# Wave8 R32 ChainHandlersR32C4 + ChainHandlersR32C — STATUS (final this session)

Branch: `wave8/r32-chainc4` (head 9ae6896a9 + working tree below)
Lean v4.33.1, atomic `lean -o` builds with tmp-file+`test -s`+`mv -f`.

## Delivered (both compile clean, zero sorry/axiom/native_decide/bv_decide)

### `ContractParts/ChainHandlersR32C4.lean` (NEW, ~1080 lines)
- **`op_swap_chainSpecR32`** (idx 517), **`op_swapn_chainSpecR32`** (idx 521),
  **`op_exchange_chainSpecR32`** (idx 522): the full stack-swap family proved
  UNCONDITIONALLY at `OpHandlerChainSpecR32` strength via
  `opHandlerChainSpecR32_of_run` walks.
  - `epsA32_stack_swap_positions`: full R32 port of `Group06Stack2.eps_stack_swap_positions`
    with A32 payload — WitnessDbOK via `witnessDbOK_of_scratchEff` (Rl = [oldStk]),
    sysInside via `sysInside_congr_globals`, bridge HeadMemChainWF via
    `Group09ChainWF.headMemChainWF_of_disj_bre` + `headMemChainWF_g09_iff_bridge`,
    hdj via new `pw_rel_of_mem` (Pairwise-Disj transfer over flattened frameObjects).
  - `seq_callA32_stack_swap`: `HandlerRunA32.seq_call` wrapper.
  - `HandlerRunA32.seq_assign_local`: A32 port of the R14 assign-node combinator
    (needed by op_exchange's slot recomputation branches).
  - `epsA32_code_imm_bounded`, `epsA32_max_args`, `epsA32_decode_single_bounded`
    (bounded-value refinements of the readOnly A32 eps lemmas).
  - `op_exchange_tailA32`: A32 port of `Group06Stack3.op_exchange_tail`
    (max call + range check + swap + pc_add).
  - Private helper ports: `eval_cmp_eq`, `eval_notLower_var_loadG_eq_zero`,
    `eval_lower_loadG_add1_eq_zero`, `eval_seq_seq`, `loadWordExp`, `struct4`,
    `stack_slot_in`, `pw_rel_of_mem`.
- **`RemainingChainHandlersR32C4`** structure: reduced to 20 fields
  (op_swap/op_swapn/op_exchange REMOVED — now closed unconditionally):
  op_keccak, op_balance, op_calldataload, op_calldatacopy, op_codecopy,
  op_extcodesize, op_extcodecopy, op_returndatacopy, op_extcodehash,
  op_blockhash, op_selfbalance, op_mload, op_mstore, op_mstore8, op_sload,
  op_sstore, op_tload, op_tstore, op_push (OpPushBoundedChainSpecR32),
  op_log (OpLogBoundedChainSpecR32).

### `ContractParts/ChainHandlersR32C.lean` (NEW, 314 lines)
- `remainingChainHandlersR32_of`: 77-field merge of C1/C2/C3 proven walks,
  C4's unconditional swap family (`ChainHandlersR32C4.op_swap_chainSpecR32`,
  `op_swapn_chainSpecR32`, `op_exchange_chainSpecR32`) and the 17-field
  `hc4 : RemainingChainHandlersR32C4` parameter.
- G10-lane hop derivations: `hop_create_of_g10`, `hop_create2_of_g10`,
  `hop_call_of_g10`, `hop_callcode_of_g10`, `hop_delegatecall_of_g10`,
  `hop_staticcall_of_g10`.
- `chainHandlersR32Stmt_of`: proves `ChainHandlersR32Stmt` from clean named
  parameters: `hdb : HdbBounded`, AR32 eps params (hU/hcc/hcc2/hgcr/hgca),
  the hop_* G10-lane premises, `hc4`, and
  `hframes : TerminatingFunBoundedOn (fun s => EvmInvR32 s ∧ HeadMemBridge.HeadMemChainWF s) "run_frames" K.«run_frames»`.

## Net effect
The R32 chain-handler closure assembly now needs only:
- 17 C4 opcode fields (memory/storage/transient/account/env families),
- 4 fresh hop walks + CallSpecLiftR32 wiring + AR32 callee contracts,
- HdbBounded + run_frames termination.
All stack-opcode lanes (push/dup/dupn/swap/swapn/exchange) are closed
unconditionally end-to-end at EvmInvR32 + HeadMemBridge strength.

## Known-hard open families (unchanged, per prior STATUS)
sload/sstore/tload/tstore, keccak/mem (mload/mstore/mstore8), balance-family,
op_blockhash, op_calldataload, op_push/op_log bounded specs, and the G10
hop lifts requiring cross-lane continuations.

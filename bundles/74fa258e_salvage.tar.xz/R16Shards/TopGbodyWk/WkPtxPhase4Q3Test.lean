import InitECandidate.Solver.Wave8GuestInv.R16Shards.TopGbodyWk.WkPtxPhase4Q2

set_option Elab.async false
set_option autoImplicit false

namespace InitECandidate.Solver.Wave8GuestInv.R16Shards.TopGbodyWk

-- variant A: parenthesized application value, same line
theorem p4Q3_parse_testA {F : Type}
    {entry mid : PanSemStateFiniteExact 64 F} {lw nl_w w_lp : BitVec 64}
    (tail : ProgHOL 64)
    (htail : PtxRelRunStrong entry tail
      (setVarHOLFinite (ofString "i") (.val (.word 0x0000000000000000#64))
        (setVarHOLFinite (ofString "stable_lp") (.val (.word w_lp))
          {mid with memory := (pmcUpdW mid.memory (BitVec.ofNat 64 (lw.toNat + 8)) nl_w)}))) : True := trivial

-- variant B: newline after :=, atomic-ish value
theorem p4Q3_parse_testB {F : Type}
    {entry mid : PanSemStateFiniteExact 64 F} {lw nl_w w_lp : BitVec 64}
    (tail : ProgHOL 64)
    (htail : PtxRelRunStrong entry tail
      (setVarHOLFinite (ofString "i") (.val (.word 0x0000000000000000#64))
        (setVarHOLFinite (ofString "stable_lp") (.val (.word w_lp))
          {mid with memory :=
            nl_w}))) : True := trivial

end InitECandidate.Solver.Wave8GuestInv.R16Shards.TopGbodyWk

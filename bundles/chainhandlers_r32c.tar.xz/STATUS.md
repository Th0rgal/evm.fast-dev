# Wave 8 R32 Chain-Handlers — Delivery Status (Bundle-Inc4 Update)

## What happened this turn (r32_inc4 bundle)
1. Applied `r32_inc4.bundle` (sha256 `92531a81decba2683b652493fe62ebf258b02399832a3797e75a03709acdd3f5`,
   git head `9ae6896a930be62f439555d37a9167583e40ef93`) via `git fetch <bundle> wave8/r32-bundle`
   + fast-forward merge (base decd3bdb6). Adds 6 files: Group10BufSpecsR32 (1475L),
   Group10CallContR32 (1040L), Group10CallGenR32 (749L), MainEntryR32 (989L),
   TargetR32Clean (139L), WkProcessTransactionR32 (168L).
2. **Found + fixed a staging bug in `Group10CallR32.lean`** (r32_inc3 file):
   `op_staticcall_specA_r32` used the seed runner `opHandlerSpecA_of_run_seed_g10`
   (expects `HandlerRunA s0 (fun _ => EvmInv s0)` continuation) but
   `Group10CallR32Continuations.op_staticcall` is `True`-shaped (identical to
   `op_delegatecall`, which correctly uses the plain `opHandlerSpecA_of_run`).
   One-word fix; file now compiles clean (exit=0, 0 errors). Patch included:
   `g10callr32-staticcall-fix.patch`. **Please propagate upstream.**
3. **Bundle lane now fully compiles** (all via direct lean, oleans installed):
   - Group10CallR32 (after fix) → Group10BufSpecsR32 → Group10CreateR32
     (`op_create_specA_r32`, `op_create2_specA_r32` — the bundle's stated purpose,
     verified: exit=0, 0 errors).
   - WkProcessTransactionR32 → MainEntryR32 → TargetR32Clean (exit=0 each).
     Required building missing/stale oleans first: `StrongBridgesR31`,
     `SetStorageR31`, the whole `WkPtxPhase4{,A..Q2,Wire}` chain (22 files,
     NOTE: `WkPtxPhase4O` imports `O2` — build order O1→O2→O is NOT
     lexicographic), and refreshing stale `WkBlockTxEnc/EncodeReceipt.olean`
     (it predated `receiptKeccakIvls`/`encode_receipt_main`).
4. **NOT compiling (WIP, controller's lane)**: `Group10CallGenR32.lean` +
   `Group10CallContR32.lean`. Two blockers:
   a. They reference **`EvmChildPushSpecA`, which is defined nowhere** in the
      bundle. Usage shows the intended shape: like `EvmPreservingSpecA`
      (Group10CallsCreates.lean:1439) but returned-case conclusion
      `(EvmInv post ∧ WF post) ∧ evmR post ≤ evmR s ∧ Qret s v post ∧
      ((v = .val (.word 0) ∧ evmChain post = evmChain s) ∨
       ((evmChain post).length = (evmChain s).length + 1 ∧ ∃ w ≠ 0, v = .val (.word w)))`,
      error case unchanged (chain kept). Both files already import
      Group10CallR32, so the def belongs there.
   b. They bind `(hgc32 : callSpec_generic_call_r32)` — but Group10CallR32
      stages `callSpec_generic_call_r32` as a conditional THEOREM
      (∀ {F s post}, hWF → hchain → … → WF post ∧ ∃ ec, …), not the
      `EvmChildPushSpecA`-typed leaf the combinator applications expect
      (`apply ccA_decCall_childCall_r32 hgc32`). Needs re-staging as a
      def/theorem of `EvmChildPushSpecA … (ofString "generic_call")` plus its
      proof (the real G10-lane obligation).

## Assembly target (now fully known — StrongBridgesR32.lean + MainEntryR32)
`ChainHandlersR32Stmt` (StrongBridgesR32.lean:596) has 18 fields:
- `hsetA` (set_storage A-side, 5-global GlobalsKept + evmR — NOTE: my C3
  epsA32_set_storage concludes the weaker 3-global form; needs strengthening
  or a separate A-side proof),
- `hU`/`hcc`/`hcc2`/`hgcr`/`hgca` (five G10 callee contracts at
  `EvmPreservingSpecAR32`, P=True, Q=LocFrame — Group10BufSpecsR32 provides
  u256_to_be32/cca/cc2 at A-strength with buffer-flavored Pc; AR32-strength
  versions + generic_create/generic_call still needed),
- `bf`/`be`/`bx`/`bd`/`hframes` (TerminatingFunBoundedOn bounds),
- `hop_mcopy`/`hop_return`/`hop_revert`/`hop_selfdestruct` (MINE — fresh walks),
- `hop_create`/`hop_call`/`hop_callcode`/`hop_delegatecall`/`hop_create2`/
  `hop_staticcall` (G10 lane via `CallSpecLiftR32` = StrongBridgesR32.lean:576:
  `OpHandlerSpecA fname → OpHandlerChainSpecR32 fname`),
- `hrem : RemainingChainHandlersR32` (77 opcode fields; StrongBridgesR32.lean:376).
Consumers verified compiling: `MainEntryR32.mainEntryR32` (MainEntryR32.lean:737)
takes `(hChain : ChainHandlersR32Stmt) (hWkPtx : WkProcessTransactionStmtR32)`;
`TargetR32Clean.assemblyR32`/`MainEntryLaneR32` consume it further.

## My files (unchanged this turn, all compile clean — re-verified)
- `ChainHandlersR32C1.lean` (3788L) — A32 framework + combinators + leaves
  (epsA32_stack_pop/push/pc_add/of_readOnly), decCall/decCall_simple/seq_call/
  seq_charge_gas_exact, `opHandlerChainSpecR32_of_run` runner.
- `ChainHandlersR32C2.lean` (2646L) — 52 walks at R32 strength + readOnly
  callee leaves + `witnessDbOK_of_head_slots` + ite-helpers.
- `ChainHandlersR32C3.lean` (685L) — §1 `epsA32_of_wkSc` master; §2 world
  leaves (get_account/ext_code_of/get_storage/get_storage_original/set_storage/
  move_ether); §3 readOnly leaves (max/acct_is_empty_ro/is_warm_address_ro/
  is_valid_jumpdest/check_gas/require_not_static/words_of_lt/add_sat_pos/
  access_gas_cost_bounds); §4 combinators (decCall_shaped, decCall_stack_pop_s4,
  seq_charge_gas_const, seq_store_ev_nonstruct) + §4b transfer-hstep lemmas;
  §5 walks op_jump (idx 503) + op_jumpi (idx 504).
- Coverage: 54/77 `hrem` opcode fields (52 C2 + jump/jumpi C3).

## Remaining walk work (difficulty notes for next sessions)
- op_tload/op_tstore (Group07Transient:85/109): old leaves
  `eps_get_transient_storage`/`eps_set_transient_storage`
  (JournalTransientHelpers:169/:1890) are plain `EvmPreservingSpec`
  (EvmInv-only, no chain-WF/WitnessDbOK). A32 lift needs chain-WF +
  WitnessDbOK preservation through sk_make scratch writes + ts-table
  htab reads (tload) / htab_set writes (tstore). NOT readOnly
  (`transientMutCallees`), so `epsA32_of_readOnly` does not apply.
- op_sload/op_sstore (StateAccountOps:297/335): get_storage leaves ready (§2),
  but need fresh `epsA32_is_warm_storage_key` (htab_has read at ev+176) and
  `epsA32_warm_storage_key` (htab_set write at ev+176, GlobalsKept ["heap_ptr"])
  lifts — the "warm-family needs head-htab-write WitnessDbOK argument" open
  risk. Also `epsA32_u256_to_be32_evm_key_buf` (Group10BufSpecsR32's
  `bufSpec_u256_to_be32_r32` is A-strength with buffer Pc; walk flavor needs
  out=evm_key_buf correlation per `u256_to_be32_callee_out_eq_key`).
- op_blockhash (Group05bEnv5:289): needs eps_block_env world leaf +
  eps_track_ancestor_access (access-table write) + eps_u256_from_be + sat_word.
- op_balance-family (StateAccountOps:90/108/141/182): need
  epsA32_to_address_masked (WarmAccessHelpers:583) + epsA32_warm_after_charge
  (:1140) + epsA32_is_account_alive + epsA32_emit_transfer_log.
- op_swap/swapn/exchange (Group06Stack3:371/419/542): epsA32_stack_swap_positions
  port (Group06Stack2:201+ ~200-line hand-proof).
- mem-family (Group08): g08 combinator ports (decCall_stack_copy_g08,
  eps_sat_word_exact_g08:1777, eps_u256_to_be32_head_mem_g08:5222).
- op_keccak (Group04:2967): extend_memory lane.
- op_push (OpPushBoundedChainSpecR32) / op_log (OpLogBoundedChainSpecR32).
- Then ChainHandlersR32C.lean assembly: hrem record (77 fields), 4 hop_*
  fresh walks, CallSpecLiftR32-lifts for the 6 G10 hop_* fields, the 5 AR32
  callee contracts + bounds + hsetA as premises (Stmt shape), wire to
  ChainHandlersR32Stmt.

## Build command (direct lean; NEVER lake build / turbo-lean)
```
cd /var/lib/orb-node/caches/repo && export ELAN_HOME=/var/lib/orb-node/work/caches/elan
REPO=$(readlink -f /var/lib/orb-node/caches/repo); LP="$REPO/.lake/build/lib/lean"
for p in "$REPO"/.lake/packages/*/.lake/build/lib/lean; do LP="$LP:$p"; done
export LEAN_PATH="$LP"
timeout 580 lean submission/InitECandidate/Solver/Wave8GuestInv/ContractParts/<FILE>.lean
# olean: lean -o <OL>/<FILE>.olean <path>; OL=$REPO/.lake/build/lib/lean/InitECandidate/Solver/Wave8GuestInv/ContractParts
```
Hard-won method notes (binder arities, decCall explicit-args/Qc, P-shape
transitions, probe-technique, rcases/obtain substitution, evmR bridging,
namespace ambiguity watchlist) — see previous STATUS (mission-state.md at
`/var/lib/orb-node/work/22b760b0-8de6-4a1b-ac0c-7c3b00fd9877/.opencode/mission-state.md`).

## Compile-evidence logs (this turn, all exit=0, 0 errors)
FINAL_ChainHandlersR32C{1,2,3}.log (my files), g10callr32.log (Group10CallR32
after fix), g10buf.log (Group10BufSpecsR32), g10create.log (Group10CreateR32),
WkProcessTransactionR32.log, MainEntryR32.log, TargetR32Clean.log,
sbr31.log (StrongBridgesR31), ss31.log (SetStorageR31),
p4_*.log (Phase4 chain), encrcpt.log (EncodeReceipt refresh).

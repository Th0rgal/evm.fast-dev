import InitECandidate.Solver.Wave8GuestInv.ContractParts.StrongBridgesR32
import InitECandidate.Solver.Wave8GuestInv.R16Shards.OpHandlersB.Group09LogReturnRevert
import InitECandidate.Solver.Wave8GuestInv.R16Shards.OpHandlersB.Group10CallsCreates
import InitECandidate.Solver.Wave8GuestInv.R16Shards.OpHandlers.StackPushInv
import InitECandidate.Solver.Wave8GuestInv.R16Shards.OpHandlers.U256WsSpecs

/-! # Wave 8 R32 C1: chain-WF walk framework with `EvmInvR32` (part 1)

`HandlerRunA32`, an `EvmInvR32`-strength port of the `Group09ChainWF.HandlerRunA`
combinator framework over `StrongBridgesR32.EvmPreservingSpecAR32`-style callee leaves
(bridge-flavored `HeadMemChainWF`), together with the master witness-DB preservation
lemmas used to lift frame-effect callees (`stack_pop`, `pc_add`, `charge_gas`,
`stack_push*`, `u256_*` safe-step callees) from `EvmInv` to `EvmInvR32` strength.
-/

set_option Elab.async false
set_option autoImplicit false
set_option maxRecDepth 100000
set_option maxHeartbeats 4000000
set_option linter.unusedSimpArgs false
set_option linter.unusedTactic false
set_option linter.unreachableTactic false
set_option linter.unusedVariables false

namespace InitECandidate.Solver.Wave8GuestInv.ContractParts.ChainHandlersR32C1

open Flapjack Flapjack.Pancake.PanLang Flapjack.PanSemStateFiniteExact
open Flapjack.Basis.Pure.MlString
open InitE
open InitECandidate.Solver.GuestCodeLookup
open InitECandidate.Solver.GuestTrapAndLookup
open InitECandidate.Solver.PanTerminatingBounded
open InitECandidate.Solver.PanRunBounded
open InitECandidate.Solver.Wave8GuestInv
open InitECandidate.Solver.Wave8GuestInv.R11Shards
open InitECandidate.Solver.Wave8GuestInv.R11Shards.OpDispatchSpec
open InitECandidate.Solver.Wave8GuestInv.R14Shards.OpHandlersA
open InitECandidate.Solver.Wave8GuestInv.R16Shards.OpHandlers
open InitECandidate.Solver.Wave8Contracts.M23
open InitECandidate.Solver.Wave8GuestInv.ContractParts.StrongBridges
open InitECandidate.Solver.Wave8GuestInv.ContractParts
open InitECandidate.Solver.Wave8GuestInv.R16Shards.OpHandlersB
open InitECandidate.Solver.Wave8GuestInv.R16Shards.OpHandlersB.Group09ChainWF
open InitECandidate.Solver.Wave8GuestInv.R16Shards.OpHandlersB.Group10
open InitECandidate.Solver.Wave8GuestInv.R16Shards.EvmEkFk

/-! ## 1. The R32 leaf-callee spec (bridge flavor) -/

/-- `EvmPreservingSpecA` at `EvmInvR32` strength with bridge `HeadMemChainWF`.  This is
`StrongBridgesR32.EvmPreservingSpecAR32` with `HeadMemBridge.HeadMemChainWF` in place of
`Group10.HeadMemChainWF`, so that walk combinators and the bridge-flavored
`OpHandlerChainSpecR32` share one WF convention. -/
def EvmPreservingSpecA32
    (P : ∀ {F : Type}, PanSemStateFiniteExact 64 F → Prop)
    (Qret : ∀ {F : Type}, PanSemStateFiniteExact 64 F → ValueHOL 64 → PanSemStateFiniteExact 64 F → Prop)
    (fname : MlS) : Prop :=
  ∃ (params : List (MlS × ShapeHOL)) (body : ProgHOL 64) (retShape : ShapeHOL),
    originalRuntimeCode.lookup fname = some (params, body, retShape) ∧
    ∀ {F : Type} (s : PanSemStateFiniteExact 64 F), s.code = originalRuntimeCode →
      EvmInvR32 s → HeadMemBridge.HeadMemChainWF s → P s →
      (∃ values, lookupCodeHOLFinite originalRuntimeCode.lookup fname values =
        some (body, s.locals, retShape)) →
      (evaluateHOLFiniteState s body).1 ≠ some .timeOut →
      let r := (evaluateHOLFiniteState s body).1
      let post := (evaluateHOLFiniteState s body).2
      (∀ v, r = some (.returned v) →
        (EvmInvR32 post ∧ HeadMemBridge.HeadMemChainWF post) ∧
          evmChain post = evmChain s ∧ OpDispatchSpec.evmR post ≤ OpDispatchSpec.evmR s ∧ Qret s v post) ∧
      (IsEvmErr r → (EvmInvR32 post ∧ HeadMemBridge.HeadMemChainWF post) ∧
        evmChain post = evmChain s ∧ OpDispatchSpec.evmR post ≤ OpDispatchSpec.evmR s)

/-- Transport from the `Group10`-flavored `EvmPreservingSpecAR32` of
`StrongBridgesR32` into the bridge-flavored `EvmPreservingSpecA32`. -/
theorem epsA32_of_ar32 {P Qret fname}
    (h : EvmPreservingSpecAR32 P Qret fname) : EvmPreservingSpecA32 P Qret fname := by
  obtain ⟨params, body, retShape, hlook, hspec⟩ := h
  refine ⟨params, body, retShape, hlook, ?_⟩
  intro F s hcode hInv hWF hP hval hnt
  have hWF10 : Group10.HeadMemChainWF s := (headMemChainWF_g10_iff_bridge s).mpr hWF
  have hs := hspec s hcode hInv hWF10 hP hval hnt
  dsimp only at hs ⊢
  refine ⟨fun v hv => ?_, fun he => ?_⟩
  · obtain ⟨⟨hi, hw⟩, hch, hR, hQ⟩ := hs.1 v hv
    exact ⟨⟨hi, (headMemChainWF_g10_iff_bridge _).mp hw⟩, hch, hR, hQ⟩
  · obtain ⟨⟨hi, hw⟩, hch, hR⟩ := hs.2 he
    exact ⟨⟨hi, (headMemChainWF_g10_iff_bridge _).mp hw⟩, hch, hR⟩

/-! ## 2. The `HandlerRunA32` walk framework -/

/-- `EvmInvR32`-strength port of `Group09ChainWF.HandlerRunA`: a walk of an opcode
handler body from initial state `s0`, maintaining the `EvmInvR32`/bridge-WF invariant,
chain length, and the `charged` flag's `evmR` bound, concluding
`OpDispatchChainPostR32 s0`. -/
def HandlerRunA32 {F : Type} (s0 : PanSemStateFiniteExact 64 F)
    (P : PanSemStateFiniteExact 64 F → Prop) (charged : Bool)
    (prog : ProgHOL 64) : Prop :=
  ∀ (t : PanSemStateFiniteExact 64 F), t.code = originalRuntimeCode →
    EvmInvR32 t → HeadMemBridge.HeadMemChainWF t →
    (evmChain t).length = (evmChain s0).length →
    (if charged then evmR t < evmR s0 else evmR t ≤ evmR s0) → P t →
    (evaluateHOLFiniteState t prog).1 ≠ some .timeOut →
    OpDispatchChainPostR32 s0 (evaluateHOLFiniteState t prog).1 (evaluateHOLFiniteState t prog).2

theorem rboundA32_step {charged : Bool} {r1 r2 r0 : Nat}
    (h1 : r1 ≤ r2) (h2 : if charged then r2 < r0 else r2 ≤ r0) :
    if charged then r1 < r0 else r1 ≤ r0 := by
  cases charged <;> simp at * <;> omega

theorem rboundA32_to_le {charged : Bool} {r1 r0 : Nat}
    (h : if charged then r1 < r0 else r1 ≤ r0) : r1 ≤ r0 := by
  cases charged <;> simp at h <;> omega

theorem HandlerRunA32.weaken {F : Type} {s0 : PanSemStateFiniteExact 64 F}
    {P Q : PanSemStateFiniteExact 64 F → Prop} {charged : Bool} {prog : ProgHOL 64}
    (himp : ∀ t, EvmInvR32 t → P t → Q t) (h : HandlerRunA32 s0 Q charged prog) :
    HandlerRunA32 s0 P charged prog :=
  fun t hc hi hw hl hR hp hn => h t hc hi hw hl hR (himp t hi hp) hn

/-- g09-style single-`rfl` congruence: elaborating `hlc` before `h` keeps the
trivial `?post := post'` assignment from being made, so `h` keeps its raw post. -/
theorem opDispatchChainPostR32_congr_lcl {F : Type}
    {s post post' : PanSemStateFiniteExact 64 F} {r : Option (PanSemResultExact 64)}
    (hlc : post' = { post with locals := post'.locals, clock := post'.clock })
    (h : OpDispatchChainPostR32 s r post) : OpDispatchChainPostR32 s r post' :=
  opDispatchChainPostR32_congr_lc rfl rfl (by rw [hlc]) (by rw [hlc]) hlc h

theorem HandlerRunA32.ret {F : Type} {s0 : PanSemStateFiniteExact 64 F}
    {P : PanSemStateFiniteExact 64 F → Prop} (e : ExpHOL 64) :
    HandlerRunA32 s0 P true (.return e) := by
  intro t _ hi hw _ hR _ _
  simp only [↓reduceIte] at hR
  rw [evaluateHOLFiniteState_return]
  split
  · exact opDispatchChainPostR32_error s0 t
  · split
    · have hi' := localsFree_evmInvR32 t (emptyLocalsHOLFinite t).locals t.clock hi
      have hw' := HeadMemBridge.headMemChainWF_locals t (emptyLocalsHOLFinite t).locals t.clock hw
      have hc := R11Shards.OpDispatchSpec.evm_congr (s := t) (t := emptyLocalsHOLFinite t) rfl rfl
      refine ⟨fun _ => ⟨⟨hi', hw'⟩, evmPot_lt_of_evmR_lt hi'.1 ?_⟩, ?_⟩
      · rw [hc.2.1]; exact hR
      · rintro ⟨_, h⟩; cases h
    · exact opDispatchChainPostR32_error s0 t

theorem HandlerRunA32.ret_done {F : Type} {s0 : PanSemStateFiniteExact 64 F}
    (hRun : EvmRun s0) {P : PanSemStateFiniteExact 64 F → Prop} {charged : Bool}
    (hdone : ∀ t, EvmInvR32 t → P t → EvmDone t) (e : ExpHOL 64) :
    HandlerRunA32 s0 P charged (.return e) := by
  intro t _ hi hw hlen hR hP _
  have hR_le : evmR t ≤ evmR s0 := rboundA32_to_le hR
  rw [evaluateHOLFiniteState_return]
  split
  · exact opDispatchChainPostR32_error s0 t
  · split
    · have hi' : EvmInvR32 (emptyLocalsHOLFinite t) :=
        localsFree_evmInvR32 t (emptyLocalsHOLFinite t).locals t.clock hi
      have hw' : HeadMemBridge.HeadMemChainWF (emptyLocalsHOLFinite t) :=
        HeadMemBridge.headMemChainWF_locals t (emptyLocalsHOLFinite t).locals t.clock hw
      have hc := R11Shards.OpDispatchSpec.evm_congr (s := t) (t := emptyLocalsHOLFinite t) rfl rfl
      have hDone' : EvmDone (emptyLocalsHOLFinite t) := by
        unfold EvmDone globN memW
        exact hdone t hi hP
      refine ⟨fun _ => ⟨⟨hi', hw'⟩, evmPot_lt_of_done hRun hi'.1 hDone'
        (by rw [hc.2.2.1, hlen]) (by rw [hc.2.1]; exact hR_le)⟩, ?_⟩
      rintro ⟨_, h⟩; cases h
    · exact opDispatchChainPostR32_error s0 t

theorem HandlerRunA32.raise_evmErr {F : Type} {s0 : PanSemStateFiniteExact 64 F}
    {P : PanSemStateFiniteExact 64 F → Prop} {charged : Bool} (e : ExpHOL 64) :
    HandlerRunA32 s0 P charged (.raise (ofString "EvmErr") e) := by
  intro t _ hi hw hlen hR _ _
  have hR_le : evmR t ≤ evmR s0 := rboundA32_to_le hR
  rw [evaluateHOLFiniteState_raise]
  split
  · dsimp only
    split
    · have hi' := localsFree_evmInvR32 t (emptyLocalsHOLFinite t).locals t.clock hi
      have hw' := HeadMemBridge.headMemChainWF_locals t (emptyLocalsHOLFinite t).locals t.clock hw
      have hc := evm_congr (s := t) (t := emptyLocalsHOLFinite t) rfl rfl
      refine ⟨?_, fun _ => ⟨⟨hi', hw'⟩, by rw [hc.2.2.1]; exact hlen, by rw [hc.2.1]; exact hR_le⟩⟩
      rintro ⟨_, h⟩; cases h
    · exact opDispatchChainPostR32_error s0 t
  · exact opDispatchChainPostR32_error s0 t

theorem HandlerRunA32.ite {F : Type} {s0 : PanSemStateFiniteExact 64 F}
    {P : PanSemStateFiniteExact 64 F → Prop} {charged : Bool}
    {cond : ExpHOL 64} {yes no : ProgHOL 64}
    (hyes : HandlerRunA32 s0 (fun t => P t ∧
      ∃ w : BitVec 64, @evalHOLExact 64 F _ t.toExact (fun a => Classical.propDecidable (t.memaddrs a)) cond = some (.val (.word w)) ∧ w ≠ 0) charged yes)
    (hno : HandlerRunA32 s0 (fun t => P t ∧
      @evalHOLExact 64 F _ t.toExact (fun a => Classical.propDecidable (t.memaddrs a)) cond = some (.val (.word 0))) charged no) :
    HandlerRunA32 s0 P charged (.ite cond yes no) := by
  intro t hc hi hw hl hR hp hn
  rw [evaluateHOLFiniteState_ite] at hn ⊢
  revert hn
  split
  · rename_i w he
    by_cases hz : w = 0
    · subst hz; simp only [↓reduceIte]
      intro hn; exact hno t hc hi hw hl hR ⟨hp, he⟩ hn
    · simp only [hz, ↓reduceIte]
      intro hn; exact hyes t hc hi hw hl hR ⟨hp, w, he, hz⟩ hn
  · intro _; exact opDispatchChainPostR32_error s0 t

theorem HandlerRunA32.seq_skip {F : Type} {s0 : PanSemStateFiniteExact 64 F}
    {P : PanSemStateFiniteExact 64 F → Prop} {charged : Bool} {cont : ProgHOL 64}
    (hcont : HandlerRunA32 s0 P charged cont) :
    HandlerRunA32 s0 P charged (.seq .skip cont) := by
  intro t hc hi hw hl hR hp hn
  rw [evaluateHOLFiniteState_seq_line780, evaluateHOLFiniteState_skip] at hn ⊢
  exact hcont t hc hi hw hl hR hp hn

theorem HandlerRunA32.dec {F : Type} {s0 : PanSemStateFiniteExact 64 F}
    {P Q : PanSemStateFiniteExact 64 F → Prop} {charged : Bool}
    {nm : MlS} {sh : ShapeHOL} {init : ExpHOL 64} {body : ProgHOL 64}
    (hinit : ∀ t v,
      @evalHOLExact 64 F _ t.toExact (fun a => Classical.propDecidable (t.memaddrs a)) init = some v →
      EvmInvR32 t → HeadMemBridge.HeadMemChainWF t → P t → Q (setVarHOLFinite nm v t))
    (hbody : HandlerRunA32 s0 Q charged body) :
    HandlerRunA32 s0 P charged (.dec nm sh init body) := by
  intro t hc hi hw hlen hR hp hn
  rw [evaluateHOLFiniteState_dec_total] at hn ⊢
  dsimp only at hn ⊢
  revert hn
  split
  · intro _; exact opDispatchChainPostR32_error s0 t
  · rename_i v hv
    split
    · intro hn
      let t1 := setVarHOLFinite nm v t
      have hi1 : EvmInvR32 t1 := localsFree_evmInvR32 t t1.locals t.clock hi
      have hw1 : HeadMemBridge.HeadMemChainWF t1 :=
        HeadMemBridge.headMemChainWF_locals t t1.locals t.clock hw
      have hc1 := evm_congr (s := t) (t := t1) rfl rfl
      have hR1 : if charged then evmR t1 < evmR s0 else evmR t1 ≤ evmR s0 := by
        rw [hc1.2.1]; exact hR
      have hb := hbody t1 hc hi1 hw1 (hc1.2.2.1.trans hlen) hR1 (hinit t v hv hi hw hp) hn
      exact opDispatchChainPostR32_congr_lcl rfl hb
    · intro _; exact opDispatchChainPostR32_error s0 t

theorem HandlerRunA32.dec_simple {F : Type} {s0 : PanSemStateFiniteExact 64 F}
    {charged : Bool} {nm : MlS} {sh : ShapeHOL} {init : ExpHOL 64} {body : ProgHOL 64}
    (hbody : HandlerRunA32 s0 (fun _ => True) charged body) :
    HandlerRunA32 s0 (fun _ => True) charged (.dec nm sh init body) :=
  HandlerRunA32.dec (fun _ _ _ _ _ _ => trivial) hbody

theorem HandlerRunA32.decCall {F : Type} {s0 : PanSemStateFiniteExact 64 F}
    {P Q : PanSemStateFiniteExact 64 F → Prop}
    {Pc : ∀ {F : Type}, PanSemStateFiniteExact 64 F → Prop}
    {Qc : ∀ {F : Type}, PanSemStateFiniteExact 64 F → ValueHOL 64 → PanSemStateFiniteExact 64 F → Prop}
    {charged : Bool}
    {nm : MlS} {sh : ShapeHOL} {fname : MlS} {args : List (ExpHOL 64)} {cont : ProgHOL 64}
    (hf : EvmPreservingSpecA32 Pc Qc fname)
    (hentry : ∀ t values body' callee ret',
      t.code = originalRuntimeCode → EvmInvR32 t → HeadMemBridge.HeadMemChainWF t → P t →
      evalListHOLFinite t (h := fun a => Classical.propDecidable (t.memaddrs a)) args = some values →
      lookupCodeHOLFinite t.code.lookup fname values = some (body', callee, ret') →
      Pc (callEntryStateHOLFinite t callee))
    (hstep : ∀ t values body callee retShape v cpost,
      EvmInvR32 t → HeadMemBridge.HeadMemChainWF t → P t →
      evalListHOLFinite t (h := fun a => Classical.propDecidable (t.memaddrs a)) args = some values →
      lookupCodeHOLFinite originalRuntimeCode.lookup fname values = some (body, callee, retShape) →
      EvmInvR32 cpost → HeadMemBridge.HeadMemChainWF cpost →
      evmChain cpost = evmChain (callEntryStateHOLFinite t callee) →
      Qc (callEntryStateHOLFinite t callee) v cpost →
      Q (setVarHOLFinite nm v { cpost with locals := t.locals }))
    (hcont : HandlerRunA32 s0 Q charged cont) :
    HandlerRunA32 s0 P charged (.decCall nm sh fname args cont) := by
  intro t hc hi hw hlen hR hp hn
  obtain ⟨params, body, retShape, hlook, hspec⟩ := hf
  rw [evaluateHOLFiniteState_decCall_fixClockRewrite] at hn ⊢
  rcases hargs : evalListHOLFinite t (h := fun a => Classical.propDecidable (t.memaddrs a)) args with _ | values
  · exact opDispatchChainPostR32_error s0 t
  · simp only [hargs] at hn ⊢
    rcases hl : lookupCodeHOLFinite t.code.lookup fname values with _ | ⟨body', callee, ret'⟩
    · exact opDispatchChainPostR32_error s0 t
    · simp only [hl] at hn ⊢
      by_cases hz : t.clock = 0
      · simp [hz] at hn
      · simp only [hz, ↓reduceIte] at hn ⊢
        have hbody_eq : body' = body :=
          lookupCodeHOLFinite_installed_body t.code.lookup fname params body body'
            retShape ret' values callee (by rw [hc]; exact hlook) hl
        subst body'
        have hret_eq : ret' = retShape := by
          have hx := PanSemStateFiniteExact.lookupCodeHOLFinite_eq_some
            t.code.lookup fname values body callee ret' hl
          rw [hc] at hx; simp only [Flapjack.lookupCodeHOLExact, hlook] at hx
          split at hx
          · exact (congrArg (fun x => x.2.2) (Option.some.inj hx)).symm
          · cases hx
        subst ret'
        have hi_ce : EvmInvR32 (callEntryStateHOLFinite t callee) :=
          localsFree_evmInvR32 t callee (t.clock - 1) hi
        have hw_ce : HeadMemBridge.HeadMemChainWF (callEntryStateHOLFinite t callee) :=
          HeadMemBridge.headMemChainWF_locals t callee (t.clock - 1) hw
        have hPc : Pc (callEntryStateHOLFinite t callee) :=
          hentry t values body callee retShape hc hi hw hp hargs hl
        have hl_orig : lookupCodeHOLFinite originalRuntimeCode.lookup fname values =
            some (body, callee, retShape) := by rwa [← hc]
        have hmeta := (PanRunBounded.evaluateHOLFiniteState_metadata (callEntryStateHOLFinite t callee) body).1
        rcases hrun : evaluateHOLFiniteState (callEntryStateHOLFinite t callee) body with ⟨res, cpost⟩
        simp only [hrun] at hn hmeta ⊢
        change cpost.code = t.code at hmeta
        have hc_ce := evm_congr (s := t) (t := callEntryStateHOLFinite t callee) rfl rfl
        have hQ (hsafe : res ≠ some .timeOut) :
            (∀ v, res = some (.returned v) →
              (EvmInvR32 cpost ∧ HeadMemBridge.HeadMemChainWF cpost) ∧
              evmChain cpost = evmChain (callEntryStateHOLFinite t callee) ∧
              evmR cpost ≤ evmR (callEntryStateHOLFinite t callee) ∧
              Qc (callEntryStateHOLFinite t callee) v cpost) ∧
            (IsEvmErr res →
              (EvmInvR32 cpost ∧ HeadMemBridge.HeadMemChainWF cpost) ∧
              evmChain cpost = evmChain (callEntryStateHOLFinite t callee) ∧
              evmR cpost ≤ evmR (callEntryStateHOLFinite t callee)) := by
          have hs := hspec (callEntryStateHOLFinite t callee) hc hi_ce hw_ce hPc ⟨values, hl_orig⟩
            (by rw [hrun]; exact hsafe)
          dsimp only at hs; rw [hrun] at hs; exact hs
        cases res with
        | none => exact opDispatchChainPostR32_error s0 cpost
        | some r0 =>
          cases r0 with
          | timeOut => simp at hn
          | returned v =>
            dsimp only at hn ⊢
            split
            · rename_i hsh_ok
              rw [if_pos hsh_ok] at hn
              obtain ⟨⟨hi_cp, hw_cp⟩, hch_cp, hR_cp, hQc_cp⟩ := (hQ (by simp)).1 v rfl
              let resumed := setVarHOLFinite nm v { cpost with locals := t.locals }
              have hcode_res : resumed.code = originalRuntimeCode := hmeta.trans hc
              have hi_res : EvmInvR32 resumed := localsFree_evmInvR32 cpost resumed.locals cpost.clock hi_cp
              have hw_res : HeadMemBridge.HeadMemChainWF resumed :=
                HeadMemBridge.headMemChainWF_locals cpost resumed.locals cpost.clock hw_cp
              have hc_res := evm_congr (s := cpost) (t := resumed) rfl rfl
              have hlen_res : (evmChain resumed).length = (evmChain s0).length := by
                rw [hc_res.2.2.1, hch_cp, hc_ce.2.2.1]; exact hlen
              have hR_res : if charged then evmR resumed < evmR s0 else evmR resumed ≤ evmR s0 :=
                rboundA32_step (by rw [hc_res.2.1]; rw [hc_ce.2.1] at hR_cp; exact hR_cp) hR
              have hQ_res : Q resumed :=
                hstep t values body callee retShape v cpost hi hw hp hargs hl_orig hi_cp hw_cp hch_cp hQc_cp
              have hb := hcont resumed hcode_res hi_res hw_res hlen_res hR_res hQ_res (by simpa [resumed] using hn)
              exact opDispatchChainPostR32_congr_lcl rfl hb
            · exact opDispatchChainPostR32_error s0 cpost
          | exception eid ev =>
            by_cases heid : eid = ofString "EvmErr"
            · subst heid
              obtain ⟨⟨hi_cp, hw_cp⟩, hch_cp, hR_cp⟩ := (hQ (by simp)).2 ⟨ev, rfl⟩
              have hi_el : EvmInvR32 cpost.emptyLocalsHOLFinite :=
                localsFree_evmInvR32 cpost _ cpost.clock hi_cp
              have hw_el : HeadMemBridge.HeadMemChainWF cpost.emptyLocalsHOLFinite :=
                HeadMemBridge.headMemChainWF_locals cpost _ cpost.clock hw_cp
              have hc_el := evm_congr (s := cpost) (t := cpost.emptyLocalsHOLFinite) rfl rfl
              refine ⟨?_, fun _ => ⟨⟨hi_el, hw_el⟩, ?_, ?_⟩⟩
              · rintro ⟨_, h⟩; cases h
              · rw [hc_el.2.2.1, hch_cp, hc_ce.2.2.1]; exact hlen
              · have := rboundA32_to_le hR; rw [hc_el.2.1]; rw [hc_ce.2.1] at hR_cp; omega
            · refine opDispatchChainPostR32_other (fun _ h => by cases h) ?_
              rintro ⟨_, h⟩; injection h with h'; injection h' with h1 _; exact heid h1
          | «break» => exact opDispatchChainPostR32_error s0 cpost
          | «continue» => exact opDispatchChainPostR32_error s0 cpost
          | finalFfi _ =>
            refine opDispatchChainPostR32_other (fun _ h => by cases h) ?_
            rintro ⟨_, h⟩; cases h
          | error => exact opDispatchChainPostR32_error s0 cpost.emptyLocalsHOLFinite

theorem HandlerRunA32.seq_call {F : Type} {s0 : PanSemStateFiniteExact 64 F}
    {P Q : PanSemStateFiniteExact 64 F → Prop}
    {Pc : ∀ {F : Type}, PanSemStateFiniteExact 64 F → Prop}
    {Qc : ∀ {F : Type}, PanSemStateFiniteExact 64 F → ValueHOL 64 → PanSemStateFiniteExact 64 F → Prop}
    {charged : Bool}
    {fname : MlS} {args : List (ExpHOL 64)} {cont : ProgHOL 64}
    (hf : EvmPreservingSpecA32 Pc Qc fname)
    (hentry : ∀ t values body' callee ret',
      t.code = originalRuntimeCode → EvmInvR32 t → HeadMemBridge.HeadMemChainWF t → P t →
      evalListHOLFinite t (h := fun a => Classical.propDecidable (t.memaddrs a)) args = some values →
      lookupCodeHOLFinite t.code.lookup fname values = some (body', callee, ret') →
      Pc (callEntryStateHOLFinite t callee))
    (hstep : ∀ t values body callee retShape v cpost,
      EvmInvR32 t → HeadMemBridge.HeadMemChainWF t → P t →
      evalListHOLFinite t (h := fun a => Classical.propDecidable (t.memaddrs a)) args = some values →
      lookupCodeHOLFinite originalRuntimeCode.lookup fname values = some (body, callee, retShape) →
      EvmInvR32 cpost → HeadMemBridge.HeadMemChainWF cpost →
      evmChain cpost = evmChain (callEntryStateHOLFinite t callee) →
      Qc (callEntryStateHOLFinite t callee) v cpost →
      Q { cpost with locals := t.locals })
    (hcont : HandlerRunA32 s0 Q charged cont) :
    HandlerRunA32 s0 P charged (.seq (.call (some (none, none)) fname args) cont) := by
  intro t hc hi hw hlen hR hp hn
  obtain ⟨params, body, retShape, hlook, hspec⟩ := hf
  rw [evaluateHOLFiniteState_seq_line780, evaluateHOLFiniteState_call] at hn ⊢
  rcases hargs : evalListHOLFinite t (h := fun a => Classical.propDecidable (t.memaddrs a)) args with _ | values
  · exact opDispatchChainPostR32_error s0 t
  · simp only [hargs] at hn ⊢
    rcases hl : lookupCodeHOLFinite t.code.lookup fname values with _ | ⟨body', callee, ret'⟩
    · exact opDispatchChainPostR32_error s0 t
    · simp only [hl] at hn ⊢
      by_cases hz : t.clock = 0
      · simp [hz] at hn
      · simp only [hz, ↓reduceIte] at hn ⊢
        have hbody_eq : body' = body :=
          lookupCodeHOLFinite_installed_body t.code.lookup fname params body body'
            retShape ret' values callee (by rw [hc]; exact hlook) hl
        subst body'
        have hret_eq : ret' = retShape := by
          have hx := PanSemStateFiniteExact.lookupCodeHOLFinite_eq_some
            t.code.lookup fname values body callee ret' hl
          rw [hc] at hx; simp only [Flapjack.lookupCodeHOLExact, hlook] at hx
          split at hx
          · exact (congrArg (fun x => x.2.2) (Option.some.inj hx)).symm
          · cases hx
        subst ret'
        have hi_ce : EvmInvR32 (callEntryStateHOLFinite t callee) :=
          localsFree_evmInvR32 t callee (t.clock - 1) hi
        have hw_ce : HeadMemBridge.HeadMemChainWF (callEntryStateHOLFinite t callee) :=
          HeadMemBridge.headMemChainWF_locals t callee (t.clock - 1) hw
        have hPc : Pc (callEntryStateHOLFinite t callee) :=
          hentry t values body callee retShape hc hi hw hp hargs hl
        have hl_orig : lookupCodeHOLFinite originalRuntimeCode.lookup fname values =
            some (body, callee, retShape) := by rwa [← hc]
        have hmeta := (PanRunBounded.evaluateHOLFiniteState_metadata (callEntryStateHOLFinite t callee) body).1
        rcases hrun : evaluateHOLFiniteState (callEntryStateHOLFinite t callee) body with ⟨res, cpost⟩
        simp only [hrun] at hn hmeta ⊢
        change cpost.code = t.code at hmeta
        have hc_ce := evm_congr (s := t) (t := callEntryStateHOLFinite t callee) rfl rfl
        have hQ (hsafe : res ≠ some .timeOut) :
            (∀ v, res = some (.returned v) →
              (EvmInvR32 cpost ∧ HeadMemBridge.HeadMemChainWF cpost) ∧
              evmChain cpost = evmChain (callEntryStateHOLFinite t callee) ∧
              evmR cpost ≤ evmR (callEntryStateHOLFinite t callee) ∧
              Qc (callEntryStateHOLFinite t callee) v cpost) ∧
            (IsEvmErr res →
              (EvmInvR32 cpost ∧ HeadMemBridge.HeadMemChainWF cpost) ∧
              evmChain cpost = evmChain (callEntryStateHOLFinite t callee) ∧
              evmR cpost ≤ evmR (callEntryStateHOLFinite t callee)) := by
          have hs := hspec (callEntryStateHOLFinite t callee) hc hi_ce hw_ce hPc ⟨values, hl_orig⟩
            (by rw [hrun]; exact hsafe)
          dsimp only at hs; rw [hrun] at hs; exact hs
        cases res with
        | none => exact opDispatchChainPostR32_error s0 cpost
        | some r0 =>
          cases r0 with
          | timeOut => simp at hn
          | returned v =>
            by_cases hsh_ok : shapeEqHOL (shapeOfHOLExact v) retShape = true
            · simp only [hsh_ok, ↓reduceIte] at hn ⊢
              obtain ⟨⟨hi_cp, hw_cp⟩, hch_cp, hR_cp, hQc_cp⟩ := (hQ (by simp)).1 v rfl
              let resumed : PanSemStateFiniteExact 64 F := { cpost with locals := t.locals }
              have hcode_res : resumed.code = originalRuntimeCode := hmeta.trans hc
              have hi_res : EvmInvR32 resumed := localsFree_evmInvR32 cpost t.locals cpost.clock hi_cp
              have hw_res : HeadMemBridge.HeadMemChainWF resumed :=
                HeadMemBridge.headMemChainWF_locals cpost t.locals cpost.clock hw_cp
              have hc_res := evm_congr (s := cpost) (t := resumed) rfl rfl
              have hlen_res : (evmChain resumed).length = (evmChain s0).length := by
                rw [hc_res.2.2.1, hch_cp, hc_ce.2.2.1]; exact hlen
              have hR_res : if charged then evmR resumed < evmR s0 else evmR resumed ≤ evmR s0 :=
                rboundA32_step (by rw [hc_res.2.1]; rw [hc_ce.2.1] at hR_cp; exact hR_cp) hR
              have hQ_res : Q resumed :=
                hstep t values body callee retShape v cpost hi hw hp hargs hl_orig hi_cp hw_cp hch_cp hQc_cp
              exact hcont resumed hcode_res hi_res hw_res hlen_res hR_res hQ_res (by simpa [resumed] using hn)
            · simp only [hsh_ok, Bool.false_eq_true, ↓reduceIte]
              exact opDispatchChainPostR32_error s0 cpost
          | exception eid ev =>
            by_cases heid : eid = ofString "EvmErr"
            · subst heid
              obtain ⟨⟨hi_cp, hw_cp⟩, hch_cp, hR_cp⟩ := (hQ (by simp)).2 ⟨ev, rfl⟩
              have hi_el : EvmInvR32 cpost.emptyLocalsHOLFinite :=
                localsFree_evmInvR32 cpost _ cpost.clock hi_cp
              have hw_el : HeadMemBridge.HeadMemChainWF cpost.emptyLocalsHOLFinite :=
                HeadMemBridge.headMemChainWF_locals cpost _ cpost.clock hw_cp
              have hc_el := evm_congr (s := cpost) (t := cpost.emptyLocalsHOLFinite) rfl rfl
              refine ⟨?_, fun _ => ⟨⟨hi_el, hw_el⟩, ?_, ?_⟩⟩
              · rintro ⟨_, h⟩; cases h
              · rw [hc_el.2.2.1, hch_cp, hc_ce.2.2.1]; exact hlen
              · have := rboundA32_to_le hR; rw [hc_el.2.1]; rw [hc_ce.2.1] at hR_cp; omega
            · refine opDispatchChainPostR32_other (fun _ h => by cases h) ?_
              rintro ⟨_, h⟩; injection h with h'; injection h' with h1 _; exact heid h1
          | «break» => exact opDispatchChainPostR32_error s0 cpost
          | «continue» => exact opDispatchChainPostR32_error s0 cpost
          | finalFfi _ =>
            refine opDispatchChainPostR32_other (fun _ h => by cases h) ?_
            rintro ⟨_, h⟩; cases h
          | error => exact opDispatchChainPostR32_error s0 cpost.emptyLocalsHOLFinite

theorem HandlerRunA32.decCall_simple {F : Type} {s0 : PanSemStateFiniteExact 64 F}
    {Qc : ∀ {F : Type}, PanSemStateFiniteExact 64 F → ValueHOL 64 → PanSemStateFiniteExact 64 F → Prop}
    {charged : Bool}
    {nm : MlS} {sh : ShapeHOL} {fname : MlS} {args : List (ExpHOL 64)} {cont : ProgHOL 64}
    (hf : EvmPreservingSpecA32 (fun _ => True) Qc fname)
    (hcont : HandlerRunA32 s0 (fun _ => True) charged cont) :
    HandlerRunA32 s0 (fun _ => True) charged (.decCall nm sh fname args cont) :=
  HandlerRunA32.decCall hf (by intros; trivial) (by intros; trivial) hcont

theorem HandlerRunA32.seq_call_simple {F : Type} {s0 : PanSemStateFiniteExact 64 F}
    {Qc : ∀ {F : Type}, PanSemStateFiniteExact 64 F → ValueHOL 64 → PanSemStateFiniteExact 64 F → Prop}
    {charged : Bool}
    {fname : MlS} {args : List (ExpHOL 64)} {cont : ProgHOL 64}
    (hf : EvmPreservingSpecA32 (fun _ => True) Qc fname)
    (hcont : HandlerRunA32 s0 (fun _ => True) charged cont) :
    HandlerRunA32 s0 (fun _ => True) charged (.seq (.call (some (none, none)) fname args) cont) :=
  HandlerRunA32.seq_call hf (by intros; trivial) (by intros; trivial) hcont

theorem HandlerRunA32.raise_other {F : Type} {s0 : PanSemStateFiniteExact 64 F}
    {P : PanSemStateFiniteExact 64 F → Prop} {charged : Bool} {eid : MlS}
    (hne : eid ≠ ofString "EvmErr") (e : ExpHOL 64) :
    HandlerRunA32 s0 P charged (.raise eid e) := by
  intro t _ _ _ _ _ _ _
  rw [evaluateHOLFiniteState_raise]
  split
  · dsimp only
    split
    · refine opDispatchChainPostR32_other (fun _ h => by cases h) ?_
      rintro ⟨_, h⟩; injection h with h'; injection h' with h1 _; exact hne h1
    · exact opDispatchChainPostR32_error s0 t
  · exact opDispatchChainPostR32_error s0 t

theorem HandlerRunA32.seq_ite_nonfallthrough_skip {F : Type} {s0 : PanSemStateFiniteExact 64 F}
    {P : PanSemStateFiniteExact 64 F → Prop} {charged : Bool}
    {cond : ExpHOL 64} {yes cont : ProgHOL 64}
    (hnn : ∀ u : PanSemStateFiniteExact 64 F, (evaluateHOLFiniteState u yes).1 ≠ none)
    (hyes : HandlerRunA32 s0 P charged yes)
    (hcont : HandlerRunA32 s0 P charged cont) :
    HandlerRunA32 s0 P charged (.seq (.ite cond yes .skip) cont) := by
  intro t hc hi hwf hlen hR hP hnt
  rw [evaluateHOLFiniteState_seq_line780, evaluateHOLFiniteState_ite] at hnt ⊢
  revert hnt
  split
  · rename_i w hw
    by_cases hw0 : w = 0
    · subst hw0; simp only [↓reduceIte, evaluateHOLFiniteState_skip]
      intro hnt; exact hcont t hc hi hwf hlen hR hP hnt
    · simp only [hw0, ↓reduceIte]
      have hy_nn := hnn t
      rcases hy : evaluateHOLFiniteState t yes with ⟨ry, sy⟩
      rw [hy] at hy_nn
      cases ry with
      | none => exact absurd rfl hy_nn
      | some r0 =>
        dsimp only; intro hnt
        have hr := hyes t hc hi hwf hlen hR hP (by rw [hy]; exact hnt)
        rw [hy] at hr; exact hr
  · intro _; exact opDispatchChainPostR32_error s0 t

theorem HandlerRunA32.seq_ite_other_skip {F : Type} {s0 : PanSemStateFiniteExact 64 F}
    {P : PanSemStateFiniteExact 64 F → Prop} {charged : Bool}
    {cond : ExpHOL 64} {eid : MlS} {errExp : ExpHOL 64} {cont : ProgHOL 64}
    (hne : eid ≠ ofString "EvmErr")
    (hcont : HandlerRunA32 s0 P charged cont) :
    HandlerRunA32 s0 P charged (.seq (.ite cond (.raise eid errExp) .skip) cont) :=
  HandlerRunA32.seq_ite_nonfallthrough_skip (fun _ => by
      rw [evaluateHOLFiniteState_raise]; split
      · dsimp only; split <;> simp
      · simp)
    (HandlerRunA32.raise_other hne errExp) hcont

theorem HandlerRunA32.seq_ite_simple {F : Type} {s0 : PanSemStateFiniteExact 64 F}
    {charged : Bool} {cond : ExpHOL 64} {yes no cont : ProgHOL 64}
    (hyes : HandlerRunA32 s0 (fun _ => True) charged (.seq yes cont))
    (hno : HandlerRunA32 s0 (fun _ => True) charged (.seq no cont)) :
    HandlerRunA32 s0 (fun _ => True) charged (.seq (.ite cond yes no) cont) := by
  intro t hc hi hwf hlen hR _ hnt
  rw [evaluateHOLFiniteState_seq_line780, evaluateHOLFiniteState_ite] at hnt ⊢
  revert hnt
  split
  · rename_i w hw
    by_cases hw0 : w = 0
    · subst hw0; simp only [↓reduceIte]
      rw [← evaluateHOLFiniteState_seq_line780]
      intro hnt; exact hno t hc hi hwf hlen hR trivial hnt
    · simp only [hw0, ↓reduceIte]
      rw [← evaluateHOLFiniteState_seq_line780]
      intro hnt; exact hyes t hc hi hwf hlen hR trivial hnt
  · intro _; exact opDispatchChainPostR32_error s0 t

theorem HandlerRunA32.seq_decCall_call_simple {F : Type} {s0 : PanSemStateFiniteExact 64 F}
    {Q1 Q2 : ∀ {F : Type}, PanSemStateFiniteExact 64 F → ValueHOL 64 → PanSemStateFiniteExact 64 F → Prop}
    {charged : Bool}
    {nm : MlS} {sh : ShapeHOL} {fn1 fn2 : MlS} {args1 args2 : List (ExpHOL 64)} {cont : ProgHOL 64}
    (hf1 : EvmPreservingSpecA32 (fun _ => True) Q1 fn1)
    (hf2 : EvmPreservingSpecA32 (fun _ => True) Q2 fn2)
    (hcont : HandlerRunA32 s0 (fun _ => True) charged cont) :
    HandlerRunA32 s0 (fun _ => True) charged
      (.seq (.decCall nm sh fn1 args1 (.call (some (none, none)) fn2 args2)) cont) := by
  intro t hc hi hwf hlen hR _ hnt
  obtain ⟨params1, body1, ret1, hlook1, hspec1⟩ := hf1
  rw [evaluateHOLFiniteState_seq_line780, evaluateHOLFiniteState_decCall_fixClockRewrite] at hnt ⊢
  rcases hargs1 : evalListHOLFinite t (h := fun a => Classical.propDecidable (t.memaddrs a)) args1 with _ | vals1
  · exact opDispatchChainPostR32_error s0 t
  · simp only [hargs1] at hnt ⊢
    rcases hl1 : lookupCodeHOLFinite t.code.lookup fn1 vals1 with _ | ⟨body1', callee1, ret1'⟩
    · exact opDispatchChainPostR32_error s0 t
    · simp only [hl1] at hnt ⊢
      by_cases hz1 : t.clock = 0
      · simp [hz1] at hnt
      · simp only [hz1, ↓reduceIte] at hnt ⊢
        have hb1 : body1' = body1 :=
          lookupCodeHOLFinite_installed_body t.code.lookup fn1 params1 body1 body1'
            ret1 ret1' vals1 callee1 (by rw [hc]; exact hlook1) hl1
        subst body1'
        have hr1 : ret1' = ret1 := by
          have hx := PanSemStateFiniteExact.lookupCodeHOLFinite_eq_some
            t.code.lookup fn1 vals1 body1 callee1 ret1' hl1
          rw [hc] at hx; simp only [Flapjack.lookupCodeHOLExact, hlook1] at hx
          split at hx
          · exact (congrArg (fun x => x.2.2) (Option.some.inj hx)).symm
          · cases hx
        subst ret1'
        have hInv_ce1 : EvmInvR32 (callEntryStateHOLFinite t callee1) :=
          localsFree_evmInvR32 t callee1 (t.clock - 1) hi
        have hWF_ce1 : HeadMemBridge.HeadMemChainWF (callEntryStateHOLFinite t callee1) :=
          HeadMemBridge.headMemChainWF_locals t callee1 (t.clock - 1) hwf
        have hl1_orig : lookupCodeHOLFinite originalRuntimeCode.lookup fn1 vals1 =
            some (body1, callee1, ret1) := by rwa [← hc]
        have hmeta1 := (PanRunBounded.evaluateHOLFiniteState_metadata
          (callEntryStateHOLFinite t callee1) body1).1
        rcases hrun1 : evaluateHOLFiniteState (callEntryStateHOLFinite t callee1) body1 with ⟨res1, cpost1⟩
        simp only [hrun1] at hnt hmeta1 ⊢
        change cpost1.code = t.code at hmeta1
        have hc_ce1 := R11Shards.OpDispatchSpec.evm_congr (s := t) (t := callEntryStateHOLFinite t callee1) rfl rfl
        have hQ1 (hsafe : res1 ≠ some .timeOut) :
            (∀ v, res1 = some (.returned v) →
              (EvmInvR32 cpost1 ∧ HeadMemBridge.HeadMemChainWF cpost1) ∧
              evmChain cpost1 = evmChain (callEntryStateHOLFinite t callee1) ∧
              evmR cpost1 ≤ evmR (callEntryStateHOLFinite t callee1) ∧
              Q1 (callEntryStateHOLFinite t callee1) v cpost1) ∧
            (IsEvmErr res1 →
              (EvmInvR32 cpost1 ∧ HeadMemBridge.HeadMemChainWF cpost1) ∧
              evmChain cpost1 = evmChain (callEntryStateHOLFinite t callee1) ∧
              evmR cpost1 ≤ evmR (callEntryStateHOLFinite t callee1)) := by
          have hs := hspec1 (callEntryStateHOLFinite t callee1) hc hInv_ce1 hWF_ce1 trivial
            ⟨vals1, hl1_orig⟩ (by rw [hrun1]; exact hsafe)
          dsimp only at hs; rw [hrun1] at hs; exact hs
        cases res1 with
        | none => exact opDispatchChainPostR32_error s0 cpost1
        | some r1 =>
          cases r1 with
          | timeOut => simp at hnt
          | returned v1 =>
            dsimp only at hnt ⊢
            by_cases hsh1 : (shapeEqHOL (shapeOfHOLExact v1) sh && shapeEqHOL (shapeOfHOLExact v1) ret1) = true
            · rw [if_pos hsh1] at hnt ⊢
              dsimp only at hnt ⊢
              obtain ⟨⟨hInv_cp1, hWF_cp1⟩, hch_cp1, hR_cp1, _⟩ := (hQ1 (by simp)).1 v1 rfl
              let u := setVarHOLFinite nm v1 { cpost1 with locals := t.locals }
              have hcode_u : u.code = originalRuntimeCode := hmeta1.trans hc
              have hInv_u : EvmInvR32 u := localsFree_evmInvR32 cpost1 u.locals cpost1.clock hInv_cp1
              have hWF_u : HeadMemBridge.HeadMemChainWF u :=
                HeadMemBridge.headMemChainWF_locals cpost1 u.locals cpost1.clock hWF_cp1
              have hc_u := R11Shards.OpDispatchSpec.evm_congr (s := cpost1) (t := u) rfl rfl
              have hlen_u : (evmChain u).length = (evmChain s0).length := by
                rw [hc_u.2.2.1, hch_cp1, hc_ce1.2.2.1]; exact hlen
              have hR_u : if charged then evmR u < evmR s0 else evmR u ≤ evmR s0 :=
                rboundA32_step
                (by
                  have h1 : Wave8GuestInv.evmR u = Wave8GuestInv.evmR cpost1 := hc_u.2.1
                  have h2 : Wave8GuestInv.evmR (t.callEntryStateHOLFinite callee1) =
                      Wave8GuestInv.evmR t := hc_ce1.2.1
                  have h3 := hR_cp1
                  omega) hR
              have hcall_ret : HandlerRunA32 s0 (fun _ => True) charged
                  (.seq (.call (some (none, none)) fn2 args2) (.raise (ofString "EvmErr") (.const 0))) :=
                HandlerRunA32.seq_call_simple hf2 (HandlerRunA32.raise_evmErr (.const 0))
              obtain ⟨params2, body2, ret2, hlook2, hspec2⟩ := hf2
              have hfold_u : setVarHOLFinite nm v1 { cpost1 with locals := t.locals } = u := rfl
              rw [hfold_u] at hnt ⊢
              rcases hev2 : evaluateHOLFiniteState u (.call (some (none, none)) fn2 args2) with ⟨r2, sp2⟩
              simp only [hev2] at hnt ⊢
              cases r2 with
              | some rr =>
                dsimp only at hnt ⊢
                have hcall := hcall_ret u hcode_u hInv_u hWF_u hlen_u hR_u trivial
                rw [evaluateHOLFiniteState_seq_line780, hev2] at hcall
                dsimp only at hcall
                exact opDispatchChainPostR32_congr_lcl rfl (hcall hnt)
              | none =>
                dsimp only at hnt ⊢
                rw [evaluateHOLFiniteState_call] at hev2
                rcases hargs2 : evalListHOLFinite u (h := fun a => Classical.propDecidable (u.memaddrs a)) args2 with _ | vals2
                · rw [hargs2] at hev2; simp at hev2
                · rw [hargs2] at hev2; dsimp only at hev2
                  rcases hl2 : lookupCodeHOLFinite u.code.lookup fn2 vals2 with _ | ⟨body2', callee2, ret2'⟩
                  · rw [hl2] at hev2; simp at hev2
                  · rw [hl2] at hev2; dsimp only at hev2
                    by_cases hz2 : u.clock = 0
                    · rw [if_pos hz2] at hev2; simp at hev2
                    · rw [if_neg hz2] at hev2
                      have hb2 : body2' = body2 :=
                        lookupCodeHOLFinite_installed_body u.code.lookup fn2 params2 body2 body2'
                          ret2 ret2' vals2 callee2 (by rw [hcode_u]; exact hlook2) hl2
                      subst body2'
                      have hr2 : ret2' = ret2 := by
                        have hx := PanSemStateFiniteExact.lookupCodeHOLFinite_eq_some
                          u.code.lookup fn2 vals2 body2 callee2 ret2' hl2
                        rw [hcode_u] at hx; simp only [Flapjack.lookupCodeHOLExact, hlook2] at hx
                        split at hx
                        · exact (congrArg (fun x => x.2.2) (Option.some.inj hx)).symm
                        · cases hx
                      subst ret2'
                      have hInv_ce2 : EvmInvR32 (callEntryStateHOLFinite u callee2) :=
                        localsFree_evmInvR32 u callee2 (u.clock - 1) hInv_u
                      have hWF_ce2 : HeadMemBridge.HeadMemChainWF (callEntryStateHOLFinite u callee2) :=
                        HeadMemBridge.headMemChainWF_locals u callee2 (u.clock - 1) hWF_u
                      have hl2_orig : lookupCodeHOLFinite originalRuntimeCode.lookup fn2 vals2 =
                          some (body2, callee2, ret2) := by rwa [← hcode_u]
                      have hmeta2 := (PanRunBounded.evaluateHOLFiniteState_metadata
                        (callEntryStateHOLFinite u callee2) body2).1
                      rcases hrun2 : evaluateHOLFiniteState (callEntryStateHOLFinite u callee2) body2 with ⟨res2, cpost2⟩
                      rw [hrun2] at hev2 hmeta2
                      change cpost2.code = u.code at hmeta2
                      cases res2 with
                      | none => simp at hev2
                      | some rr2 =>
                        cases rr2 with
                        | returned v2 =>
                          dsimp only at hev2
                          split at hev2
                          · injection hev2 with _ hsp2
                            subst sp2
                            have hs2 := hspec2 (callEntryStateHOLFinite u callee2) hcode_u hInv_ce2
                              hWF_ce2 trivial ⟨vals2, hl2_orig⟩ (by rw [hrun2]; simp)
                            dsimp only at hs2; rw [hrun2] at hs2; dsimp only at hs2
                            obtain ⟨⟨hInv_cp2, hWF_cp2⟩, hch_cp2, hR_cp2, _⟩ := hs2.1 v2 rfl
                            have hc_ce2 := R11Shards.OpDispatchSpec.evm_congr (s := u) (t := callEntryStateHOLFinite u callee2) rfl rfl
                            let restored : PanSemStateFiniteExact 64 F :=
                              { cpost2 with locals := HolFiniteMapExact.resVarEq u.locals (nm, t.locals.lookup nm) }
                            have hcode_rest : restored.code = originalRuntimeCode := hmeta2.trans hcode_u
                            have hInv_rest : EvmInvR32 restored :=
                              localsFree_evmInvR32 cpost2 restored.locals cpost2.clock hInv_cp2
                            have hWF_rest : HeadMemBridge.HeadMemChainWF restored :=
                              HeadMemBridge.headMemChainWF_locals cpost2 restored.locals cpost2.clock hWF_cp2
                            have hc_rest := R11Shards.OpDispatchSpec.evm_congr (s := cpost2) (t := restored) rfl rfl
                            have hlen_rest : (evmChain restored).length = (evmChain s0).length := by
                              rw [hc_rest.2.2.1, hch_cp2, hc_ce2.2.2.1]; exact hlen_u
                            have hR_rest : if charged then evmR restored < evmR s0 else evmR restored ≤ evmR s0 := by
                              have h1 : Wave8GuestInv.evmR restored = Wave8GuestInv.evmR cpost2 := hc_rest.2.1
                              have h2 : Wave8GuestInv.evmR (u.callEntryStateHOLFinite callee2) =
                                Wave8GuestInv.evmR u := hc_ce2.2.1
                              have h3 : Wave8GuestInv.evmR cpost2 ≤
                                  Wave8GuestInv.evmR (u.callEntryStateHOLFinite callee2) := hR_cp2
                              have hle : Wave8GuestInv.evmR restored ≤ Wave8GuestInv.evmR u := by
                                rw [h1]; exact h3.trans (le_of_eq h2)
                              exact rboundA32_step hle hR_u
                            exact hcont restored hcode_rest hInv_rest hWF_rest hlen_rest hR_rest trivial hnt
                          · simp at hev2
                        | timeOut | exception _ _ | «break» | «continue» | finalFfi _ | error => simp at hev2
            · rw [if_neg hsh1] at hnt ⊢
              exact opDispatchChainPostR32_error s0 cpost1
          | exception eid ev =>
            by_cases heid : eid = ofString "EvmErr"
            · subst heid
              obtain ⟨⟨hInv_cp1, hWF_cp1⟩, hch_cp1, hR_cp1⟩ := (hQ1 (by simp)).2 ⟨ev, rfl⟩
              have hInv_el : EvmInvR32 cpost1.emptyLocalsHOLFinite :=
                localsFree_evmInvR32 cpost1 _ cpost1.clock hInv_cp1
              have hWF_el : HeadMemBridge.HeadMemChainWF cpost1.emptyLocalsHOLFinite :=
                HeadMemBridge.headMemChainWF_locals cpost1 _ cpost1.clock hWF_cp1
              have hc_el := R11Shards.OpDispatchSpec.evm_congr (s := cpost1) (t := cpost1.emptyLocalsHOLFinite) rfl rfl
              refine ⟨?_, fun _ => ⟨⟨hInv_el, hWF_el⟩, ?_, ?_⟩⟩
              · rintro ⟨_, h⟩; cases h
              · rw [hc_el.2.2.1, hch_cp1, hc_ce1.2.2.1]; exact hlen
              · dsimp only
                have h0 := rboundA32_to_le hR
                have h1 : Wave8GuestInv.evmR cpost1.emptyLocalsHOLFinite =
                    Wave8GuestInv.evmR cpost1 := hc_el.2.1
                have h2 : Wave8GuestInv.evmR (t.callEntryStateHOLFinite callee1) =
                    Wave8GuestInv.evmR t := hc_ce1.2.1
                have h3 := hR_cp1
                omega
            · refine opDispatchChainPostR32_other (fun _ h => by cases h) ?_
              rintro ⟨_, h⟩; injection h with h'; injection h' with h1 _; exact heid h1
          | «break» => exact opDispatchChainPostR32_error s0 cpost1
          | «continue» => exact opDispatchChainPostR32_error s0 cpost1
          | finalFfi _ =>
            refine opDispatchChainPostR32_other (fun _ h => by cases h) ?_
            rintro ⟨_, h⟩; cases h
          | error => exact opDispatchChainPostR32_error s0 cpost1.emptyLocalsHOLFinite

/-! ## 4. Master witness-DB lemma for untyped-global-buffer writes

The `u256_*`/keccak callee family writes only inside `untypedGlobalBufIvls s` (the
`u256_ws`, `sk_buf`, `keccak_pad`, `keccak_st`, `mpt_nib_scratch` global buffers) and keeps
every global.  For such a step the witness-DB witness `(S, Nd)` of the pre-state survives
verbatim: the db table, the typed tables, the fixed objects and the trie nodes are all
disjoint from the global buffers, so every protected cell is unhit, and
`EvmBase.worldTypedWith_congr_w1` rebuilds `WorldTypedWith post S Nd` from
`SameTypedCells`. -/

/-- `globN` is bounded by `2 ^ 64` (it is the `toNat` of a 64-bit word). -/
theorem globN_lt {F : Type} (s : PanSemStateFiniteExact 64 F) (name : String) :
    globN s name < 2 ^ 64 := by
  unfold globN
  split
  · exact BitVec.isLt _
  · decide

/-- `Disj` between two global-buffer regions at distinct `globalBuffers` indices (a copy of
the private `FrameBase.globalBuffers_idx_disj`). -/
theorem globalBuffers_idx_disj' {F : Type} {s : PanSemStateFiniteExact 64 F}
    (hF : FixedTyped s) {i1 i2 : Nat}
    (h1 : i1 < globalBuffers.length) (h2 : i2 < globalBuffers.length) (hne : i1 ≠ i2) :
    let g1 := globalBuffers[i1]
    let g2 := globalBuffers[i2]
    Disj (globN s g1.1, if globN s g1.1 = 0 then 0 else g1.2)
         (globN s g2.1, if globN s g2.1 = 0 then 0 else g2.2) := by
  have hpw := hF.2
  unfold fixedObjects at hpw
  have hpw1 := (List.pairwise_append.1 (List.pairwise_append.1
    (List.pairwise_append.1 hpw).1).1).1
  have hlen : (globalBuffers.map fun gn =>
      (globN s gn.1, if globN s gn.1 = 0 then 0 else gn.2)).length =
      globalBuffers.length := List.length_map _
  rcases Nat.lt_or_gt_of_ne hne with hlt | hgt
  · have := List.pairwise_iff_getElem.1 hpw1 i1 i2 (by rw [hlen]; exact h1)
      (by rw [hlen]; exact h2) hlt
    simpa [List.getElem_map] using this
  · have := List.pairwise_iff_getElem.1 hpw1 i2 i1 (by rw [hlen]; exact h2)
      (by rw [hlen]; exact h1) hgt
    exact R11Shards.Disj.symm (by simpa [List.getElem_map] using this)

/-- Every `untypedGlobalBufIvls` region is one of the five untyped global buffers. -/
theorem untypedGlobalBufIvls_map_mem {F : Type} {s : PanSemStateFiniteExact 64 F} {x : Ivl}
    (hx : x ∈ untypedGlobalBufIvls s) :
    x ∈ globalBuffers.map (fun gn => (globN s gn.1, if globN s gn.1 = 0 then 0 else gn.2)) := by
  unfold untypedGlobalBufIvls at hx
  simp only [List.map, List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl
  · exact List.mem_map.2 ⟨("u256_ws", 640), by decide, rfl⟩
  · exact List.mem_map.2 ⟨("sk_buf", 64), by decide, rfl⟩
  · exact List.mem_map.2 ⟨("keccak_pad", 136), by decide, rfl⟩
  · exact List.mem_map.2 ⟨("keccak_st", 200), by decide, rfl⟩
  · exact List.mem_map.2 ⟨("mpt_nib_scratch", 64), by decide, rfl⟩

theorem untypedGlobalBufIvls_fix {F : Type} {s : PanSemStateFiniteExact 64 F} {x : Ivl}
    (hx : x ∈ untypedGlobalBufIvls s) : x ∈ fixedObjects s := by
  unfold fixedObjects
  exact List.mem_append_left _ (List.mem_append_left _ (List.mem_append_left _
    (untypedGlobalBufIvls_map_mem hx)))

theorem untypedGlobalBufIvls_aligned {F : Type} {s : PanSemStateFiniteExact 64 F}
    (hF : FixedTyped s) {x : Ivl} (hx : x ∈ untypedGlobalBufIvls s) : x.1 % 8 = 0 := by
  rcases hF.1 x (untypedGlobalBufIvls_fix hx) with h0 | ⟨_, hw⟩
  · obtain ⟨gn, hgn_m, rfl⟩ := List.mem_map.1 (untypedGlobalBufIvls_map_mem hx)
    have hpos : 0 < gn.2 := by clear * - hgn_m; revert gn hgn_m; decide
    dsimp only at h0 ⊢
    by_cases hz : globN s gn.1 = 0
    · simp [hz]
    · simp [hz] at h0; omega
  · exact hw.1

/-- A byte-region effect whose write regions are disjoint from `i` (and aligned) leaves
every aligned cell of `i` unhit. -/
theorem ivlUnhit_of_bre {F : Type} {s post : PanSemStateFiniteExact 64 F} {Rl : List Ivl}
    (heff : ByteRegionEffect s post Rl) {i : Ivl}
    (hal : ∀ x ∈ Rl, x.1 % 8 = 0) (hdisj : ∀ x ∈ Rl, Disj i x) :
    InitECandidate.Solver.Wave8Contracts.M08.IvlUnhit s post i := by
  intro a ha8 hlo hhi
  refine heff.cell_frame a fun x hx => ?_
  intro hc
  obtain ⟨hA, hB⟩ := hc
  have hx8 := hal x hx
  rcases hdisj x hx with h1 | h1 | h1 | h1 <;> omega

/-- The untyped global buffers are disjoint from every `worldTypedIvls` region. -/
theorem untypedGlobalBufIvls_disj_worldTypedIvls {F : Type}
    {s : PanSemStateFiniteExact 64 F} {S Nd : List Nat} (hWT : WorldTypedWith s S Nd)
    {x : Ivl} (hx : x ∈ untypedGlobalBufIvls s) {i : Ivl}
    (hi : i ∈ worldTypedIvls s S Nd) : i.2 = 0 ∨ Disj x i := by
  have hx_map := untypedGlobalBufIvls_map_mem hx
  have hx_fix : x ∈ fixedObjects s := untypedGlobalBufIvls_fix hx
  have hx_idx : ∃ idx : Nat, ∃ h : idx < globalBuffers.length,
      idx ∈ ([43, 38, 23, 25, 28] : List Nat) ∧
      x = (globN s globalBuffers[idx].1, if globN s globalBuffers[idx].1 = 0 then 0
        else globalBuffers[idx].2) := by
    unfold untypedGlobalBufIvls at hx
    simp only [List.map, List.mem_cons, List.not_mem_nil, or_false] at hx
    rcases hx with rfl | rfl | rfl | rfl | rfl
    · exact ⟨43, by decide, by simp, rfl⟩
    · exact ⟨38, by decide, by simp, rfl⟩
    · exact ⟨23, by decide, by simp, rfl⟩
    · exact ⟨25, by decide, by simp, rfl⟩
    · exact ⟨28, by decide, by simp, rfl⟩
  have htr_idx : ∀ r ∈ typedRecords,
      ∃ idx2 : Nat, ∃ h : idx2 < globalBuffers.length,
        idx2 ∈ ([46, 11, 42, 10] : List Nat) ∧ r = globalBuffers[idx2] := by
    intro r hr
    simp only [typedRecords, List.mem_cons, List.not_mem_nil, or_false] at hr
    rcases hr with rfl | rfl | rfl | rfl
    · exact ⟨46, by decide, by simp, rfl⟩
    · exact ⟨11, by decide, by simp, rfl⟩
    · exact ⟨42, by decide, by simp, rfl⟩
    · exact ⟨10, by decide, by simp, rfl⟩
  obtain ⟨idx1, hidx1, hmem1, hxeq⟩ := hx_idx
  obtain ⟨hpw_123, _, hrel_bal⟩ := List.pairwise_append.1 hWT.2.2.1.2
  obtain ⟨hpw_12, _, hrel_bo⟩ := List.pairwise_append.1 hpw_123
  obtain ⟨_, _, hrel_jrn⟩ := List.pairwise_append.1 hpw_12
  unfold worldTypedIvls at hi
  simp only [List.mem_append] at hi
  rcases hi with ((((h1 | h2) | h3) | h4) | h5) | h6
  · obtain ⟨t, ht, hfp⟩ := List.mem_flatMap.1 h1
    exact Or.inr (R11Shards.Disj.symm (((hWT.1.2.1 t ht).2 i hfp).2 x hx_fix))
  · obtain ⟨r, hr, rfl⟩ := List.mem_map.1 h2
    obtain ⟨idx2, hidx2, hmem2, rfl⟩ := htr_idx r hr
    have hne : idx1 ≠ idx2 := by clear * - hmem1 hmem2; revert idx1 idx2 hmem1 hmem2; decide
    rw [hxeq]
    exact Or.inr (globalBuffers_idx_disj' hWT.2.2.1 hidx1 hidx2 hne)
  · simp only [List.mem_singleton] at h3; subst h3
    exact Or.inr (hrel_jrn x hx_map _ (List.mem_singleton.2 rfl))
  · exact Or.inr (hrel_bo x (List.mem_append_left _ hx_map) i h4)
  · exact Or.inr (hrel_bal x (List.mem_append_left _ (List.mem_append_left _ hx_map)) i h5)
  · exact Or.inr (R11Shards.Disj.symm ((hWT.2.2.2.2.1 i h6).2 x hx_fix))

/-- The `vm_system_address` `Inside` conjunct of `EvmInvR32` transfers across equal
globals. -/
theorem sysInside_congr_globals {F : Type} {s post : PanSemStateFiniteExact 64 F}
    (hglob : post.globals = s.globals)
    (hsys : Inside (globN s "vm_system_address", 20) sourceBase (globN s "heap_ptr")) :
    Inside (globN post "vm_system_address", 20) sourceBase (globN post "heap_ptr") := by
  have h1 : globN post "vm_system_address" = globN s "vm_system_address" := by
    unfold globN; rw [hglob]
  have h2 : globN post "heap_ptr" = globN s "heap_ptr" := by unfold globN; rw [hglob]
  rw [h1, h2]; exact hsys

/-- Master lemma: an `untypedGlobalBufIvls`-confined, globals-keeping byte-region effect
preserves the witness DB with the same witness `(S, Nd)`. -/
theorem witnessDbOK_of_untypedGlobalBufs {F : Type}
    {s post : PanSemStateFiniteExact 64 F}
    (hAs : ArenaReady s) (hdb : StorageCreateFinish.WitnessDbOK s)
    (heff : ByteRegionEffect s post (untypedGlobalBufIvls s))
    (hApost : ArenaReady post) : StorageCreateFinish.WitnessDbOK post := by
  obtain ⟨S, Nd, hWT, hdbAt⟩ := hdb
  -- write-region facts
  have hfix : ∀ x ∈ untypedGlobalBufIvls s, x ∈ fixedObjects s :=
    fun x hx => untypedGlobalBufIvls_fix hx
  have hRl8 : ∀ x ∈ untypedGlobalBufIvls s, x.1 % 8 = 0 :=
    fun x hx => untypedGlobalBufIvls_aligned hWT.2.2.1 hx
  have hdisj_wti : ∀ x ∈ untypedGlobalBufIvls s, ∀ i ∈ worldTypedIvls s S Nd,
      i.2 = 0 ∨ Disj x i := fun x hx i hi =>
    untypedGlobalBufIvls_disj_worldTypedIvls hWT hx hi
  -- SameTypedCells
  have hcell : SameTypedCells s post S Nd :=
    ByteRegionEffect.sameTypedCells (Rl := []) (extra := untypedGlobalBufIvls s)
      hAs.1.memaddrs hWT (fun _ h => by simp at h) hdisj_wti (by simpa using heff)
  -- globals kept
  have hglob : post.globals = s.globals := heff.globals
  have hglobN : ∀ name, globN post name = globN s name := fun name => by
    unfold globN; rw [hglob]
  -- fixedObjects post = fixedObjects s, FixedTyped post, WorldTypedWith post
  have hke : ∀ name : String, name ≠ "heap_ptr" → name ≠ "scratch_ptr" →
      name ≠ "frame_mem_ptr" →
      s.globals.lookup (ofString name) = post.globals.lookup (ofString name) := by
    intro name _ _ _; rw [hglob]
  have hfo_eq : fixedObjects post = fixedObjects s :=
    InitECandidate.Solver.Wave8Contracts.M23.fixedObjects_eq_of_nonHeapGlobalsKept
      hAs.2 hWT.1 hWT.2.2.1 hcell hke
  have hFT_post : FixedTyped post :=
    InitECandidate.Solver.Wave8Contracts.M23.fixedTyped_of_eq hApost hWT.2.2.1
      (le_of_eq (hglobN "heap_ptr").symm)
      (le_of_eq (hglobN "scratch_ptr")) hfo_eq
  obtain ⟨hWT_post, _⟩ :=
    InitECandidate.Solver.Wave8Contracts.M23.worldTypedWith_congr_w1 hAs hApost
    (le_of_eq (hglobN "heap_ptr").symm) (le_of_eq (hglobN "scratch_ptr"))
    (fun g _ => hglobN g) hcell hWT
    ⟨hFT_post, fun o ho => Or.inl (by rw [← hfo_eq]; exact ho)⟩
  refine ⟨S, Nd, hWT_post, ?_⟩
  intro hws
  rw [hglobN "ws"] at hws ⊢
  dsimp only
  intro hnz
  set db := memW s (globN s "ws")
  have hrec_ws : (globN s "ws", if globN s "ws" = 0 then 0 else 40) ∈
      worldTypedIvls s S Nd := by
    unfold worldTypedIvls
    exact List.mem_append_left _ (List.mem_append_left _ (List.mem_append_left _
      (List.mem_append_left _ (List.mem_append_right _
        (List.mem_map.2 ⟨("ws", 40), by simp [typedRecords], rfl⟩)))))
  have hdb_eq : memW post (globN s "ws") = db :=
    memW_eq_of_cellHits hcell (globN_lt s "ws") hrec_ws
      ⟨by dsimp only; omega, by dsimp only; simp only [if_neg hws]; omega⟩
  rw [hdb_eq] at hnz ⊢
  obtain ⟨hwf, hk, hfp_in, hdisj, hvals⟩ := hdbAt hws hnz
  -- unhit facts for db, the S-tables and the witness slices
  have hu_db : ∀ i ∈ htabFootprint s db,
      InitECandidate.Solver.Wave8Contracts.M08.IvlUnhit s post i := by
    intro i hi
    exact ivlUnhit_of_bre heff hRl8 fun x hx =>
      hdisj i hi x (List.mem_append_left _ (List.mem_append_right _ (hfix x hx)))
  have hu_S : ∀ t ∈ S, ∀ i ∈ htabFootprint s t,
      InitECandidate.Solver.Wave8Contracts.M08.IvlUnhit s post i := by
    intro t ht i hi
    exact ivlUnhit_of_bre heff hRl8 fun x hx =>
      ((hWT.1.2.1 t ht).2 i hi).2 x (hfix x hx)
  have hu_v : ∀ v ∈ htabValues s db,
      InitECandidate.Solver.Wave8Contracts.M08.IvlUnhit s post (v, 16) := by
    intro v hv
    exact ivlUnhit_of_bre heff hRl8 fun x hx =>
      (hvals v hv).2 x (List.mem_append_left _ (List.mem_append_right _ (hfix x hx)))
  -- footprint / values / extents equalities
  have ht_fp : (db, 88) ∈ htabFootprint s db := by simp [htabFootprint]
  have hdb8 : db % 8 = 0 := (hwf.1 _ ht_fp).2.1
  have hhe : heapEnd ≤ 2 ^ 64 := by decide
  have hhdr_hi : db + 88 ≤ 2 ^ 64 := by
    have h := (hwf.1 _ ht_fp).1.2; dsimp only at h; omega
  obtain ⟨hhdr, hfp_eq⟩ :=
    InitECandidate.Solver.Wave8Contracts.M08.htabFootprint_eq_of_hdr_unhit hdb8 hhdr_hi
      (hu_db _ ht_fp)
  have hvals_eq : htabValues post db = htabValues s db :=
    InitECandidate.Solver.Wave8Contracts.M08.htabValues_eq_of_unhit hwf hu_db
  have hfp_S : ∀ t ∈ S, htabFootprint post t = htabFootprint s t := by
    intro t ht
    have ht_fp : (t, 88) ∈ htabFootprint s t := by simp [htabFootprint]
    have ht8 : t % 8 = 0 := ((hWT.1.2.1 t ht).1.1 _ ht_fp).2.1
    have hthi : t + 88 ≤ 2 ^ 64 := by
      have h := ((hWT.1.2.1 t ht).1.1 _ ht_fp).1.2; dsimp only at h; omega
    exact (InitECandidate.Solver.Wave8Contracts.M08.htabFootprint_eq_of_hdr_unhit ht8 hthi
      (hu_S t ht _ ht_fp)).2
  have hflat_eq : S.flatMap (htabFootprint post) = S.flatMap (htabFootprint s) :=
    List.flatMap_congr hfp_S
  have hne_eq : nodeExtents post Nd = nodeExtents s Nd :=
    InitECandidate.Solver.Wave8Contracts.M23.nodeExtents_eq hWT.2.2.2.1 hcell
  have hwo_eq : worldOwned post S Nd = worldOwned s S Nd := by
    unfold worldOwned
    rw [hflat_eq, hfo_eq, hne_eq]
  -- the five WitnessDbAt-post components
  refine ⟨InitECandidate.Solver.Wave8Contracts.M08.htabWF_congr_unhit hAs.1 hApost.1 hwf hu_db,
    ?_, ?_, ?_, ?_⟩
  · rw [hhdr 0 (by omega)]; exact hk
  · intro i hi
    rw [hfp_eq] at hi
    exact ⟨(hfp_in i hi).1, le_trans (hfp_in i hi).2 (le_of_eq (hglobN "heap_ptr").symm)⟩
  · intro i hi o ho
    rw [hfp_eq] at hi
    rw [hwo_eq] at ho
    exact hdisj i hi o ho
  · intro v hv
    rw [hvals_eq] at hv
    obtain ⟨hv_ok, hv_disj⟩ := hvals v hv
    have hhe : heapEnd ≤ 2 ^ 64 := by decide
    have hlim : heapLimit ≤ heapEnd := by decide
    have hhp_le : globN s "heap_ptr" ≤ heapLimit := hAs.2.2.1
    have hv_hi : v + 16 ≤ 2 ^ 64 := by
      have h2 := hv_ok.2.1.2; omega
    have hv8 : v % 8 = 0 := hv_ok.1.1
    refine ⟨StorageCreateFinish.witnessSliceOK_of_preserved hv_ok
      (InitECandidate.Solver.Wave8Contracts.M08.wordsOK_transfer hAs.1 hApost.1 hv_ok.1)
      (le_of_eq (hglobN "heap_ptr").symm)
      (InitECandidate.Solver.Wave8Contracts.M08.memW_eq_of_ivlUnhit (hu_v v hv) hv8 hv_hi
        (by dsimp only; omega))
      (InitECandidate.Solver.Wave8Contracts.M08.memW_eq_of_ivlUnhit (hu_v v hv) (by omega)
        hv_hi (by dsimp only; omega)),
      fun j hj => by rw [hwo_eq] at hj; exact hv_disj j hj⟩

/-! ## 5. `EvmInvR32`-strength callee lifts -/

/-- Read-only callees at `EvmPreservingSpecA32` strength: the evaluation is a pure
locals/clock update of the entry state, so `EvmInvR32`, the bridge chain-WF, the chain,
`evmR`, and `LocFrame` are preserved. -/
theorem epsA32_of_readOnly (i : Nat) (hi : i < Guest.Software.guestAst.length)
    (d : Decl (BitVec 64)) (hd : Guest.Software.guestAst[i] = .function (extractFn d))
    (good : MlS → Bool)
    (hgood : ∀ function, good function = true → ∀ values body callee rs,
      PanSemStateFiniteExact.lookupCodeHOLFinite originalRuntimeCode.lookup function values =
        some (body, callee, rs) → readOnlyProg good body = true)
    (hbody : readOnlyProg good
      (InitECandidate.Solver.FrontendCodecComputation.progToHOLStructural (extractFn d).body) = true) :
    EvmPreservingSpecA32 (fun _ => True) (fun s _ post => LocFrame s post)
      (ofString (extractFn d).name) := by
  refine ⟨_, _, _, lookup_of_guestAst_getElem i hi (extractFn d) hd, ?_⟩
  intro F s hcode hInv hWF _ hlkv _
  have hsafe := evaluate_readOnlyProg good hgood _ hbody s hcode
  have hres (hr : Resumes (evaluateHOLFiniteState s
      (InitECandidate.Solver.FrontendCodecComputation.progToHOLStructural (extractFn d).body)).1) :
      let post := (evaluateHOLFiniteState s
        (InitECandidate.Solver.FrontendCodecComputation.progToHOLStructural (extractFn d).body)).2
      (EvmInvR32 post ∧ HeadMemBridge.HeadMemChainWF post) ∧
        evmChain post = evmChain s ∧ OpDispatchSpec.evmR post ≤ OpDispatchSpec.evmR s ∧
        LocFrame s post := by
    have hlf := hsafe.to_resumes hr
    dsimp only
    let post := (evaluateHOLFiniteState s
      (InitECandidate.Solver.FrontendCodecComputation.progToHOLStructural (extractFn d).body)).2
    have hInv_p : EvmInvR32 post := by
      have h := localsFree_evmInvR32 s post.locals post.clock hInv
      rwa [← hlf] at h
    have hWF_p : HeadMemBridge.HeadMemChainWF post := by
      have h := HeadMemBridge.headMemChainWF_locals s post.locals post.clock hWF
      rwa [← hlf] at h
    have hm : post.memory = s.memory := by
      change (evaluateHOLFiniteState s
        (InitECandidate.Solver.FrontendCodecComputation.progToHOLStructural (extractFn d).body)).2.memory = s.memory
      conv_lhs => rw [hlf]
    have hg : post.globals = s.globals := by
      change (evaluateHOLFiniteState s
        (InitECandidate.Solver.FrontendCodecComputation.progToHOLStructural (extractFn d).body)).2.globals = s.globals
      conv_lhs => rw [hlf]
    have hc := evm_congr hm hg
    have hRe : OpDispatchSpec.evmR post = OpDispatchSpec.evmR s := hc.2.1
    exact ⟨⟨hInv_p, hWF_p⟩, evmChain_congr hm hg, le_of_eq hRe, hlf⟩
  refine ⟨fun v hv => hres (Or.inl ⟨v, hv⟩), fun ⟨v, hv⟩ => ?_⟩
  obtain ⟨h1, h2, h3, _⟩ := hres (Or.inr ⟨_, v, hv, by decide⟩)
  exact ⟨h1, h2, h3⟩

/-- `WsSafe` callees at `EvmPreservingSpecA32` strength: an `untypedGlobalBufIvls`-confined,
globals-keeping byte-region effect preserves `EvmInvR32` (via `evmStepR_of_untypedGlobalBufs`
and `witnessDbOK_of_untypedGlobalBufs`) and the bridge chain-WF. -/
theorem epsA32_of_wsSafe (idx : Nat) (hidx : idx < Guest.Software.guestAst.length)
    (d : Decl (BitVec 64)) (hd : Guest.Software.guestAst[idx] = .function (extractFn d))
    (hbody : ∀ {F : Type} (s : PanSemStateFiniteExact 64 F),
      WsEnv s s →
      (∃ values, lookupCodeHOLFinite originalRuntimeCode.lookup
        (ofString (extractFn d).name) values =
          some (InitECandidate.Solver.FrontendCodecComputation.progToHOLStructural (extractFn d).body,
                s.locals,
                InitECandidate.Solver.FrontendCodecComputation.shapeToHOLStructural (extractFn d).returnShape)) →
      WsSafe s (untypedGlobalBufIvls s)
        (evaluateHOLFiniteState s
          (InitECandidate.Solver.FrontendCodecComputation.progToHOLStructural (extractFn d).body))) :
    EvmPreservingSpecA32 (fun _ => True) (fun _ _ _ => True)
      (ofString (extractFn d).name) := by
  refine ⟨_, _, _, lookup_of_guestAst_getElem idx hidx (extractFn d) hd, ?_⟩
  intro F s hcode hInv hWF _ hlkv _
  have hsafe := hbody s (WsEnv.of_evmInv hcode hInv.evmInv) hlkv
  have hres (hr : Resumes (evaluateHOLFiniteState s
      (InitECandidate.Solver.FrontendCodecComputation.progToHOLStructural (extractFn d).body)).1) :
      let post := (evaluateHOLFiniteState s
        (InitECandidate.Solver.FrontendCodecComputation.progToHOLStructural (extractFn d).body)).2
      (EvmInvR32 post ∧ HeadMemBridge.HeadMemChainWF post) ∧
        evmChain post = evmChain s ∧ OpDispatchSpec.evmR post ≤ OpDispatchSpec.evmR s := by
    dsimp only
    let post := (evaluateHOLFiniteState s
      (InitECandidate.Solver.FrontendCodecComputation.progToHOLStructural (extractFn d).body)).2
    have heff := hsafe.2 hr
    obtain ⟨hInv_p, hg, hch, hR⟩ := evmStepR_of_untypedGlobalBufs hInv.evmInv heff
    have hdb_p : StorageCreateFinish.WitnessDbOK post :=
      witnessDbOK_of_untypedGlobalBufs hInv.evmInv.1 hInv.witnessDbOK heff hInv_p.1
    have hsys_p := sysInside_congr_globals hg hInv.sysInside
    have hInvC := hInv.evmInv
    obtain ⟨hAs, S, hW, hrest⟩ := hInvC
    have hF : FixedTyped s := hW.2.2.1
    have hRl8 : ∀ i ∈ untypedGlobalBufIvls s, i.1 % 8 = 0 :=
      fun i hi => untypedGlobalBufIvls_aligned hF hi
    have hfix : ∀ x ∈ untypedGlobalBufIvls s, x ∈ fixedObjects s :=
      fun x hx => untypedGlobalBufIvls_fix hx
    have hdj_all : ∀ x ∈ untypedGlobalBufIvls s,
        ∀ j ∈ ((evmChain s).map (frameObjects s)).flatten, Disj x j := by
      intro x hx j hj
      have hx_fix := hfix x hx
      obtain ⟨fo, hfo_map, hj_fo⟩ := List.mem_flatten.1 hj
      obtain ⟨ec, hec, rfl⟩ := List.mem_map.1 hfo_map
      exact R11Shards.Disj.symm (((⟨hW, hrest⟩ : EvmInvAt s S).2.2.2.2.2.2.2.2.1 ec hec j hj_fo).2 x hx_fix)
    have hdj : ∀ ec ∈ evmChain s, ∀ i ∈ untypedGlobalBufIvls s,
        (i.2 = 0 ∨ Disj (ec.1, 280) i) ∧ (i.2 = 0 ∨ Disj (ec.2, 104) i) := by
      intro ec hec i hi
      have hm280 : (ec.1, 280) ∈ frameObjects s ec := by simp [frameObjects]
      have hm104 : (ec.2, 104) ∈ frameObjects s ec := by simp [frameObjects]
      exact ⟨Or.inr (R11Shards.Disj.symm (hdj_all i hi _ (List.mem_flatten.2 ⟨frameObjects s ec,
        List.mem_map.2 ⟨ec, hec, rfl⟩, hm280⟩))),
        Or.inr (R11Shards.Disj.symm (hdj_all i hi _ (List.mem_flatten.2 ⟨frameObjects s ec,
        List.mem_map.2 ⟨ec, hec, rfl⟩, hm104⟩)))⟩
    have hWF_p := Group09ChainWF.headMemChainWF_of_disj_bre hInv.evmInv
        ((headMemChainWF_g09_iff_bridge s).mpr hWF) hch
        (congrFun (globN_congr hg) "ev") (congrFun (globN_congr hg) "frame_mem_ptr")
        hRl8 heff.cell_frame hdj
    have hRe : OpDispatchSpec.evmR post = OpDispatchSpec.evmR s := hR
    exact ⟨⟨⟨hInv_p, hdb_p, hsys_p⟩, (headMemChainWF_g09_iff_bridge _).mp hWF_p⟩,
      hch, le_of_eq hRe⟩
  refine ⟨fun v hv => ?_, fun herr => ?_⟩
  · obtain ⟨h1, h2, h3⟩ := hres (Or.inl ⟨v, hv⟩)
    exact ⟨h1, h2, h3, trivial⟩
  · obtain ⟨v, hv⟩ := herr
    exact hres (Or.inr ⟨_, v, hv, by decide⟩)

/-! ## 6. Frame-write master lemma -/

/-- Every node extent (record and path) lies at or below `heapLimit`. -/
theorem nodeExtents_le_heapLimit {F : Type} {s : PanSemStateFiniteExact 64 F}
    {Nd : List Nat} (hNH : NodeHeap s Nd) :
    ∀ j ∈ nodeExtents s Nd, j.1 + j.2 ≤ heapLimit := by
  intro j hj
  obtain ⟨n, hn, hjm⟩ := List.mem_flatMap.1 hj
  rcases List.mem_cons.1 hjm with rfl | hjm
  · rcases hNH.1 n hn with ⟨_, _, hinside, _, _, _, _, _, _, _⟩
    exact hinside.2
  · obtain rfl := List.mem_singleton.1 hjm
    unfold nodePath
    split
    · rename_i hcond
      rcases hNH.1 n hn with ⟨_, _, _, _, _, _, hkey, _, _, _⟩
      have hk := hkey hcond.1
      rcases hk with _ | ⟨_, _, hins, _⟩
      · exact absurd hcond.2 (by omega)
      · exact hins.2
    · decide

/-- `worldOwned` grows with `S`. -/
theorem worldOwned_sub {F : Type} {s : PanSemStateFiniteExact 64 F}
    {S1 S2 Nd : List Nat} (hsub : ∀ t ∈ S1, t ∈ S2) :
    ∀ o ∈ worldOwned s S1 Nd, o ∈ worldOwned s S2 Nd := by
  intro o ho
  unfold worldOwned at ho ⊢
  rcases List.mem_append.1 ho with h | h
  · rcases List.mem_append.1 h with h | h
    · obtain ⟨t, ht, hfp⟩ := List.mem_flatMap.1 h
      exact List.mem_append.2 (Or.inl (List.mem_append.2
        (Or.inl (List.mem_flatMap.2 ⟨t, hsub t ht, hfp⟩))))
    · exact List.mem_append.2 (Or.inl (List.mem_append.2 (Or.inr h)))
  · exact List.mem_append.2 (Or.inr h)

/-- Master lemma (frame writes): a globals-keeping `ByteRegionEffect` whose regions are
confined to the head frame's scratch objects, or to scratch freshly allocated below the
entry `scratch_ptr`, preserves the witness DB. The post witness intersects the DB's `S_w`
with the `EvmInv` witness `S_at`: every table forced by the `TablesTyped`/`JournalTyped`
closure conditions (roots, nested tables, journal tables) lies in both sets, so the
intersection still satisfies `WorldTypedWith`, and all of its tables are frame-disjoint by
`EvmInvAt`'s frame component, hence unhit by the writes. -/
theorem witnessDbOK_of_frameWrites {F : Type}
    {s post : PanSemStateFiniteExact 64 F} {Rl : List Ivl}
    (hInv : EvmInv s) (hdb : StorageCreateFinish.WitnessDbOK s)
    (hApost : ArenaReady post) (heff : ByteRegionEffect s post Rl)
    (hRl8 : ∀ x ∈ Rl, x.1 % 8 = 0)
    (hRl_avoid : ∀ x ∈ Rl,
      (x ∈ frameObjects s (globN s "ev", globN s "cur_cont") ∧
        Inside x (globN s "scratch_ptr") scratchEnd) ∨
      Inside x (globN post "scratch_ptr") (globN s "scratch_ptr")) :
    StorageCreateFinish.WitnessDbOK post := by
  obtain ⟨hAs, S_at, hW_at, hch_ne, hch_len, hch_last, hFW_all, hFR_all, hRW,
    hFO_pw, hFO_disj, hAT, hMarks, hRoles, hGas⟩ := hInv
  obtain ⟨Nd_at, hTr_at, hAT_at⟩ := hAT
  obtain ⟨S_w, Nd_w, hWT_w, hdbAt_w⟩ := hdb
  have hhead_mem : (globN s "ev", globN s "cur_cont") ∈ evmChain s := by
    simp [evmChain, evmChainFrom]
  obtain ⟨hntw, htabw, hpww, hwsw, hbsw, htsw, hgrw, hbcw, htcw, hbalw, hbow, hrolesw⟩ := hWT_w.1
  obtain ⟨hnta, htaba, hpwa, hwsa, hbsa, htsa, hgra, hbca, htca, hbala, hboa, hrolesa⟩ := hW_at.1
  obtain ⟨hjw1, hjw2, hjw3, hjw4⟩ := hWT_w.2.1
  obtain ⟨hja1, hja2, hja3, hja4⟩ := hW_at.2.1
  have hNH_w : NodeHeap s Nd_w := hWT_w.2.2.2.1
  -- region bounds
  have hRl_hi : ∀ x ∈ Rl, heapLimit ≤ x.1 := by
    intro x hx
    have hss : scratchStart ≤ heapLimit := le_of_eq (by rfl)
    rcases (hRl_avoid x hx) with ⟨_, hins⟩ | hins
    · exact le_trans (le_trans (le_trans hss hAs.2.2.2.1) hAs.2.2.2.2.1) hins.1
    · exact le_trans (le_trans (le_trans hss hApost.2.2.2.1) hApost.2.2.2.2.1) hins.1
  -- globals
  have hglob : post.globals = s.globals := heff.globals
  have hglobN : ∀ name, globN post name = globN s name := fun name => by
    unfold globN; rw [hglob]
  have hhp : globN s "heap_ptr" ≤ globN post "heap_ptr" := le_of_eq (hglobN "heap_ptr").symm
  -- the post witness S' = S_w ∩ S_at
  obtain ⟨S', hS'_def⟩ : ∃ S', S' = S_w.filter (fun t => t ∈ S_at) := ⟨_, rfl⟩
  have hS'_mem : ∀ t ∈ S', t ∈ S_w ∧ t ∈ S_at := by
    intro t ht
    rw [hS'_def] at ht
    have h := List.mem_filter.1 ht
    exact ⟨h.1, of_decide_eq_true h.2⟩
  have hS'_nodup : S'.Nodup := by
    rw [hS'_def]; exact List.Nodup.filter _ hntw
  have hmem' : ∀ v, v ∈ S_w → v ∈ S_at → v ∈ S' := by
    intro v hw ha
    rw [hS'_def]
    exact List.mem_filter.2 ⟨hw, by simp [ha]⟩
  have hrootIn' : ∀ v, RootIn S_w v → RootIn S_at v → RootIn S' v := by
    intro v hvw hva
    rcases hva with rfl | ha
    · exact Or.inl rfl
    · rcases hvw with rfl | hw
      · exact Or.inl rfl
      · exact Or.inr (hmem' v hw ha)
  -- `WorldTypedWith s S' Nd_w`
  have hTT' : TablesTyped s S' := by
    refine ⟨hS'_nodup, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, hbow, ?_⟩
    · intro t ht
      exact htabw t (hS'_mem t ht).1
    · intro t ht u hu hne i hi j hj
      exact hpww t (hS'_mem t ht).1 u (hS'_mem u hu).1 hne i hi j hj
    · intro k hk hnz
      exact hrootIn' _ (hwsw k hk hnz) (hwsa k hk hnz)
    · intro k hk hnz
      exact hrootIn' _ (hbsw k hk hnz) (hbsa k hk hnz)
    · intro k hk hnz
      exact hrootIn' _ (htsw k hk hnz) (htsa k hk hnz)
    · intro g hg
      exact hrootIn' _ (hgrw g hg) (hgra g hg)
    · intro hnz hin
      have hw := hbcw hnz ((hS'_mem _ hin).1)
      have ha := hbca hnz ((hS'_mem _ hin).2)
      intro i hi
      exact hmem' _ (hw i hi) (ha i hi)
    · intro hnz hin
      have hw := htcw hnz ((hS'_mem _ hin).1)
      have ha := htca hnz ((hS'_mem _ hin).2)
      intro i hi
      exact hmem' _ (hw i hi) (ha i hi)
    · intro ad had
      obtain ⟨h1, h2, h3, h4⟩ := hbalw ad had
      obtain ⟨h1a, h2a, _, _⟩ := hbala ad had
      exact ⟨hmem' _ h1 h1a, hmem' _ h2 h2a, h3, h4⟩
    · obtain ⟨hr1, hr2, hr3⟩ := hrolesw
      obtain ⟨hra1, _, _⟩ := hrolesa
      refine ⟨?_, hr2, hr3⟩
      intro a ha
      obtain ⟨h1, h2⟩ := hr1 a ha
      obtain ⟨h1a, _⟩ := hra1 a ha
      exact ⟨hmem' _ h1 h1a, h2⟩
  have hJT' : JournalTyped s S' := by
    refine ⟨hjw1, hjw2, hjw3, ?_⟩
    intro i hi
    exact hmem' _ (hjw4 i hi) (hja4 i hi)
  have hTr' : TriesTypedWith s S' Nd_w := by
    obtain ⟨hn1, hn2, hn3⟩ := hWT_w.2.2.2
    refine ⟨hn1, ?_, ?_⟩
    · intro o ho
      obtain ⟨hd1, hd2⟩ := hn2 o ho
      exact ⟨fun t ht i hi => hd1 t ((hS'_mem t ht).1) i hi, hd2⟩
    · intro hws0
      obtain ⟨hr, hclos⟩ := hn3 hws0
      exact ⟨hr, fun hi => hclos ((hS'_mem _ hi).1)⟩
  have hWT' : WorldTypedWith s S' Nd_w := ⟨hTT', hJT', hWT_w.2.2.1, hTr'⟩
  -- write regions vs tables, fixed objects and nodes
  have hdj_fix : ∀ x ∈ Rl, ∀ j ∈ fixedObjects s, Disj x j := by
    intro x hx j hj
    rcases (hRl_avoid x hx) with ⟨hfo, _⟩ | hxins
    · exact (hFO_disj _ hhead_mem _ hfo).2 j hj
    · rcases hWT_w.2.2.1.1 j hj with h0 | ⟨halloc, _⟩
      · exact Or.inr (Or.inl h0)
      · rcases halloc with hins | hins
        · exact Or.inr (Or.inr (Or.inr (le_trans (le_trans hins.2 hAs.2.2.1)
            (hRl_hi x hx))))
        · exact Or.inr (Or.inr (Or.inl (le_trans hxins.2 hins.1)))
  have hdj_S' : ∀ x ∈ Rl, ∀ t ∈ S', ∀ i ∈ htabFootprint s t, Disj i x := by
    intro x hx t ht i hi
    have ht_w := (hS'_mem t ht).1
    have ht_at := (hS'_mem t ht).2
    rcases (hRl_avoid x hx) with ⟨hfo, _⟩ | hxins
    · exact R11Shards.Disj.symm ((hFO_disj _ hhead_mem _ hfo).1 t ht_at i hi)
    · rcases ((htabw t ht_w).2 i hi).1 with hins | hins
      · exact Or.inr (Or.inr (Or.inl (le_trans (le_trans hins.2 hAs.2.2.1)
          (hRl_hi x hx))))
      · exact Or.inr (Or.inr (Or.inr (le_trans hxins.2 hins.1)))
  have hdisj_wti' : ∀ x ∈ Rl, ∀ i ∈ worldTypedIvls s S' Nd_w, i.2 = 0 ∨ Disj x i := by
    intro x hx i hi
    unfold worldTypedIvls at hi
    simp only [List.mem_append] at hi
    rcases hi with ((((h1 | h2) | h3) | h4) | h5) | h6
    · obtain ⟨t, ht, hfp⟩ := List.mem_flatMap.1 h1
      exact Or.inr (R11Shards.Disj.symm (hdj_S' x hx t ht i hfp))
    · obtain ⟨r, hr, rfl⟩ := List.mem_map.1 h2
      exact Or.inr (hdj_fix x hx _ (typedRec_in_fixedObjects s hr))
    · obtain rfl := List.mem_singleton.1 h3
      refine Or.inr (hdj_fix x hx _ ?_)
      unfold fixedObjects
      exact List.mem_append_left _ (List.mem_append_left _
        (List.mem_append_right _ (List.mem_singleton.2 rfl)))
    · exact Or.inr (hdj_fix x hx _ (blockOut_in_fixedObjects h4))
    · exact Or.inr (hdj_fix x hx _ (bal_in_fixedObjects h5))
    · exact Or.inr (Or.inr (Or.inr (Or.inr (le_trans
        (nodeExtents_le_heapLimit hNH_w i h6) (hRl_hi x hx)))))
  -- SameTypedCells and the WorldTypedWith-post chain
  have hcell' : SameTypedCells s post S' Nd_w :=
    ByteRegionEffect.sameTypedCells (Rl := []) (extra := Rl)
      hAs.1.memaddrs hWT' (fun _ h => by simp at h) hdisj_wti' (by simpa using heff)
  have hke : ∀ name : String, name ≠ "heap_ptr" → name ≠ "scratch_ptr" →
      name ≠ "frame_mem_ptr" →
      s.globals.lookup (ofString name) = post.globals.lookup (ofString name) := by
    intro name _ _ _; rw [hglob]
  have hfo_eq : fixedObjects post = fixedObjects s :=
    InitECandidate.Solver.Wave8Contracts.M23.fixedObjects_eq_of_nonHeapGlobalsKept
      hAs.2 hWT'.1 hWT'.2.2.1 hcell' hke
  have hFT_post : FixedTyped post :=
    InitECandidate.Solver.Wave8Contracts.M23.fixedTyped_of_eq hApost hWT'.2.2.1
      (le_of_eq (hglobN "heap_ptr").symm)
      (le_of_eq (hglobN "scratch_ptr")) hfo_eq
  obtain ⟨hWT_post', _⟩ :=
    InitECandidate.Solver.Wave8Contracts.M23.worldTypedWith_congr_w1 hAs hApost
    (le_of_eq (hglobN "heap_ptr").symm) (le_of_eq (hglobN "scratch_ptr"))
    (fun g _ => hglobN g) hcell' hWT'
    ⟨hFT_post, fun o ho => Or.inl (by rw [← hfo_eq]; exact ho)⟩
  -- the WitnessDbAt-post components
  refine ⟨S', Nd_w, hWT_post', ?_⟩
  intro hws
  rw [hglobN "ws"] at hws ⊢
  dsimp only
  intro hnz
  set db := memW s (globN s "ws") with hdb_def
  have hrec_ws : (globN s "ws", if globN s "ws" = 0 then 0 else 40) ∈
      worldTypedIvls s S' Nd_w := by
    unfold worldTypedIvls
    exact List.mem_append_left _ (List.mem_append_left _ (List.mem_append_left _
      (List.mem_append_left _ (List.mem_append_right _
        (List.mem_map.2 ⟨("ws", 40), by simp [typedRecords], rfl⟩)))))
  have hdb_eq : memW post (globN s "ws") = db :=
    memW_eq_of_cellHits hcell' (globN_lt s "ws") hrec_ws
      ⟨by dsimp only; omega, by dsimp only; simp only [if_neg hws]; omega⟩
  rw [hdb_eq] at hnz ⊢
  obtain ⟨hwf, hk, hfp_in, hdisj, hvals⟩ := hdbAt_w hws hnz
  have hu_db : ∀ i ∈ htabFootprint s db,
      InitECandidate.Solver.Wave8Contracts.M08.IvlUnhit s post i := by
    intro i hi
    exact ivlUnhit_of_bre heff hRl8 fun x hx =>
      Or.inr (Or.inr (Or.inl (le_trans (le_trans (hfp_in i hi).2 hAs.2.2.1)
        (hRl_hi x hx))))
  have hu_S' : ∀ t ∈ S', ∀ i ∈ htabFootprint s t,
      InitECandidate.Solver.Wave8Contracts.M08.IvlUnhit s post i := by
    intro t ht i hi
    exact ivlUnhit_of_bre heff hRl8 fun x hx => hdj_S' x hx t ht i hi
  have hu_v : ∀ v ∈ htabValues s db,
      InitECandidate.Solver.Wave8Contracts.M08.IvlUnhit s post (v, 16) := by
    intro v hv
    have hv_ok := (hvals v hv).1
    exact ivlUnhit_of_bre heff hRl8 fun x hx =>
      Or.inr (Or.inr (Or.inl (le_trans (le_trans hv_ok.2.1.2 hAs.2.2.1)
        (hRl_hi x hx))))
  have ht_fp : (db, 88) ∈ htabFootprint s db := by simp [htabFootprint]
  have hdb8 : db % 8 = 0 := (hwf.1 _ ht_fp).2.1
  have hhe : heapEnd ≤ 2 ^ 64 := by decide
  have hhdr_hi : db + 88 ≤ 2 ^ 64 := by
    have h := (hwf.1 _ ht_fp).1.2; dsimp only at h; omega
  obtain ⟨hhdr, hfp_eq⟩ :=
    InitECandidate.Solver.Wave8Contracts.M08.htabFootprint_eq_of_hdr_unhit hdb8 hhdr_hi
      (hu_db _ ht_fp)
  have hvals_eq : htabValues post db = htabValues s db :=
    InitECandidate.Solver.Wave8Contracts.M08.htabValues_eq_of_unhit hwf hu_db
  have hfp_S' : ∀ t ∈ S', htabFootprint post t = htabFootprint s t := by
    intro t ht
    have ht_fp : (t, 88) ∈ htabFootprint s t := by simp [htabFootprint]
    have ht8 : t % 8 = 0 := ((htabw t (hS'_mem t ht).1).1.1 _ ht_fp).2.1
    have hthi : t + 88 ≤ 2 ^ 64 := by
      have h := ((htabw t (hS'_mem t ht).1).1.1 _ ht_fp).1.2; dsimp only at h; omega
    exact (InitECandidate.Solver.Wave8Contracts.M08.htabFootprint_eq_of_hdr_unhit ht8 hthi
      (hu_S' t ht _ ht_fp)).2
  have hflat_eq : S'.flatMap (htabFootprint post) = S'.flatMap (htabFootprint s) :=
    List.flatMap_congr hfp_S'
  have hne_eq : nodeExtents post Nd_w = nodeExtents s Nd_w :=
    InitECandidate.Solver.Wave8Contracts.M23.nodeExtents_eq hWT'.2.2.2.1 hcell'
  have hwo_eq : worldOwned post S' Nd_w = worldOwned s S' Nd_w := by
    unfold worldOwned
    rw [hflat_eq, hfo_eq, hne_eq]
  refine ⟨InitECandidate.Solver.Wave8Contracts.M08.htabWF_congr_unhit hAs.1 hApost.1 hwf hu_db,
    ?_, ?_, ?_, ?_⟩
  · rw [hhdr 0 (by omega)]; exact hk
  · intro i hi
    rw [hfp_eq] at hi
    exact ⟨(hfp_in i hi).1, le_trans (hfp_in i hi).2 (le_of_eq (hglobN "heap_ptr").symm)⟩
  · intro i hi o ho
    rw [hfp_eq] at hi
    rw [hwo_eq] at ho
    exact hdisj i hi o (worldOwned_sub (fun t ht => (hS'_mem t ht).1) o ho)
  · intro v hv
    rw [hvals_eq] at hv
    obtain ⟨hv_ok, hv_disj⟩ := hvals v hv
    have hlim : heapLimit ≤ heapEnd := by decide
    have hhp_le : globN s "heap_ptr" ≤ heapLimit := hAs.2.2.1
    have hv_hi : v + 16 ≤ 2 ^ 64 := by
      have h2 := hv_ok.2.1.2; omega
    have hv8 : v % 8 = 0 := hv_ok.1.1
    refine ⟨StorageCreateFinish.witnessSliceOK_of_preserved hv_ok
      (InitECandidate.Solver.Wave8Contracts.M08.wordsOK_transfer hAs.1 hApost.1 hv_ok.1)
      hhp
      (InitECandidate.Solver.Wave8Contracts.M08.memW_eq_of_ivlUnhit (hu_v v hv) hv8 hv_hi
        (by dsimp only; omega))
      (InitECandidate.Solver.Wave8Contracts.M08.memW_eq_of_ivlUnhit (hu_v v hv) (by omega)
        hv_hi (by dsimp only; omega)),
      ?_⟩
    intro j hj
    rw [hwo_eq] at hj
    exact hv_disj j (worldOwned_sub (fun t ht => (hS'_mem t ht).1) j hj)

/-! ## 6.5 Scratch-effect support (stack-push lane) -/

/-- A scratch-byte effect whose write regions are disjoint from `i` (and aligned) leaves
every aligned cell of `i` unhit. -/
theorem ivlUnhit_of_sbe {F : Type} {s post : PanSemStateFiniteExact 64 F} {Rl : List Ivl}
    (heff : ScratchByteEff s post Rl) {i : Ivl}
    (hal : ∀ x ∈ Rl, x.1 % 8 = 0) (hdisj : ∀ x ∈ Rl, Disj i x) :
    InitECandidate.Solver.Wave8Contracts.M08.IvlUnhit s post i := by
  intro a ha8 hlo hhi
  refine heff.cell_frame a fun x hx => ?_
  intro hc
  obtain ⟨hA, hB⟩ := hc
  have hx8 := hal x hx
  rcases hdisj x hx with h1 | h1 | h1 | h1 <;> omega

/-- The `vm_system_address` `Inside` conjunct of `EvmInvR32` transfers across an effect
that only moves `scratch_ptr`. -/
theorem sysInside_congr_scratch {F : Type} {s post : PanSemStateFiniteExact 64 F}
    (hgo : ∀ g : String, ofString g ≠ ofString "scratch_ptr" → globN post g = globN s g)
    (hsys : Inside (globN s "vm_system_address", 20) sourceBase (globN s "heap_ptr")) :
    Inside (globN post "vm_system_address", 20) sourceBase (globN post "heap_ptr") := by
  have h1 := hgo "vm_system_address" (by decide)
  have h2 := hgo "heap_ptr" (by decide)
  rw [h1, h2]; exact hsys

/-- Master lemma (scratch effects): like `witnessDbOK_of_frameWrites`, but the effect may
move `scratch_ptr` (shrinking it) and the write regions are confined to the head frame's
scratch objects or to scratch freshly allocated below the entry `scratch_ptr`. -/
theorem witnessDbOK_of_scratchEff {F : Type}
    {s post : PanSemStateFiniteExact 64 F} {Rl : List Ivl}
    (hInv : EvmInv s) (hdb : StorageCreateFinish.WitnessDbOK s)
    (hApost : ArenaReady post) (heff : ScratchByteEff s post Rl)
    (hsc : globN post "scratch_ptr" ≤ globN s "scratch_ptr")
    (hRl8 : ∀ x ∈ Rl, x.1 % 8 = 0)
    (hRl_avoid : ∀ x ∈ Rl, x.2 = 0 ∨
      ((x ∈ frameObjects s (globN s "ev", globN s "cur_cont") ∧
        Inside x (globN s "scratch_ptr") scratchEnd) ∨
      Inside x (globN post "scratch_ptr") (globN s "scratch_ptr"))) :
    StorageCreateFinish.WitnessDbOK post := by
  obtain ⟨hAs, S_at, hW_at, hch_ne, hch_len, hch_last, hFW_all, hFR_all, hRW,
    hFO_pw, hFO_disj, hAT, hMarks, hRoles, hGas⟩ := hInv
  obtain ⟨Nd_at, hTr_at, hAT_at⟩ := hAT
  obtain ⟨S_w, Nd_w, hWT_w, hdbAt_w⟩ := hdb
  have hhead_mem : (globN s "ev", globN s "cur_cont") ∈ evmChain s := by
    simp [evmChain, evmChainFrom]
  obtain ⟨hntw, htabw, hpww, hwsw, hbsw, htsw, hgrw, hbcw, htcw, hbalw, hbow, hrolesw⟩ := hWT_w.1
  obtain ⟨hnta, htaba, hpwa, hwsa, hbsa, htsa, hgra, hbca, htca, hbala, hboa, hrolesa⟩ := hW_at.1
  obtain ⟨hjw1, hjw2, hjw3, hjw4⟩ := hWT_w.2.1
  obtain ⟨hja1, hja2, hja3, hja4⟩ := hW_at.2.1
  have hNH_w : NodeHeap s Nd_w := hWT_w.2.2.2.1
  -- region bounds
  have hRl_hi : ∀ x ∈ Rl, heapLimit ≤ x.1 ∨ x.2 = 0 := by
    intro x hx
    have hss : scratchStart ≤ heapLimit := le_of_eq (by rfl)
    rcases (hRl_avoid x hx) with hz | ⟨_, hins⟩ | hins
    · exact Or.inr hz
    · exact Or.inl (le_trans (le_trans (le_trans hss hAs.2.2.2.1) hAs.2.2.2.2.1) hins.1)
    · exact Or.inl (le_trans (le_trans (le_trans hss hApost.2.2.2.1) hApost.2.2.2.2.1) hins.1)
  -- globals (only `scratch_ptr` may move, shrinking)
  have hglobN : ∀ name : String, ofString name ≠ ofString "scratch_ptr" →
      globN post name = globN s name :=
    fun name hn => R16Shards.OpHandlers.globN_eq_of_lookup_eq (heff.glob_other name hn)
  have hhp : globN s "heap_ptr" ≤ globN post "heap_ptr" :=
    le_of_eq (hglobN "heap_ptr" (by decide)).symm
  -- the post witness S' = S_w ∩ S_at
  obtain ⟨S', hS'_def⟩ : ∃ S', S' = S_w.filter (fun t => t ∈ S_at) := ⟨_, rfl⟩
  have hS'_mem : ∀ t ∈ S', t ∈ S_w ∧ t ∈ S_at := by
    intro t ht
    rw [hS'_def] at ht
    have h := List.mem_filter.1 ht
    exact ⟨h.1, of_decide_eq_true h.2⟩
  have hS'_nodup : S'.Nodup := by
    rw [hS'_def]; exact List.Nodup.filter _ hntw
  have hmem' : ∀ v, v ∈ S_w → v ∈ S_at → v ∈ S' := by
    intro v hw ha
    rw [hS'_def]
    exact List.mem_filter.2 ⟨hw, by simp [ha]⟩
  have hrootIn' : ∀ v, RootIn S_w v → RootIn S_at v → RootIn S' v := by
    intro v hvw hva
    rcases hva with rfl | ha
    · exact Or.inl rfl
    · rcases hvw with rfl | hw
      · exact Or.inl rfl
      · exact Or.inr (hmem' v hw ha)
  -- `WorldTypedWith s S' Nd_w`
  have hTT' : TablesTyped s S' := by
    refine ⟨hS'_nodup, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, hbow, ?_⟩
    · intro t ht
      exact htabw t (hS'_mem t ht).1
    · intro t ht u hu hne i hi j hj
      exact hpww t (hS'_mem t ht).1 u (hS'_mem u hu).1 hne i hi j hj
    · intro k hk hnz
      exact hrootIn' _ (hwsw k hk hnz) (hwsa k hk hnz)
    · intro k hk hnz
      exact hrootIn' _ (hbsw k hk hnz) (hbsa k hk hnz)
    · intro k hk hnz
      exact hrootIn' _ (htsw k hk hnz) (htsa k hk hnz)
    · intro g hg
      exact hrootIn' _ (hgrw g hg) (hgra g hg)
    · intro hnz hin
      have hw := hbcw hnz ((hS'_mem _ hin).1)
      have ha := hbca hnz ((hS'_mem _ hin).2)
      intro i hi
      exact hmem' _ (hw i hi) (ha i hi)
    · intro hnz hin
      have hw := htcw hnz ((hS'_mem _ hin).1)
      have ha := htca hnz ((hS'_mem _ hin).2)
      intro i hi
      exact hmem' _ (hw i hi) (ha i hi)
    · intro ad had
      obtain ⟨h1, h2, h3, h4⟩ := hbalw ad had
      obtain ⟨h1a, h2a, _, _⟩ := hbala ad had
      exact ⟨hmem' _ h1 h1a, hmem' _ h2 h2a, h3, h4⟩
    · obtain ⟨hr1, hr2, hr3⟩ := hrolesw
      obtain ⟨hra1, _, _⟩ := hrolesa
      refine ⟨?_, hr2, hr3⟩
      intro a ha
      obtain ⟨h1, h2⟩ := hr1 a ha
      obtain ⟨h1a, _⟩ := hra1 a ha
      exact ⟨hmem' _ h1 h1a, h2⟩
  have hJT' : JournalTyped s S' := by
    refine ⟨hjw1, hjw2, hjw3, ?_⟩
    intro i hi
    exact hmem' _ (hjw4 i hi) (hja4 i hi)
  have hTr' : TriesTypedWith s S' Nd_w := by
    obtain ⟨hn1, hn2, hn3⟩ := hWT_w.2.2.2
    refine ⟨hn1, ?_, ?_⟩
    · intro o ho
      obtain ⟨hd1, hd2⟩ := hn2 o ho
      exact ⟨fun t ht i hi => hd1 t ((hS'_mem t ht).1) i hi, hd2⟩
    · intro hws0
      obtain ⟨hr, hclos⟩ := hn3 hws0
      exact ⟨hr, fun hi => hclos ((hS'_mem _ hi).1)⟩
  have hWT' : WorldTypedWith s S' Nd_w := ⟨hTT', hJT', hWT_w.2.2.1, hTr'⟩
  -- write regions vs tables, fixed objects and nodes
  have hdj_fix : ∀ x ∈ Rl, ∀ j ∈ fixedObjects s, Disj x j := by
    intro x hx j hj
    rcases (hRl_avoid x hx) with hz | ⟨hfo, _⟩ | hxins
    · exact Or.inl hz
    · exact (hFO_disj _ hhead_mem _ hfo).2 j hj
    · rcases hWT_w.2.2.1.1 j hj with h0 | ⟨halloc, _⟩
      · exact Or.inr (Or.inl h0)
      · rcases halloc with hins | hins
        · rcases hRl_hi x hx with hhi | hz
          · exact Or.inr (Or.inr (Or.inr (le_trans (le_trans hins.2 hAs.2.2.1) hhi)))
          · exact Or.inl hz
        · exact Or.inr (Or.inr (Or.inl (le_trans hxins.2 hins.1)))
  have hdj_S' : ∀ x ∈ Rl, ∀ t ∈ S', ∀ i ∈ htabFootprint s t, Disj i x := by
    intro x hx t ht i hi
    have ht_w := (hS'_mem t ht).1
    have ht_at := (hS'_mem t ht).2
    rcases (hRl_avoid x hx) with hz | ⟨hfo, _⟩ | hxins
    · exact Or.inr (Or.inl hz)
    · exact R11Shards.Disj.symm ((hFO_disj _ hhead_mem _ hfo).1 t ht_at i hi)
    · rcases ((htabw t ht_w).2 i hi).1 with hins | hins
      · rcases hRl_hi x hx with hhi | hz
        · exact Or.inr (Or.inr (Or.inl (le_trans (le_trans hins.2 hAs.2.2.1) hhi)))
        · exact Or.inr (Or.inl hz)
      · exact Or.inr (Or.inr (Or.inr (le_trans hxins.2 hins.1)))
  have hdisj_wti' : ∀ x ∈ Rl, ∀ i ∈ worldTypedIvls s S' Nd_w, i.2 = 0 ∨ Disj x i := by
    intro x hx i hi
    unfold worldTypedIvls at hi
    simp only [List.mem_append] at hi
    rcases hi with ((((h1 | h2) | h3) | h4) | h5) | h6
    · obtain ⟨t, ht, hfp⟩ := List.mem_flatMap.1 h1
      exact Or.inr (R11Shards.Disj.symm (hdj_S' x hx t ht i hfp))
    · obtain ⟨r, hr, rfl⟩ := List.mem_map.1 h2
      exact Or.inr (hdj_fix x hx _ (typedRec_in_fixedObjects s hr))
    · obtain rfl := List.mem_singleton.1 h3
      refine Or.inr (hdj_fix x hx _ ?_)
      unfold fixedObjects
      exact List.mem_append_left _ (List.mem_append_left _
        (List.mem_append_right _ (List.mem_singleton.2 rfl)))
    · exact Or.inr (hdj_fix x hx _ (blockOut_in_fixedObjects h4))
    · exact Or.inr (hdj_fix x hx _ (bal_in_fixedObjects h5))
    · rcases hRl_hi x hx with hhi | hz
      · exact Or.inr (Or.inr (Or.inr (Or.inr (le_trans
          (nodeExtents_le_heapLimit hNH_w i h6) hhi))))
      · exact Or.inr (Or.inl hz)
  -- SameTypedCells and the WorldTypedWith-post chain
  have hcellG : SameTypedCells s { post with globals := s.globals } S' Nd_w :=
    ByteRegionEffect.sameTypedCells (Rl := []) (extra := Rl)
      hAs.1.memaddrs hWT' (fun _ h => by simp at h) hdisj_wti'
      ⟨heff.code, heff.memaddrs, heff.shMemaddrs, heff.baseAddr, heff.be, rfl,
        heff.out_dom, heff.cell_frame, heff.byte_frame⟩
  have hcell' : SameTypedCells s post S' Nd_w := hcellG
  have hfo_eq : fixedObjects post = fixedObjects s := by
    unfold fixedObjects
    rw [blockOutObjects_eq hAs.2 hWT'.2.2.1 hcell' (hglobN "bo" (by decide)),
        balObjects_eq hAs.2 hWT'.1 hWT'.2.2.1 hcell' (hglobN "bal_accounts" (by decide)),
        hglobN "journal" (by decide),
        hglobN "journal_cap" (by decide)]
    congr 3
    apply List.map_congr_left
    intro gn hgn
    have hne : ofString gn.1 ≠ ofString "scratch_ptr" := by
      clear * - hgn; revert gn hgn; decide
    rw [hglobN gn.1 hne]
  have hFT_post : FixedTyped post :=
    InitECandidate.Solver.Wave8Contracts.M23.fixedTyped_of_eq hApost hWT'.2.2.1 hhp hsc hfo_eq
  have hcg : ∀ g ∈ coreWorldGlobals, globN post g = globN s g := by
    intro g hg
    have hne : ofString g ≠ ofString "scratch_ptr" := by
      clear * - hg; revert g hg; decide
    exact hglobN g hne
  obtain ⟨hWT_post', _⟩ :=
    InitECandidate.Solver.Wave8Contracts.M23.worldTypedWith_congr_w1 hAs hApost
    hhp hsc hcg hcell' hWT'
    ⟨hFT_post, fun o ho => Or.inl (by rw [← hfo_eq]; exact ho)⟩
  -- the WitnessDbAt-post components
  refine ⟨S', Nd_w, hWT_post', ?_⟩
  intro hws
  rw [hglobN "ws" (by decide)] at hws ⊢
  dsimp only
  intro hnz
  set db := memW s (globN s "ws") with hdb_def
  have hrec_ws : (globN s "ws", if globN s "ws" = 0 then 0 else 40) ∈
      worldTypedIvls s S' Nd_w := by
    unfold worldTypedIvls
    exact List.mem_append_left _ (List.mem_append_left _ (List.mem_append_left _
      (List.mem_append_left _ (List.mem_append_right _
        (List.mem_map.2 ⟨("ws", 40), by simp [typedRecords], rfl⟩)))))
  have hdb_eq : memW post (globN s "ws") = db :=
    memW_eq_of_cellHits hcell' (globN_lt s "ws") hrec_ws
      ⟨by dsimp only; omega, by dsimp only; simp only [if_neg hws]; omega⟩
  rw [hdb_eq] at hnz ⊢
  obtain ⟨hwf, hk, hfp_in, hdisj, hvals⟩ := hdbAt_w hws hnz
  have hu_db : ∀ i ∈ htabFootprint s db,
      InitECandidate.Solver.Wave8Contracts.M08.IvlUnhit s post i := by
    intro i hi
    exact ivlUnhit_of_sbe heff hRl8 fun x hx => by
      rcases hRl_hi x hx with hhi | hz
      · exact Or.inr (Or.inr (Or.inl (le_trans (le_trans (hfp_in i hi).2 hAs.2.2.1)
          hhi)))
      · exact Or.inr (Or.inl hz)
  have hu_S' : ∀ t ∈ S', ∀ i ∈ htabFootprint s t,
      InitECandidate.Solver.Wave8Contracts.M08.IvlUnhit s post i := by
    intro t ht i hi
    exact ivlUnhit_of_sbe heff hRl8 fun x hx => hdj_S' x hx t ht i hi
  have hu_v : ∀ v ∈ htabValues s db,
      InitECandidate.Solver.Wave8Contracts.M08.IvlUnhit s post (v, 16) := by
    intro v hv
    have hv_ok := (hvals v hv).1
    exact ivlUnhit_of_sbe heff hRl8 fun x hx => by
      rcases hRl_hi x hx with hhi | hz
      · exact Or.inr (Or.inr (Or.inl (le_trans (le_trans hv_ok.2.1.2 hAs.2.2.1)
          hhi)))
      · exact Or.inr (Or.inl hz)
  have ht_fp : (db, 88) ∈ htabFootprint s db := by simp [htabFootprint]
  have hdb8 : db % 8 = 0 := (hwf.1 _ ht_fp).2.1
  have hhe : heapEnd ≤ 2 ^ 64 := by decide
  have hhdr_hi : db + 88 ≤ 2 ^ 64 := by
    have h := (hwf.1 _ ht_fp).1.2; dsimp only at h; omega
  obtain ⟨hhdr, hfp_eq⟩ :=
    InitECandidate.Solver.Wave8Contracts.M08.htabFootprint_eq_of_hdr_unhit hdb8 hhdr_hi
      (hu_db _ ht_fp)
  have hvals_eq : htabValues post db = htabValues s db :=
    InitECandidate.Solver.Wave8Contracts.M08.htabValues_eq_of_unhit hwf hu_db
  have hfp_S' : ∀ t ∈ S', htabFootprint post t = htabFootprint s t := by
    intro t ht
    have ht_fp : (t, 88) ∈ htabFootprint s t := by simp [htabFootprint]
    have ht8 : t % 8 = 0 := ((htabw t (hS'_mem t ht).1).1.1 _ ht_fp).2.1
    have hthi : t + 88 ≤ 2 ^ 64 := by
      have h := ((htabw t (hS'_mem t ht).1).1.1 _ ht_fp).1.2; dsimp only at h; omega
    exact (InitECandidate.Solver.Wave8Contracts.M08.htabFootprint_eq_of_hdr_unhit ht8 hthi
      (hu_S' t ht _ ht_fp)).2
  have hflat_eq : S'.flatMap (htabFootprint post) = S'.flatMap (htabFootprint s) :=
    List.flatMap_congr hfp_S'
  have hne_eq : nodeExtents post Nd_w = nodeExtents s Nd_w :=
    InitECandidate.Solver.Wave8Contracts.M23.nodeExtents_eq hWT'.2.2.2.1 hcell'
  have hwo_eq : worldOwned post S' Nd_w = worldOwned s S' Nd_w := by
    unfold worldOwned
    rw [hflat_eq, hfo_eq, hne_eq]
  refine ⟨InitECandidate.Solver.Wave8Contracts.M08.htabWF_congr_unhit hAs.1 hApost.1 hwf hu_db,
    ?_, ?_, ?_, ?_⟩
  · rw [hhdr 0 (by omega)]; exact hk
  · intro i hi
    rw [hfp_eq] at hi
    exact ⟨(hfp_in i hi).1, le_trans (hfp_in i hi).2 hhp⟩
  · intro i hi o ho
    rw [hfp_eq] at hi
    rw [hwo_eq] at ho
    exact hdisj i hi o (worldOwned_sub (fun t ht => (hS'_mem t ht).1) o ho)
  · intro v hv
    rw [hvals_eq] at hv
    obtain ⟨hv_ok, hv_disj⟩ := hvals v hv
    have hlim : heapLimit ≤ heapEnd := by decide
    have hhp_le : globN s "heap_ptr" ≤ heapLimit := hAs.2.2.1
    have hv_hi : v + 16 ≤ 2 ^ 64 := by
      have h2 := hv_ok.2.1.2; omega
    have hv8 : v % 8 = 0 := hv_ok.1.1
    refine ⟨StorageCreateFinish.witnessSliceOK_of_preserved hv_ok
      (InitECandidate.Solver.Wave8Contracts.M08.wordsOK_transfer hAs.1 hApost.1 hv_ok.1)
      hhp
      (InitECandidate.Solver.Wave8Contracts.M08.memW_eq_of_ivlUnhit (hu_v v hv) hv8 hv_hi
        (by dsimp only; omega))
      (InitECandidate.Solver.Wave8Contracts.M08.memW_eq_of_ivlUnhit (hu_v v hv) (by omega)
        hv_hi (by dsimp only; omega)),
      ?_⟩
    intro j hj
    rw [hwo_eq] at hj
    exact hv_disj j (worldOwned_sub (fun t ht => (hS'_mem t ht).1) j hj)

/-- Port of the (private) `Group10CallsCreates.headMemChainWF_of_head_stack_push_g10`:
the head-frame-preserving scratch effect of `stack_push` keeps the chain WF. -/
theorem headMemChainWF_of_head_stack_push_c1 {F : Type}
    {s post : PanSemStateFiniteExact 64 F} {freshIvl : Ivl}
    (hInv : EvmInv s) (hHMWF : Group10.HeadMemChainWF s)
    (hApost : ArenaReady post)
    (heff : ScratchByteEff s post [freshIvl, (globN s "ev", 280), (memW s (globN s "ev" + 8), 32 * memW s (globN s "ev" + 232))])
    (hfresh : freshIvl = (0, 0) ∨
      (freshIvl.1 % 8 = 0 ∧ freshIvl.2 % 8 = 0 ∧
        Inside freshIvl (globN post "scratch_ptr") (globN s "scratch_ptr")))
    (he0_other : ∀ off, off + 8 ≤ 280 → off % 8 = 0 → off ≠ 8 → off ≠ 16 → off ≠ 232 →
      memW post (globN s "ev" + off) = memW s (globN s "ev" + off))
    (hchain : evmChain post = evmChain s) :
    Group10.HeadMemChainWF post := by
  obtain ⟨hAs, S, _, _, _, _, hFW_all, _, _, hFO_pw, _⟩ := hInv
  set e0 := globN s "ev"
  set c0 := globN s "cur_cont"
  set oldStk : Ivl := (memW s (e0 + 8), 32 * memW s (e0 + 232))
  have hch_cons : ∃ tl, evmChain s = (e0, c0) :: tl := ⟨_, rfl⟩
  obtain ⟨chTail, hch_eq⟩ := hch_cons
  have hhead_mem : (e0, c0) ∈ evmChain s := by rw [hch_eq]; exact List.mem_cons_self
  have hhead_FW := hFW_all _ hhead_mem
  have he0_8 : e0 % 8 = 0 := (hhead_FW.1 (e0, 280) (by simp)).2.1
  have holdStk_8 : oldStk.1 % 8 = 0 := (hhead_FW.1 oldStk (by simp [oldStk])).2.1
  have hRl_list : ∀ x ∈ ([freshIvl, (e0, 280), oldStk] : List Ivl), x.1 % 8 = 0 := by
    intro x hx; simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
    rcases hx with rfl | rfl | rfl
    · rcases hfresh with rfl | ⟨h8, _⟩
      · rfl
      · exact h8
    · exact he0_8
    · exact holdStk_8
  have hglob_eq : ∀ g, ofString g ≠ ofString "scratch_ptr" → globN post g = globN s g :=
    fun g hg => R16Shards.OpHandlers.globN_eq_of_lookup_eq (heff.glob_other g hg)
  have hmemW_disj : ∀ {base sz k : Nat}, base + sz ≤ 2 ^ 64 → base % 8 = 0 → k % 8 = 0 → k + 8 ≤ sz →
      (∀ x ∈ ([freshIvl, (e0, 280), oldStk] : List Ivl), Disj x (base, sz)) →
      memW post (base + k) = memW s (base + k) := by
    intro base sz k hbnd hb8 hk8 hk hdj
    unfold memW
    have ha : base + k < 2 ^ 64 := by omega
    have hbk8 : (base + k) % 8 = 0 := by omega
    have hbit : (BitVec.ofNat 64 (base + k)).toNat = base + k := Nat.mod_eq_of_lt ha
    rw [heff.cell_frame (BitVec.ofNat 64 (base + k))]
    intro x hx; rw [hbit]
    exact not_cellHits_of_disj_aligned (i := (base, sz)) hbk8 (hRl_list x hx)
      (Nat.le_add_right base k) (Nat.add_le_add_left hk base) (R11Shards.Disj.symm (hdj x hx))
  have hpw_head_tail :
      (frameObjects s (e0, c0)).Pairwise Disj ∧
      (∀ o1 ∈ frameObjects s (e0, c0),
        ∀ ec ∈ chTail, ∀ o2 ∈ frameObjects s ec, Disj o1 o2) := by
    have hpw := hFO_pw
    rw [hch_eq, List.map_cons, List.flatten_cons, List.pairwise_append] at hpw
    refine ⟨hpw.1, fun o1 ho1 ec hec o2 ho2 => hpw.2.2 o1 ho1 o2 ?_⟩
    exact List.mem_flatten.2 ⟨_, List.mem_map.2 ⟨ec, hec, rfl⟩, ho2⟩
  have hfresh_disj_ec : ∀ ec ∈ evmChain s, Disj freshIvl (ec.1, 280) ∧ Disj freshIvl (ec.2, 104) := by
    intro ec hec
    rcases hfresh with rfl | ⟨_, _, hfin1, _⟩
    · exact ⟨Or.inl rfl, Or.inl rfl⟩
    · have hFW := hFW_all ec hec
      have h3 := hApost.2.2.2.2.1
      rw [hglob_eq "frame_mem_ptr" (by decide)] at h3
      obtain ⟨hin1, _⟩ := (hFW.1 (ec.1, 280) (by simp)).1
      obtain ⟨hin2, _⟩ := (hFW.1 (ec.2, 104) (by simp)).1
      exact ⟨Or.inr (Or.inr (Or.inl (by dsimp only at hin1 ⊢; omega))),
             Or.inr (Or.inr (Or.inl (by dsimp only at hin2 ⊢; omega)))⟩
  have hhead_pw := hpw_head_tail.1
  unfold frameObjects at hhead_pw
  have hp0 := List.pairwise_cons.1 hhead_pw
  have hp1 := List.pairwise_cons.1 hp0.2
  refine Group10.headMemChainWF_of_agree hHMWF hchain ?_
    (hglob_eq "ev" (by decide)) (hglob_eq "frame_mem_ptr" (by decide))
  intro ec hec
  have hFW := hFW_all ec hec
  obtain ⟨hb_e, hb_c, _, _⟩ := frameWF_bounds hAs.2 hFW
  have he8 : ec.1 % 8 = 0 := (hFW.1 (ec.1, 280) (by simp)).2.1
  have hc8 : ec.2 % 8 = 0 := (hFW.1 (ec.2, 104) (by simp)).2.1
  have hdj_f := hfresh_disj_ec ec hec
  have he_eq : ∀ k, k + 8 ≤ 280 → k % 8 = 0 → k ≠ 8 → k ≠ 16 → k ≠ 232 →
      memW post (ec.1 + k) = memW s (ec.1 + k) := by
    intro k hk hk8 hk8' hk16 hk232
    rw [hch_eq, List.mem_cons] at hec
    rcases hec with rfl | htail
    · exact he0_other k hk hk8 hk8' hk16 hk232
    · apply hmemW_disj hb_e he8 hk8 hk
      intro x hx; simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
      rcases hx with rfl | rfl | rfl
      · exact hdj_f.1
      · exact hpw_head_tail.2 _ (by simp [frameObjects]) ec htail _ (by simp [frameObjects])
      · exact hpw_head_tail.2 _ (by simp [frameObjects, oldStk]) ec htail _ (by simp [frameObjects])
  have hc56 : memW post (ec.2 + 56) = memW s (ec.2 + 56) := by
    apply hmemW_disj hb_c hc8 (by omega) (by omega)
    intro x hx; simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
    rw [hch_eq, List.mem_cons] at hec
    rcases hec with rfl | htail
    · rcases hx with rfl | rfl | rfl
      · exact hdj_f.2
      · exact hp0.1 _ (by simp)
      · exact R11Shards.Disj.symm (hp1.1 _ (by simp [oldStk]))
    · rcases hx with rfl | rfl | rfl
      · exact hdj_f.2
      · exact hpw_head_tail.2 _ (by simp [frameObjects]) ec htail _ (by simp [frameObjects])
      · exact hpw_head_tail.2 _ (by simp [frameObjects, oldStk]) ec htail _ (by simp [frameObjects])
  exact ⟨he_eq 24 (by omega) (by omega) (by omega) (by omega) (by omega),
         he_eq 32 (by omega) (by omega) (by omega) (by omega) (by omega),
         he_eq 40 (by omega) (by omega) (by omega) (by omega) (by omega),
         hc56⟩


/-- Port of the (private) `Group10CallsCreates.raise3_unchanged_hmwf_g10`, strengthened to
the `EvmInvR32` payload: raising `EvmErr` from an unchanged state preserves the witness DB
(refl scratch effect), the system-address bound, and the chain WF after local wrapping. -/
theorem raise3_unchanged_hmwf_c1 {F : Type} {s t : PanSemStateFiniteExact 64 F}
    (hInv : EvmInvR32 s)
    (hHMWF : Group10.HeadMemChainWF s)
    (L_wrap : HolFiniteMapExact MlS (ValueHOL 64) → HolFiniteMapExact MlS (ValueHOL 64))
    (ht_eq : t = { s with locals := t.locals, clock := t.clock }) :
    let out := evaluateHOLFiniteState t (.raise (ofString "EvmErr") (.const 3#64))
    (∀ v, out.1 = some (.returned v) →
      (StorageCreateFinish.WitnessDbOK { out.2 with locals := L_wrap out.2.locals } ∧
        Inside (globN { out.2 with locals := L_wrap out.2.locals } "vm_system_address", 20)
          sourceBase (globN { out.2 with locals := L_wrap out.2.locals } "heap_ptr") ∧
        HeadMemBridge.HeadMemChainWF { out.2 with locals := L_wrap out.2.locals })) ∧
    (IsEvmErr out.1 →
      (StorageCreateFinish.WitnessDbOK { out.2 with locals := L_wrap out.2.locals } ∧
        Inside (globN { out.2 with locals := L_wrap out.2.locals } "vm_system_address", 20)
          sourceBase (globN { out.2 with locals := L_wrap out.2.locals } "heap_ptr") ∧
        HeadMemBridge.HeadMemChainWF { out.2 with locals := L_wrap out.2.locals })) := by
  dsimp only
  rw [evaluateHOLFiniteState_raise]; dsimp only [evalHOLExact]
  cases ht_esh : t.eshapes.lookup (ofString "EvmErr") with
  | none =>
    dsimp only
    constructor
    · intro _ h; cases h
    · rintro ⟨_, h⟩; cases h
  | some sh =>
    dsimp only
    by_cases hcond : shapeOfHOLExact (.val (.word 3#64)) = sh ∧
        sizeOfShapeWithContextHOL t.structs (shapeOfHOLExact (.val (.word 3#64))) ≤ 32
    · rw [if_pos hcond]; dsimp only
      let post := { t.emptyLocalsHOLFinite with locals := L_wrap t.emptyLocalsHOLFinite.locals }
      have hp_eq : post = { s with locals := post.locals, clock := t.clock } := by
        dsimp only [post, emptyLocalsHOLFinite]; conv_lhs => rw [ht_eq]
      have hApost : ArenaReady post := by
        rw [hp_eq]
        exact ⟨guestInv_congr (s := s) rfl rfl rfl rfl hInv.evmInv.1.1, hInv.evmInv.1.2⟩
      have heff_refl : ScratchByteEff s post [] := by
        rw [hp_eq]
        exact (ScratchByteEff.refl s []).with_locals_clock post.locals t.clock
      have hdb : StorageCreateFinish.WitnessDbOK post :=
        witnessDbOK_of_scratchEff hInv.evmInv hInv.witnessDbOK hApost heff_refl
          (by rw [hp_eq]; exact le_refl _) (by simp) (by simp)
      have hsys : Inside (globN post "vm_system_address", 20) sourceBase
          (globN post "heap_ptr") := by
        rw [hp_eq]; exact hInv.sysInside
      have hHMWF_p : Group10.HeadMemChainWF post := by
        have h := Group10.headMemChainWF_locals s post.locals t.clock hHMWF
        rwa [← hp_eq] at h
      have hres : StorageCreateFinish.WitnessDbOK post ∧
          Inside (globN post "vm_system_address", 20) sourceBase (globN post "heap_ptr") ∧
          HeadMemBridge.HeadMemChainWF post :=
        ⟨hdb, hsys, (headMemChainWF_g10_iff_bridge post).mp hHMWF_p⟩
      constructor
      · intro _ h; cases h
      · intro _; exact hres
    · rw [if_neg hcond]; dsimp only
      constructor
      · intro _ h; cases h
      · rintro ⟨_, h⟩; cases h


/-- `stack_push` at `EvmPreservingSpecA32` strength: full port of the G10 walk
(`Group10CallsCreates.epsA_stack_push`), with the `EvmInvR32` payload (witness DB via the
scratch-effect master, system-address bound) proved alongside the frame/chain facts. -/

theorem epsA32_stack_push :
    EvmPreservingSpecA32 (fun _ => True)
      (fun s _ post => ∀ g : String, ofString g ≠ ofString "scratch_ptr" → globN post g = globN s g)
      (ofString "stack_push") := by
  obtain ⟨params_sp, body_sp, retShape_sp, hlk_sp, hspec_sp⟩ := eps_stack_push
  have hlk_eq := lookup_stack_push.symm.trans hlk_sp
  injection hlk_eq with hprod
  rcases Prod.mk.inj hprod with ⟨rfl, hprod2⟩
  rcases Prod.mk.inj hprod2 with ⟨hbody_eq, rfl⟩
  subst hbody_eq
  refine ⟨_, _, _, lookup_stack_push, ?_⟩
  intro F s hcode hInvR32 hWF _ ⟨vals, hlk_entry⟩ hnt
  have hInv := hInvR32.evmInv
  have hs_base := hspec_sp s hcode hInv trivial ⟨vals, hlk_entry⟩ hnt
  clear hspec_sp hlk_sp
  dsimp only at hs_base ⊢
  suffices hhm :
      let r := (evaluateHOLFiniteState s (sourceFnBody Guest.Software.guestFn_stack_push)).1
      let post := (evaluateHOLFiniteState s (sourceFnBody Guest.Software.guestFn_stack_push)).2
      (∀ v, r = some (.returned v) →
        (StorageCreateFinish.WitnessDbOK post ∧
          Inside (globN post "vm_system_address", 20) sourceBase (globN post "heap_ptr") ∧
          HeadMemBridge.HeadMemChainWF post)) ∧
      (IsEvmErr r →
        (StorageCreateFinish.WitnessDbOK post ∧
          Inside (globN post "vm_system_address", 20) sourceBase (globN post "heap_ptr") ∧
          HeadMemBridge.HeadMemChainWF post)) by
    dsimp only at hhm
    refine ⟨fun v hv => ?_, fun herr => ?_⟩
    · obtain ⟨hInv_p, hch_p, hR_p, hg_p⟩ := hs_base.1 v hv
      obtain ⟨hdb_p, hsys_p, hWF_p⟩ := hhm.1 v hv
      exact ⟨⟨⟨hInv_p, hdb_p, hsys_p⟩, hWF_p⟩, hch_p, hR_p, hg_p⟩
    · obtain ⟨hInv_p, hch_p, hR_p⟩ := hs_base.2 herr
      obtain ⟨hdb_p, hsys_p, hWF_p⟩ := hhm.2 herr
      exact ⟨⟨⟨hInv_p, hdb_p, hsys_p⟩, hWF_p⟩, hch_p, hR_p⟩
  have hv_struct : ∃ w0 w1 w2 w3 : BitVec 64,
      s.locals.lookup (ofString "v") =
        some (.rStruct [.val (.word w0), .val (.word w1), .val (.word w2), .val (.word w3)]) := by
    have hx := PanSemStateFiniteExact.lookupCodeHOLFinite_eq_some
      originalRuntimeCode.lookup (ofString "stack_push") vals
      (sourceFnBody Guest.Software.guestFn_stack_push) s.locals .one hlk_entry
    simp only [Flapjack.lookupCodeHOLExact, lookup_stack_push] at hx
    rcases vals with _ | ⟨v0, _ | _⟩
    · simp at hx
    · split at hx
      · rename_i hcond
        have heq := Option.some.inj hx
        rcases Prod.mk.inj heq with ⟨_, hrest⟩
        rcases Prod.mk.inj hrest with ⟨hloc, _⟩
        have hsh : shapeEqHOL (.comb [.one, .one, .one, .one]) (shapeOfHOLExact v0) = true := by
          simpa [List.map] using hcond
        rw [shapeEqHOL_eq_true] at hsh
        have hfn : s.locals.lookup (ofString "v") = some v0 := by
          have := congrFun hloc.symm (ofString "v")
          simpa [FUPDATE_LIST, FUPDATE] using this
        rcases v0 with _ | fs | _
        · simp [shapeOfHOLExact] at hsh
        · simp only [shapeOfHOLExact, ShapeHOL.comb.injEq] at hsh
          rcases fs with _ | ⟨f0, _ | ⟨f1, _ | ⟨f2, _ | ⟨f3, _ | _⟩⟩⟩⟩
          · simp at hsh
          · simp at hsh
          · simp at hsh
          · simp at hsh
          · simp only [List.map, List.cons.injEq] at hsh
            obtain ⟨h0, h1, h2, h3, _⟩ := hsh
            rcases f0 with ⟨⟨w0⟩⟩ | _ | _ <;> simp [shapeOfHOLExact] at h0
            rcases f1 with ⟨⟨w1⟩⟩ | _ | _ <;> simp [shapeOfHOLExact] at h1
            rcases f2 with ⟨⟨w2⟩⟩ | _ | _ <;> simp [shapeOfHOLExact] at h2
            rcases f3 with ⟨⟨w3⟩⟩ | _ | _ <;> simp [shapeOfHOLExact] at h3
            exact ⟨w0, w1, w2, w3, hfn⟩
          · simp at hsh
        · simp [shapeOfHOLExact] at hsh
      · cases hx
    · simp at hx
  obtain ⟨vw0, vw1, vw2, vw3, hv_loc⟩ := hv_struct
  have hhead_mem : (globN s "ev", globN s "cur_cont") ∈ evmChain s := by simp [evmChain, evmChainFrom]
  have hFW0 := hInv.2.choose_spec.2.2.2.2.1 _ hhead_mem
  have hb_ev := (frameWF_bounds hInv.1.2 hFW0).1
  dsimp only at hb_ev
  have hev_pos : 0 < globN s "ev" := by
    obtain ⟨hin1, _⟩ := (hFW0.1 (globN s "ev", 280) (by simp)).1
    have h1 := hInv.1.2.2.2.1; have h2 := hInv.1.2.2.2.2.1
    rw [R11Shards.scratchStart_val] at h1; dsimp only at hin1; omega
  obtain ⟨evw, hevw, hevw_nat⟩ := global_word_of_pos s "ev" hev_pos
  obtain ⟨hp_w, fp_w, sp_g_w, hhp_lk, hhp_nat, hfp_lk, hfp_nat, hsp_g_lk, hsp_g_nat⟩ :=
    Wave8Contracts.M26.arenaOK_globals s hInv.1.2
  have herr_triv : ∀ {P1 P2 : Prop},
      (∀ v, (some PanSemResultExact.error : Option (PanSemResultExact 64)) = some (.returned v) → P1) ∧
      (IsEvmErr (some PanSemResultExact.error) → P2) := by
    intro _ _; constructor
    · intro _ h; cases h
    · rintro ⟨_, h⟩; cases h
  let growBranch : ProgHOL 64 :=
    .seq
      (.ite (.cmp .notLower (.var .local (ofString "cap")) (.const 1024#64))
        (.raise (ofString "EvmErr") (.const 3#64))
        .skip)
      (.dec (ofString "ncap") .one (.panop .mul [.var .local (ofString "cap"), .const 2#64])
        (.seq
          (.ite (.cmp .lower (.const 1024#64) (.var .local (ofString "ncap")))
            (.assign .local (ofString "ncap") (.const 1024#64))
            .skip)
          (.decCall (ofString "ns") .one (ofString "scratch_alloc")
            [.panop .mul [.var .local (ofString "ncap"), .const 32#64]]
            (.seq
              (.call (some (none, none)) (ofString "memcpy")
                [.var .local (ofString "ns"),
                 .load .one (.op .add [.var .global (ofString "ev"), .const 8#64]),
                 .panop .mul [.var .local (ofString "sp"), .const 32#64]])
              (.seq
                (.store (.op .add [.var .global (ofString "ev"), .const 8#64]) (.var .local (ofString "ns")))
                (.store (.op .add [.var .global (ofString "ev"), .const 232#64]) (.var .local (ofString "ncap"))))))))
  let tailProg : ProgHOL 64 :=
    .seq
      (.ite (.cmp .equal (.var .local (ofString "sp")) (.const 1024#64))
        (.raise (ofString "EvmErr") (.const 3#64))
        .skip)
      (.seq
        (.store
          (.op .add
            [.load .one (.op .add [.var .global (ofString "ev"), .const 8#64]),
             .panop .mul [.var .local (ofString "sp"), .const 32#64]])
          (.var .local (ofString "v")))
        (.seq
          (.store (.op .add [.var .global (ofString "ev"), .const 16#64])
            (.op .add [.var .local (ofString "sp"), .const 1#64]))
          (.return (.const 0#64))))
  have hbody : sourceFnBody Guest.Software.guestFn_stack_push =
      .dec (ofString "sp") .one (.load .one (.op .add [.var .global (ofString "ev"), .const 16#64]))
        (.dec (ofString "cap") .one (.load .one (.op .add [.var .global (ofString "ev"), .const 232#64]))
          (.seq
            (.ite (.cmp .notLower (.var .local (ofString "sp")) (.var .local (ofString "cap")))
              growBranch
              .skip)
            tailProg)) := rfl
  dsimp only
  rw [hbody] at hnt ⊢
  rw [evaluateHOLFiniteState_dec_total] at hnt ⊢; dsimp only at hnt ⊢
  rcases hload_sp : @evalHOLExact 64 F _ s.toExact (fun a => Classical.propDecidable (s.memaddrs a))
      (.load .one (.op .add [.var .global (ofString "ev"), .const 16#64])) with _ | vsp
  · exact herr_triv
  · simp only [hload_sp] at hnt ⊢
    obtain ⟨spw, rfl, hspw_eq⟩ := evalAt_loadG_word s "ev" 16#64 vsp hload_sp
    have h16_n : (16#64 : BitVec 64).toNat = 16 := rfl
    rw [h16_n] at hspw_eq
    have hsh_sp : shapeEqHOL .one (shapeOfHOLExact (.val (.word spw))) = true := by
      simp [shapeEqHOL, shapeOfHOLExact]
    rw [if_pos hsh_sp] at hnt ⊢; dsimp only at hnt ⊢
    set s1 := setVarHOLFinite (ofString "sp") (.val (.word spw)) s with hs1
    rw [evaluateHOLFiniteState_dec_total] at hnt ⊢; dsimp only at hnt ⊢
    rcases hload_cap : @evalHOLExact 64 F _ s1.toExact (fun a => Classical.propDecidable (s1.memaddrs a))
        (.load .one (.op .add [.var .global (ofString "ev"), .const 232#64])) with _ | vcap
    · exact herr_triv
    · simp only [hload_cap] at hnt ⊢
      obtain ⟨capw, rfl, hcapw_eq⟩ := evalAt_loadG_word s1 "ev" 232#64 vcap hload_cap
      have h232_n : (232#64 : BitVec 64).toNat = 232 := rfl
      have hs1_gm : memW s1 (globN s1 "ev" + 232) = memW s (globN s "ev" + 232) := rfl
      rw [h232_n, hs1_gm] at hcapw_eq
      have hsh_cap : shapeEqHOL .one (shapeOfHOLExact (.val (.word capw))) = true := by
        simp [shapeEqHOL, shapeOfHOLExact]
      rw [if_pos hsh_cap] at hnt ⊢; dsimp only at hnt ⊢
      set s2 := setVarHOLFinite (ofString "cap") (.val (.word capw)) s1 with hs2
      have hs2_sp : s2.locals.lookup (ofString "sp") = some (.val (.word spw)) := by
        simp [hs2, hs1, setVarHOLFinite, HolFiniteMapExact.lookup_update, FUPDATE,
          show ofString "cap" ≠ ofString "sp" by decide]
      have hs2_cap : s2.locals.lookup (ofString "cap") = some (.val (.word capw)) := by
        simp [hs2, setVarHOLFinite, HolFiniteMapExact.lookup_update, FUPDATE]
      have hs2_v : s2.locals.lookup (ofString "v") =
          some (.rStruct [.val (.word vw0), .val (.word vw1), .val (.word vw2), .val (.word vw3)]) := by
        simp [hs2, hs1, setVarHOLFinite, HolFiniteMapExact.lookup_update, FUPDATE, hv_loc,
          show ofString "cap" ≠ ofString "v" by decide, show ofString "sp" ≠ ofString "v" by decide]
      have hcap_ge1 : 1 ≤ capw.toNat := by rw [hcapw_eq]; exact hFW0.2.2.2.1
      have hsp_le_cap : spw.toNat ≤ capw.toNat := by rw [hspw_eq, hcapw_eq]; exact hFW0.2.2.2.2.1
      have hcap_le1024 : capw.toNat ≤ 1024 := by rw [hcapw_eq]; exact hFW0.2.2.2.2.2.1
      have run_tail : ∀ (m : PanSemStateFiniteExact 64 F) (freshIvl : Ivl),
          ArenaReady m →
          globN m "scratch_ptr" ≤ globN s "scratch_ptr" →
          (∀ g : String, ofString g ≠ ofString "scratch_ptr" → m.globals.lookup (ofString g) = s.globals.lookup (ofString g)) →
          ScratchByteEff s m [freshIvl, (globN s "ev", 280), (memW s (globN s "ev" + 8), 32 * memW s (globN s "ev" + 232))] →
          (freshIvl = (0, 0) ∨
            (freshIvl.1 % 8 = 0 ∧ freshIvl.2 % 8 = 0 ∧
              Inside freshIvl (globN m "scratch_ptr") (globN s "scratch_ptr"))) →
          (∀ off, off + 8 ≤ 280 → off % 8 = 0 → off ≠ 8 → off ≠ 16 → off ≠ 232 →
            memW m (globN s "ev" + off) = memW s (globN s "ev" + off)) →
          ((freshIvl.2 = 0 ∧ memW m (globN s "ev" + 8) = memW s (globN s "ev" + 8) ∧
              memW m (globN s "ev" + 232) = memW s (globN s "ev" + 232)) ∨
            (freshIvl.2 ≠ 0 ∧ (memW m (globN s "ev" + 8), 32 * memW m (globN s "ev" + 232)) = freshIvl)) →
          spw.toNat < memW m (globN s "ev" + 232) →
          memW m (globN s "ev" + 232) ≤ 1024 →
          memW m (globN s "ev" + 16) = spw.toNat →
          m.locals.lookup (ofString "sp") = some (.val (.word spw)) →
          m.locals.lookup (ofString "v") =
            some (.rStruct [.val (.word vw0), .val (.word vw1), .val (.word vw2), .val (.word vw3)]) →
          let out := evaluateHOLFiniteState m tailProg
          let post := { out.2 with
            locals := (out.2.locals.resVarEq (ofString "cap", s1.locals.lookup (ofString "cap"))).resVarEq
              (ofString "sp", s.locals.lookup (ofString "sp")) }
          (∀ v, out.1 = some (.returned v) →
            (StorageCreateFinish.WitnessDbOK post ∧
              Inside (globN post "vm_system_address", 20) sourceBase (globN post "heap_ptr") ∧
              HeadMemBridge.HeadMemChainWF post)) ∧
          (IsEvmErr out.1 →
            (StorageCreateFinish.WitnessDbOK post ∧
              Inside (globN post "vm_system_address", 20) sourceBase (globN post "heap_ptr") ∧
              HeadMemBridge.HeadMemChainWF post)) := by
        intro m freshIvl hAm hsc_m hm_glob_other heff_m hfresh_m he0_m hnew_m hsp_lt_mcap hmcap_le _hm_sp16 hm_sp hm_v
        dsimp only [tailProg]
        have hm_ev : m.globals.lookup (ofString "ev") = some (.val (.word evw)) := by
          rw [hm_glob_other "ev" (by decide)]; exact hevw
        have hsp_ne1024 : spw ≠ 1024#64 := by
          intro heq; subst heq
          have : (1024#64 : BitVec 64).toNat = 1024 := rfl
          omega
        rw [evaluateHOLFiniteState_seq_line780, evaluateHOLFiniteState_ite]
        have hcmp_sp : @evalHOLExact 64 F _ m.toExact (fun a => Classical.propDecidable (m.memaddrs a))
            (.cmp .equal (.var .local (ofString "sp")) (.const 1024#64)) = some (.val (.word 0#64)) := by
          simp [evalHOLExact, hm_sp, Flapjack.Compiler.Encoders.Asm.wordCmpHOL, hsp_ne1024]
        rw [hcmp_sp]; simp only [↓reduceIte, evaluateHOLFiniteState_skip]
        have h0_eq : (0#64 : BitVec 64) = 0 := rfl
        simp only [h0_eq, ↓reduceIte, evaluateHOLFiniteState_skip]
        rw [evaluateHOLFiniteState_seq_line780]
        let dstStkExp : ExpHOL 64 :=
          .op .add
            [.load .one (.op .add [.var .global (ofString "ev"), .const 8#64]),
             .panop .mul [.var .local (ofString "sp"), .const 32#64]]
        rcases hst_v : evaluateHOLFiniteState m (.store dstStkExp (.var .local (ofString "v"))) with ⟨rv_st, m1⟩
        simp only [hst_v]
        cases rv_st with
        | some res_v =>
          have herr := store_some_eq_error' hst_v; subst herr; dsimp only; exact herr_triv
        | none =>
          dsimp only
          have hstk_ptr_bound : memW m (globN s "ev" + 8) + 32 * memW m (globN s "ev" + 232) ≤ 2 ^ 64 := by
            rcases hnew_m with ⟨_, h8_eq, h232_eq⟩ | ⟨hnz, hstk_eq⟩
            · rw [h8_eq, h232_eq]
              obtain ⟨_, hin2⟩ := (hFW0.1 (memW s (globN s "ev" + 8), 32 * memW s (globN s "ev" + 232)) (by simp)).1
              rw [R11Shards.scratchEnd_val] at hin2; dsimp only at hin2; omega
            · rcases hfresh_m with rfl | ⟨_, _, _, hfin2⟩
              · exact absurd rfl hnz
              · have h4 := hInv.1.2.2.2.2.2.1; rw [R11Shards.scratchEnd_val] at h4
                rw [← hstk_eq] at hfin2; dsimp only at hfin2; omega
          have hd_v_stk := ScratchByteEff.of_store_struct4
            (Rl := [freshIvl, (memW s (globN s "ev" + 8), 32 * memW s (globN s "ev" + 232))])
            hAm.1.memaddrs hst_v
            (fun v hv => by
              change m.locals.lookup (ofString "v") = some v at hv
              rw [hm_v] at hv; injection hv with hv'; exact ⟨vw0, vw1, vw2, vw3, hv'.symm⟩)
            (fun addr hdst => by
              dsimp only [dstStkExp] at hdst
              have hmem_load8 : ∃ stkw : BitVec 64, m.memory (evw + 8#64) = .word stkw ∧
                  addr = stkw + spw * 32#64 := by
                rcases hm8 : m.memory (evw + 8#64) with ⟨stkw⟩
                refine ⟨stkw, rfl, ?_⟩
                simp [evalHOLExact, evalListHOLExact, hm_ev, hm_sp,
                  wordOpHOL, wordOp, panOpHOL, valueIsWord, valueWord, memLoadHOLExact, hm8] at hdst
                by_cases hdm8 : m.memaddrs (evw + 8#64)
                · simp [hdm8, valueIsWord, valueWord] at hdst; exact hdst.symm
                · simp [hdm8] at hdst
              obtain ⟨stkw, hm8, haddr_eq⟩ := hmem_load8
              have hev8_eq : evw + 8#64 = BitVec.ofNat 64 (globN s "ev" + 8) := by
                apply BitVec.eq_of_toNat_eq
                have : (8#64 : BitVec 64).toNat = 8 := rfl
                rw [BitVec.toNat_add, hevw_nat, this, BitVec.toNat_ofNat]
              have hstkw_nat : stkw.toNat = memW m (globN s "ev" + 8) := by
                unfold memW; rw [← hev8_eq, hm8]
              have hsp32_nat : (spw * 32#64).toNat = 32 * spw.toNat := by
                have : (32#64 : BitVec 64).toNat = 32 := rfl
                rw [BitVec.toNat_mul, this, Nat.mod_eq_of_lt (by omega)]; omega
              have haddr_nat : addr.toNat = memW m (globN s "ev" + 8) + 32 * spw.toNat := by
                rw [haddr_eq, BitVec.toNat_add, hstkw_nat, hsp32_nat, Nat.mod_eq_of_lt (by omega)]
              refine ⟨by omega, ?_⟩
              rcases hnew_m with ⟨_, h8_eq, h232_eq⟩ | ⟨_, hstk_eq⟩
              · exact ⟨(memW s (globN s "ev" + 8), 32 * memW s (globN s "ev" + 232)),
                  by simp, by dsimp only; omega, by dsimp only; omega⟩
              · refine ⟨freshIvl, by simp, ?_, ?_⟩
                · rw [← hstk_eq]; dsimp only; omega
                · rw [← hstk_eq]; dsimp only; omega)
          obtain ⟨heff_st_v_stk, hm1_loc, hm1_glob⟩ := hd_v_stk
          have heff_st_v : ScratchByteEff m m1
              [freshIvl, (globN s "ev", 280), (memW s (globN s "ev" + 8), 32 * memW s (globN s "ev" + 232))] :=
            heff_st_v_stk.mono (fun x hx => by
              simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
              rcases hx with hx1 | hx2
              · rw [hx1]; exact ⟨_, List.mem_cons_self, le_refl _, le_refl _⟩
              · rw [hx2]; exact ⟨_, List.mem_cons_of_mem _ (List.mem_cons_of_mem _ List.mem_cons_self), le_refl _, le_refl _⟩)
          have hm1_e0_eq : ∀ off, off + 8 ≤ 280 → off % 8 = 0 →
              memW m1 (globN s "ev" + off) = memW m (globN s "ev" + off) := by
            intro off hoff hoff8
            unfold memW
            rw [heff_st_v_stk.cell_frame (BitVec.ofNat 64 (globN s "ev" + off))]
            intro x hx
            have htn : (BitVec.ofNat 64 (globN s "ev" + off)).toNat = globN s "ev" + off :=
              Nat.mod_eq_of_lt (by omega)
            rw [htn]
            have he0_8 : (globN s "ev") % 8 = 0 := (hFW0.1 (globN s "ev", 280) (by simp)).2.1
            have ha8 : (globN s "ev" + off) % 8 = 0 := by omega
            simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
            rcases hx with rfl | rfl
            · rcases hfresh_m with rfl | ⟨hf8, _, _, hfin2⟩
              · intro ⟨_, hc2⟩; dsimp only at hc2; omega
              · obtain ⟨he0_scr, _⟩ := (hFW0.1 (globN s "ev", 280) (by simp)).1
                exact not_cellHits_of_disj_aligned (i := (globN s "ev", 280)) ha8 hf8
                  (Nat.le_add_right _ off) (Nat.add_le_add_left hoff _)
                  (Or.inr (Or.inr (Or.inr (by dsimp only at he0_scr ⊢; omega))))
            · have hold_8 : (memW s (globN s "ev" + 8)) % 8 = 0 :=
                (hFW0.1 (memW s (globN s "ev" + 8), 32 * memW s (globN s "ev" + 232)) (by simp)).2.1
              have hpw_fo := hInv.2.choose_spec.2.2.2.2.2.2.2.1
              have hch_s : ∃ tl, evmChain s = (globN s "ev", globN s "cur_cont") :: tl := ⟨_, rfl⟩
              obtain ⟨tl_s, hch_s_eq⟩ := hch_s
              rw [hch_s_eq, List.map_cons, List.flatten_cons, List.pairwise_append] at hpw_fo
              have hd_stk : Disj (globN s "ev", 280) (memW s (globN s "ev" + 8), 32 * memW s (globN s "ev" + 232)) := by
                have hp0 := hpw_fo.1; unfold frameObjects at hp0
                exact (List.pairwise_cons.1 hp0).1 _ (by simp)
              exact not_cellHits_of_disj_aligned (i := (globN s "ev", 280)) ha8 hold_8
                (Nat.le_add_right _ off) (Nat.add_le_add_left hoff _) hd_stk
          rw [evaluateHOLFiniteState_seq_line780]
          rcases hst_sp : evaluateHOLFiniteState m1
              (.store (.op .add [.var .global (ofString "ev"), .const 16#64])
                (.op .add [.var .local (ofString "sp"), .const 1#64])) with ⟨rsp_st, m2⟩
          simp only [hst_sp]
          cases rsp_st with
          | some res_sp =>
            have herr := store_some_eq_error' hst_sp; subst herr; dsimp only; exact herr_triv
          | none =>
            dsimp only
            have hm1_ev : m1.globals.lookup (ofString "ev") = some (.val (.word evw)) := by
              rw [hm1_glob]; exact hm_ev
            have hm1_sp : m1.locals.lookup (ofString "sp") = some (.val (.word spw)) := by
              rw [hm1_loc]; exact hm_sp
            obtain ⟨w_sp1, hw_sp1_ev, hm2_eq⟩ := R14Shards.OpHandlersA.store_global_off_word (t := m1) (post := m2)
              (gname := "ev") (gbase := globN s "ev") (off := 16) hm1_ev hevw_nat (by omega)
              (fun v hv => by
                simp [evalHOLExact, evalListHOLExact, hm1_sp, wordOpHOL, wordOp, valueIsWord, valueWord] at hv
                exact ⟨_, hv.symm⟩) hst_sp
            have hw_sp1_val : w_sp1 = spw + 1#64 := by
              simp [evalHOLExact, evalListHOLExact, hm1_sp, wordOpHOL, wordOp, valueIsWord, valueWord] at hw_sp1_ev
              exact hw_sp1_ev.symm
            subst hw_sp1_val
            have heff_st_sp := (ByteRegionEffect.of_store_word (Rl := [(globN s "ev", 280)])
              (heff_st_v.memaddrs.trans hAm.1.memaddrs) hst_sp
              (fun v hv => by
                simp [evalHOLExact, evalListHOLExact, hm1_sp, wordOpHOL, wordOp, valueIsWord, valueWord] at hv
                exact ⟨_, hv.symm⟩)
              (fun addr hdst _ => by
                simp [evalHOLExact, evalListHOLExact, hm1_ev, wordOpHOL, wordOp, valueIsWord, valueWord] at hdst
                have h16_eq : (evw + 16#64).toNat = globN s "ev" + 16 := by
                  have : (16#64 : BitVec 64).toNat = 16 := rfl
                  rw [BitVec.toNat_add, hevw_nat, this, Nat.mod_eq_of_lt (by omega)]
                exact ⟨(globN s "ev", 280), by simp, by rw [← hdst, h16_eq]; dsimp only; omega,
                  by rw [← hdst, h16_eq]; dsimp only; omega⟩)).1
            have heff_st_sp_sbe : ScratchByteEff m1 m2
                [freshIvl, (globN s "ev", 280), (memW s (globN s "ev" + 8), 32 * memW s (globN s "ev" + 232))] :=
              (ScratchByteEff.of_bre heff_st_sp).mono (fun x hx => by
                simp at hx; subst hx; exact ⟨(globN s "ev", 280), by simp, le_refl _, le_refl _⟩)
            rw [evaluateHOLFiniteState_return]
            have hc0_m2 : @evalHOLExact 64 F _ m2.toExact (fun a => Classical.propDecidable (m2.memaddrs a)) (.const (0 : BitVec 64)) =
                some (.val (.word 0)) := rfl
            have hc0_m2' : @evalHOLExact 64 F _ m2.toExact (fun a => Classical.propDecidable (m2.memaddrs a)) (.const 0#64) =
                some (.val (.word 0#64)) := rfl
            simp only [hc0_m2, hc0_m2']
            have hsz0 : sizeOfShapeWithContextHOL m2.structs
                (shapeOfHOLExact (.val (.word (0 : BitVec 64)))) ≤ 32 := by
              simp [shapeOfHOLExact, sizeOfShapeWithContextHOL]
            have hsz0' : sizeOfShapeWithContextHOL m2.structs
                (shapeOfHOLExact (.val (.word 0#64))) ≤ 32 := by
              simp [shapeOfHOLExact, sizeOfShapeWithContextHOL]
            simp only [hsz0, hsz0', ↓reduceIte]
            let post := { m2.emptyLocalsHOLFinite with
              locals := (m2.emptyLocalsHOLFinite.locals.resVarEq (ofString "cap", s1.locals.lookup (ofString "cap"))).resVarEq
                (ofString "sp", s.locals.lookup (ofString "sp")) }
            have heff_total : ScratchByteEff s post
                [freshIvl, (globN s "ev", 280), (memW s (globN s "ev" + 8), 32 * memW s (globN s "ev" + 232))] :=
              ((heff_m.trans heff_st_v).trans heff_st_sp_sbe).with_locals_clock post.locals m2.clock
            have hpost_glob_m : post.globals = m.globals := by
              simp [post, emptyLocalsHOLFinite, hm2_eq, hm1_glob]
            have hApost : ArenaReady post :=
              ⟨guestInv_congr (s := m) (by simp [post, emptyLocalsHOLFinite, hm2_eq, heff_st_v.code])
                (by simp [post, emptyLocalsHOLFinite, hm2_eq, heff_st_v.memaddrs])
                (by simp [post, emptyLocalsHOLFinite, hm2_eq, heff_st_v.shMemaddrs])
                (by simp [post, emptyLocalsHOLFinite, hm2_eq, heff_st_v.baseAddr]) hAm.1,
               arenaOK_congr hpost_glob_m hAm.2⟩
            have hsc_post : globN post "scratch_ptr" ≤ globN s "scratch_ptr" := by
              unfold globN; rw [hpost_glob_m]; exact hsc_m
            have hfresh_post : freshIvl = (0, 0) ∨
                (freshIvl.1 % 8 = 0 ∧ freshIvl.2 % 8 = 0 ∧
                  Inside freshIvl (globN post "scratch_ptr") (globN s "scratch_ptr")) := by
              unfold globN; rw [hpost_glob_m]; exact hfresh_m
            have hm2_memW_ne16 : ∀ off, off + 8 ≤ 280 → off % 8 = 0 → off ≠ 16 →
                memW post (globN s "ev" + off) = memW m (globN s "ev" + off) := by
              intro off hoff hoff8 hne16
              change memW m2 (globN s "ev" + off) = memW m (globN s "ev" + off)
              rw [hm2_eq, R14Shards.OpHandlersA.memW_updW_ne m1 (globN s "ev" + 16) (globN s "ev" + off) _ (by omega) (by omega) (by omega),
                  hm1_e0_eq off hoff hoff8]
            have hm2_memW_16 : memW post (globN s "ev" + 16) = spw.toNat + 1 := by
              change memW m2 (globN s "ev" + 16) = spw.toNat + 1
              rw [hm2_eq, R14Shards.OpHandlersA.memW_updW_same m1 (globN s "ev" + 16) (spw + 1#64)]
              have : (1#64 : BitVec 64).toNat = 1 := rfl
              rw [BitVec.toNat_add, this, Nat.mod_eq_of_lt (by omega)]
            have he0_post : ∀ off, off + 8 ≤ 280 → off % 8 = 0 → off ≠ 8 → off ≠ 16 → off ≠ 232 →
                memW post (globN s "ev" + off) = memW s (globN s "ev" + off) := by
              intro off hoff hoff8 h8 h16 h232
              rw [hm2_memW_ne16 off hoff hoff8 h16, he0_m off hoff hoff8 h8 h16 h232]
            have hnew_post :
                (freshIvl.2 = 0 ∧ memW post (globN s "ev" + 8) = memW s (globN s "ev" + 8) ∧
                  memW post (globN s "ev" + 232) = memW s (globN s "ev" + 232)) ∨
                (freshIvl.2 ≠ 0 ∧ (memW post (globN s "ev" + 8), 32 * memW post (globN s "ev" + 232)) = freshIvl) := by
              rw [hm2_memW_ne16 8 (by omega) (by omega) (by omega),
                  hm2_memW_ne16 232 (by omega) (by omega) (by omega)]
              exact hnew_m
            have hcap_post :
                1 ≤ memW post (globN s "ev" + 232) ∧
                memW post (globN s "ev" + 16) ≤ memW post (globN s "ev" + 232) ∧
                memW post (globN s "ev" + 232) ≤ 1024 := by
              rw [hm2_memW_ne16 232 (by omega) (by omega) (by omega), hm2_memW_16]
              exact ⟨by omega, by omega, hmcap_le⟩
            obtain ⟨_, hch_p, _⟩ := evmInv_of_head_stack_push hInv hApost hsc_post
              heff_total hfresh_post he0_post hnew_post hcap_post
            have hHMWF_g10 : Group10.HeadMemChainWF post :=
              headMemChainWF_of_head_stack_push_c1 hInv
                ((headMemChainWF_g10_iff_bridge s).mpr hWF) hApost
                heff_total hfresh_post he0_post hch_p
            have hgo_post : ∀ g : String, ofString g ≠ ofString "scratch_ptr" →
                globN post g = globN s g := by
              intro g hg
              have hlk : post.globals.lookup (ofString g) = s.globals.lookup (ofString g) := by
                rw [hpost_glob_m]; exact hm_glob_other g hg
              exact R16Shards.OpHandlers.globN_eq_of_lookup_eq hlk
            have hsys_p : Inside (globN post "vm_system_address", 20) sourceBase
                (globN post "heap_ptr") :=
              sysInside_congr_scratch hgo_post hInvR32.sysInside
            have hev8 : globN s "ev" % 8 = 0 :=
              (hFW0.1 (globN s "ev", 280) (by simp)).2.1
            have hstk8 : memW s (globN s "ev" + 8) % 8 = 0 :=
              (hFW0.1 (memW s (globN s "ev" + 8), 32 * memW s (globN s "ev" + 232)) (by simp)).2.1
            have hRl8 : ∀ x ∈ ([freshIvl, (globN s "ev", 280),
                (memW s (globN s "ev" + 8), 32 * memW s (globN s "ev" + 232))] : List Ivl),
                x.1 % 8 = 0 := by
              intro x hx
              simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
              rcases hx with rfl | rfl | rfl
              · rcases hfresh_post with rfl | ⟨hf8, _, _, _⟩
                · rfl
                · exact hf8
              · exact hev8
              · exact hstk8
            have hRl_avoid : ∀ x ∈ ([freshIvl, (globN s "ev", 280),
                (memW s (globN s "ev" + 8), 32 * memW s (globN s "ev" + 232))] : List Ivl),
                x.2 = 0 ∨
                ((x ∈ frameObjects s (globN s "ev", globN s "cur_cont") ∧
                  Inside x (globN s "scratch_ptr") scratchEnd) ∨
                  Inside x (globN post "scratch_ptr") (globN s "scratch_ptr")) := by
              intro x hx
              simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
              rcases hx with rfl | rfl | rfl
              · rcases hfresh_post with rfl | ⟨_, _, hfin2⟩
                · exact Or.inl rfl
                · exact Or.inr (Or.inr hfin2)
              · exact Or.inr (Or.inl
                  ⟨by simp [frameObjects], (hFW0.1 (globN s "ev", 280) (by simp)).1⟩)
              · exact Or.inr (Or.inl
                  ⟨by simp [frameObjects],
                    (hFW0.1 (memW s (globN s "ev" + 8), 32 * memW s (globN s "ev" + 232)) (by simp)).1⟩)
            have hdb_p : StorageCreateFinish.WitnessDbOK post :=
              witnessDbOK_of_scratchEff hInv hInvR32.witnessDbOK hApost heff_total
                hsc_post hRl8 hRl_avoid
            have hres : StorageCreateFinish.WitnessDbOK post ∧
                Inside (globN post "vm_system_address", 20) sourceBase (globN post "heap_ptr") ∧
                HeadMemBridge.HeadMemChainWF post :=
              ⟨hdb_p, hsys_p, (headMemChainWF_g10_iff_bridge post).mp hHMWF_g10⟩
            constructor
            · intro _ _; exact hres
            · rintro ⟨_, h⟩; cases h
      rw [evaluateHOLFiniteState_seq_line780, evaluateHOLFiniteState_ite] at hnt ⊢
      have hcmp_grow : @evalHOLExact 64 F _ s2.toExact (fun a => Classical.propDecidable (s2.memaddrs a))
          (.cmp .notLower (.var .local (ofString "sp")) (.var .local (ofString "cap"))) =
          some (.val (.word (if capw ≤ spw then 1 else 0))) := by
        simp only [evalHOLExact, hs2_sp, hs2_cap, Flapjack.Compiler.Encoders.Asm.wordCmpHOL, BitVec.lt_def, BitVec.le_def]
        by_cases hle : capw.toNat ≤ spw.toNat
        · have hnot : ¬ spw.toNat < capw.toNat := by omega
          simp [hle, hnot]
        · have hlt : spw.toNat < capw.toNat := by omega
          simp [hle, hlt]
      rw [hcmp_grow] at hnt ⊢; dsimp only at hnt ⊢
      by_cases hgrow : capw ≤ spw
      · have hsp_eq_cap : spw.toNat = capw.toNat := by
          rw [BitVec.le_def] at hgrow; omega
        have h10 : ¬ ((1 : BitVec 64) = 0) := by decide
        simp only [hgrow, ↓reduceIte, h10] at hnt ⊢
        dsimp only [growBranch] at hnt ⊢
        rw [evaluateHOLFiniteState_seq_line780, evaluateHOLFiniteState_ite] at hnt ⊢
        have hcmp_cap1024 : @evalHOLExact 64 F _ s2.toExact (fun a => Classical.propDecidable (s2.memaddrs a))
            (.cmp .notLower (.var .local (ofString "cap")) (.const 1024#64)) =
            some (.val (.word (if 1024 ≤ capw.toNat then 1 else 0))) := by
          have h1024 : (1024#64 : BitVec 64).toNat = 1024 := rfl
          simp only [evalHOLExact, hs2_cap, Flapjack.Compiler.Encoders.Asm.wordCmpHOL, BitVec.lt_def, h1024]
          by_cases hle : 1024 ≤ capw.toNat
          · have hnot : ¬ capw.toNat < 1024 := by omega
            simp [hle, hnot]
          · have hlt : capw.toNat < 1024 := by omega
            simp [hle, hlt]
        rw [hcmp_cap1024] at hnt ⊢; dsimp only at hnt ⊢
        by_cases hcap1024 : 1024 ≤ capw.toNat
        · simp only [hcap1024, ↓reduceIte, h10] at hnt ⊢
          rcases hr3 : evaluateHOLFiniteState s2 (.raise (ofString "EvmErr") (.const 3#64)) with ⟨rr3, sr3⟩
          have hr3_nn : rr3 ≠ none := by
            intro h; subst h; exact raise_ne_none s2 _ (.const 3#64) (by rw [hr3])
          simp only [hr3]
          cases rr3 with
          | none => exact absurd rfl hr3_nn
          | some _ =>
            dsimp only
            have hru := raise3_unchanged_hmwf_c1 (s := s) (t := s2) hInvR32
              ((headMemChainWF_g10_iff_bridge s).mpr hWF)
              (fun L => (L.resVarEq (ofString "cap", s1.locals.lookup (ofString "cap"))).resVarEq
                (ofString "sp", s.locals.lookup (ofString "sp")))
              (by cases s; rfl)
            dsimp only at hru; rw [hr3] at hru; exact hru
        · have hcap_lt1024 : capw.toNat < 1024 := by omega
          simp only [hcap1024, ↓reduceIte, evaluateHOLFiniteState_skip] at hnt ⊢
          rw [evaluateHOLFiniteState_dec_total] at hnt ⊢; dsimp only at hnt ⊢
          have hmul2 : @evalHOLExact 64 F _ s2.toExact (fun a => Classical.propDecidable (s2.memaddrs a))
              (.panop .mul [.var .local (ofString "cap"), .const 2#64]) =
              some (.val (.word (capw * 2#64))) := by
            simp [evalHOLExact, evalListHOLExact, hs2_cap, panOpHOL, valueIsWord, valueWord]
          rw [hmul2] at hnt ⊢; dsimp only at hnt ⊢
          have hsh_ncap : shapeEqHOL .one (shapeOfHOLExact (.val (.word (capw * 2#64)))) = true := by
            simp [shapeEqHOL, shapeOfHOLExact]
          rw [if_pos hsh_ncap] at hnt ⊢; dsimp only at hnt ⊢
          set s3 := setVarHOLFinite (ofString "ncap") (.val (.word (capw * 2#64))) s2 with hs3
          have hncap0_nat : (capw * 2#64).toNat = 2 * capw.toNat := by
            have : (2#64 : BitVec 64).toNat = 2 := rfl
            rw [BitVec.toNat_mul, this, Nat.mod_eq_of_lt (by omega)]; omega
          have hite_ncap : ∃ (s4 : PanSemStateFiniteExact 64 F) (ncapw : BitVec 64),
              evaluateHOLFiniteState s3
                (.ite (.cmp .lower (.const 1024#64) (.var .local (ofString "ncap")))
                  (.assign .local (ofString "ncap") (.const 1024#64))
                  .skip) = (none, s4) ∧
              s4 = { s with locals := s4.locals, clock := s.clock } ∧
              s4.locals.lookup (ofString "ncap") = some (.val (.word ncapw)) ∧
              s4.locals.lookup (ofString "sp") = some (.val (.word spw)) ∧
              s4.locals.lookup (ofString "v") =
                some (.rStruct [.val (.word vw0), .val (.word vw1), .val (.word vw2), .val (.word vw3)]) ∧
              capw.toNat < ncapw.toNat ∧ ncapw.toNat ≤ 1024 := by
            have hs3_ncap : s3.locals.lookup (ofString "ncap") = some (.val (.word (capw * 2#64))) := by
              simp [hs3, setVarHOLFinite, HolFiniteMapExact.lookup_update, FUPDATE]
            rw [evaluateHOLFiniteState_ite]
            have hcmp_nc : @evalHOLExact 64 F _ s3.toExact (fun a => Classical.propDecidable (s3.memaddrs a))
                (.cmp .lower (.const 1024#64) (.var .local (ofString "ncap"))) =
                some (.val (.word (if 1024#64 < capw * 2#64 then 1 else 0))) := by
              simp [evalHOLExact, hs3_ncap, Flapjack.Compiler.Encoders.Asm.wordCmpHOL]
            rw [hcmp_nc]; dsimp only
            by_cases hgt1024 : 1024#64 < capw * 2#64
            · simp only [hgt1024, ↓reduceIte, h10, evaluateHOLFiniteState_assign]
              have hev1024 : @evalHOLExact 64 F _ s3.toExact (fun a => Classical.propDecidable (s3.memaddrs a))
                  (.const 1024#64) = some (.val (.word 1024#64)) := rfl
              have hval1024 : s3.isValidValueHOLFinite .local (ofString "ncap") (.val (.word 1024#64)) = true := by
                simp [isValidValueHOLFinite, isValidValueHOLExact, lookupKvarHOLExact, hs3_ncap, shapeOfHOLExact, shapeEqHOL]
              rw [hev1024]; dsimp only; rw [if_pos hval1024]
              let s4 := setKvarHOLFinite .local (ofString "ncap") (.val (.word 1024#64)) s3
              have h1024_n : (1024#64 : BitVec 64).toNat = 1024 := rfl
              refine ⟨s4, 1024#64, rfl, by cases s; rfl, ?_, ?_, ?_, by omega, by omega⟩
              · simp [s4, setKvarHOLFinite, setVarHOLFinite, HolFiniteMapExact.lookup_update, FUPDATE]
              · simp [s4, hs3, setKvarHOLFinite, setVarHOLFinite, HolFiniteMapExact.lookup_update, FUPDATE, hs2_sp,
                  show ofString "ncap" ≠ ofString "sp" by decide]
              · simp [s4, hs3, setKvarHOLFinite, setVarHOLFinite, HolFiniteMapExact.lookup_update, FUPDATE, hs2_v,
                  show ofString "ncap" ≠ ofString "v" by decide]
            · simp only [hgt1024, ↓reduceIte, evaluateHOLFiniteState_skip]
              have hle1024 : (capw * 2#64).toNat ≤ 1024 := by
                rw [BitVec.lt_def] at hgt1024
                have : (1024#64 : BitVec 64).toNat = 1024 := rfl
                omega
              refine ⟨s3, capw * 2#64, rfl, by cases s; rfl, hs3_ncap, ?_, ?_, by omega, hle1024⟩
              · simp [hs3, setVarHOLFinite, HolFiniteMapExact.lookup_update, FUPDATE, hs2_sp,
                  show ofString "ncap" ≠ ofString "sp" by decide]
              · simp [hs3, setVarHOLFinite, HolFiniteMapExact.lookup_update, FUPDATE, hs2_v,
                  show ofString "ncap" ≠ ofString "v" by decide]
          obtain ⟨s4, ncapw, hs4_run, hs4_eq, hs4_ncap, hs4_sp, hs4_v, hncap_gt, hncap_le1024⟩ := hite_ncap
          rw [evaluateHOLFiniteState_seq_line780, hs4_run] at hnt ⊢; dsimp only at hnt ⊢
          rw [evaluateHOLFiniteState_decCall_fixClockRewrite] at hnt ⊢
          have hargs_sa : evalListHOLFinite s4 (h := fun a => Classical.propDecidable (s4.memaddrs a))
              [.panop .mul [.var .local (ofString "ncap"), .const 32#64]] =
              some [.val (.word (ncapw * 32#64))] := by
            simp [evalListHOLFinite, evalListHOLExact, evalHOLExact, hs4_ncap, panOpHOL, valueIsWord, valueWord]
          have hs4_code : s4.code = originalRuntimeCode := by rw [hs4_eq]; exact hcode
          have hlk_sa := pan_one_word_lookup s4.code.lookup (ofString "scratch_alloc") (ofString "n")
            (sourceFnBody Guest.Software.guestFn_scratch_alloc) (ncapw * 32#64)
            (by rw [hs4_code]; exact scratch_alloc_lookup_pub)
          rw [hargs_sa] at hnt ⊢; dsimp only at hnt ⊢
          rw [hlk_sa] at hnt ⊢; dsimp only at hnt ⊢
          by_cases hs4_clk0 : s4.clock = 0
          · rw [if_pos hs4_clk0] at hnt; simp at hnt
          · rw [if_neg hs4_clk0] at hnt ⊢
            let saCallee := HolFiniteMapExact.empty.update (ofString "n", ValueHOL.val (.word (ncapw * 32#64)))
            let saEntry := callEntryStateHOLFinite s4 saCallee
            have hsa_code : saEntry.code = originalRuntimeCode := hs4_code
            have hsa_no_evmErr := scratch_alloc_body_no_evmErr saEntry hsa_code
            rcases hsa_run : evaluateHOLFiniteState saEntry
                (sourceFnBody Guest.Software.guestFn_scratch_alloc) with ⟨rsa, saPost⟩
            rw [hsa_run] at hsa_no_evmErr
            have hsa_run_raw : evaluateHOLFiniteState
                (callEntryStateHOLFinite s4 (HolFiniteMapExact.empty.update (ofString "n", ValueHOL.val (.word (ncapw * 32#64)))))
                (sourceFnBody Guest.Software.guestFn_scratch_alloc) = (rsa, saPost) := hsa_run
            simp only [hsa_run_raw] at hnt ⊢
            cases rsa with
            | none => exact herr_triv
            | some rsa0 =>
              cases rsa0 with
              | timeOut => simp at hnt
              | exception eid ev =>
                dsimp only at hnt ⊢
                by_cases heid : eid = ofString "EvmErr"
                · subst heid; exact absurd ⟨ev, rfl⟩ hsa_no_evmErr
                · constructor
                  · intro _ h; cases h
                  · rintro ⟨_, h⟩; injection h with h'; injection h' with h1 _; exact (heid h1).elim
              | «break» => exact herr_triv
              | «continue» => exact herr_triv
              | finalFfi _ =>
                constructor
                · intro _ h; cases h
                · rintro ⟨_, h⟩; cases h
              | error => exact herr_triv
              | returned vsa =>
                have hsa_sp_lk : saEntry.globals.lookup (ofString "scratch_ptr") = some (.val (.word sp_g_w)) := by
                  change s4.globals.lookup _ = _; rw [hs4_eq]; exact hsp_g_lk
                have hsa_fp_lk : saEntry.globals.lookup (ofString "frame_mem_ptr") = some (.val (.word fp_w)) := by
                  change s4.globals.lookup _ = _; rw [hs4_eq]; exact hfp_lk
                have hsa_n_lk : saEntry.locals.lookup (ofString "n") = some (.val (.word (ncapw * 32#64))) := by
                  simp [saEntry, saCallee, callEntryStateHOLFinite, HolFiniteMapExact.lookup_update, FUPDATE]
                obtain ⟨rfl, hcmp1_sa, hcmp2_sa, hsaPost_eq_raw⟩ :=
                  Wave8Contracts.M26.scratch_alloc_body_run saEntry sp_g_w fp_w (ncapw * 32#64)
                    hsa_code hsa_sp_lk hsa_fp_lk hsa_n_lk vsa (by rw [hsa_run])
                have hsaPost_eq : saPost = { saEntry with
                    globals := saEntry.globals.update (ofString "scratch_ptr", .val (.word ((sp_g_w - ncapw * 32#64) &&& ((0 : BitVec 64) - 8)))),
                    locals := saPost.locals } := by
                  rw [hsa_run] at hsaPost_eq_raw; exact hsaPost_eq_raw
                dsimp only [saEntry] at hsaPost_eq
                set nsw : BitVec 64 := (sp_g_w - ncapw * 32#64) &&& ((0 : BitVec 64) - 8)
                have hsh_ns : (shapeEqHOL (shapeOfHOLExact (.val (.word nsw) : ValueHOL 64)) .one &&
                    shapeEqHOL (shapeOfHOLExact (.val (.word nsw) : ValueHOL 64)) .one) = true := by
                  simp [shapeEqHOL, shapeOfHOLExact]
                have hsh_ns' : (shapeEqHOL (shapeOfHOLExact (.val (.word nsw) : ValueHOL 64)) .one &&
                    shapeEqHOL .one (shapeOfHOLExact (.val (.word nsw) : ValueHOL 64))) = true := by
                  simp [shapeEqHOL, shapeOfHOLExact]
                dsimp only at hnt ⊢
                simp only [hsh_ns, hsh_ns', ↓reduceIte] at hnt ⊢
                have hn_bytes : (ncapw * 32#64).toNat = 32 * ncapw.toNat := by
                  have : (32#64 : BitVec 64).toNat = 32 := rfl
                  rw [BitVec.toNat_mul, this, Nat.mod_eq_of_lt (by omega)]; omega
                have hsub_pf : (sp_g_w - fp_w).toNat = sp_g_w.toNat - fp_w.toNat := by
                  rw [BitVec.toNat_sub]
                  have hle_fp_sp : globN s "frame_mem_ptr" ≤ globN s "scratch_ptr" := hInv.1.2.2.2.2.1
                  omega
                have hsp_g_al : sp_g_w.toNat % 8 = 0 := by
                  have h8 : globN s "scratch_ptr" % 8 = 0 := hInv.1.2.2.2.2.2.2.2.2.1
                  rw [hsp_g_nat]; exact h8
                have hn_le_sp_g : (ncapw * 32#64).toNat ≤ sp_g_w.toNat := by
                  have := sp_g_w.isLt; have := fp_w.isLt; omega
                have hsub_pn : (sp_g_w - ncapw * 32#64).toNat = sp_g_w.toNat - 32 * ncapw.toNat := by
                  rw [BitVec.toNat_sub, hn_bytes]; omega
                have hnsw_nat : nsw.toNat = sp_g_w.toNat - 32 * ncapw.toNat := by
                  have hand := and_neg8_toNat (sp_g_w - ncapw * 32#64)
                  change nsw.toNat = (sp_g_w - ncapw * 32#64).toNat / 8 * 8 at hand
                  rw [hsub_pn] at hand; omega
                have hnsw_al : nsw.toNat % 8 = 0 := by omega
                have hnsw_ge_fp : globN s "frame_mem_ptr" ≤ nsw.toNat := by
                  rw [← hfp_nat]; exact Nat.le_of_not_lt hcmp2_sa
                have hnsw_end : nsw.toNat + 32 * ncapw.toNat = globN s "scratch_ptr" := by
                  rw [← hsp_g_nat]; omega
                set s5 := setVarHOLFinite (ofString "ns") (.val (.word nsw)) { saPost with locals := s4.locals } with hs5
                have hs5_ns : s5.locals.lookup (ofString "ns") = some (.val (.word nsw)) := by
                  simp [hs5, setVarHOLFinite, HolFiniteMapExact.lookup_update, FUPDATE]
                have hs5_ncap : s5.locals.lookup (ofString "ncap") = some (.val (.word ncapw)) := by
                  simp [hs5, setVarHOLFinite, HolFiniteMapExact.lookup_update, FUPDATE, hs4_ncap,
                    show ofString "ns" ≠ ofString "ncap" by decide]
                have hs5_sp : s5.locals.lookup (ofString "sp") = some (.val (.word spw)) := by
                  simp [hs5, setVarHOLFinite, HolFiniteMapExact.lookup_update, FUPDATE, hs4_sp,
                    show ofString "ns" ≠ ofString "sp" by decide]
                have hs5_v : s5.locals.lookup (ofString "v") =
                    some (.rStruct [.val (.word vw0), .val (.word vw1), .val (.word vw2), .val (.word vw3)]) := by
                  simp [hs5, setVarHOLFinite, HolFiniteMapExact.lookup_update, FUPDATE, hs4_v,
                    show ofString "ns" ≠ ofString "v" by decide]
                have hs5_mem : s5.memory = s.memory := by
                  change saPost.memory = s.memory; rw [hsaPost_eq]; dsimp only [callEntryStateHOLFinite]; rw [hs4_eq]
                have hs5_glob : s5.globals = s.globals.update (ofString "scratch_ptr", .val (.word nsw)) := by
                  change saPost.globals = _; rw [hsaPost_eq]; dsimp only [callEntryStateHOLFinite]; rw [hs4_eq]
                have hs5_code : s5.code = originalRuntimeCode := by
                  change saPost.code = _; rw [hsaPost_eq]; exact hsa_code
                have hs5_ma : s5.memaddrs = ordinaryDomain := by
                  change saPost.memaddrs = _; rw [hsaPost_eq]; dsimp only [callEntryStateHOLFinite]; rw [hs4_eq]; exact hInv.1.1.memaddrs
                have hs5_ev : s5.globals.lookup (ofString "ev") = some (.val (.word evw)) := by
                  rw [hs5_glob]; simp [HolFiniteMapExact.lookup_update, FUPDATE, hevw,
                    show ofString "scratch_ptr" ≠ ofString "ev" by decide]
                let mcCall : ProgHOL 64 :=
                  .call (some (none, none)) (ofString "memcpy")
                    [.var .local (ofString "ns"),
                     .load .one (.op .add [.var .global (ofString "ev"), .const 8#64]),
                     .panop .mul [.var .local (ofString "sp"), .const 32#64]]
                let st8Prog : ProgHOL 64 :=
                  .store (.op .add [.var .global (ofString "ev"), .const 8#64]) (.var .local (ofString "ns"))
                let st232Prog : ProgHOL 64 :=
                  .store (.op .add [.var .global (ofString "ev"), .const 232#64]) (.var .local (ofString "ncap"))
                rcases hs5_m8 : s5.memory (evw + 8#64) with ⟨oldStkw⟩
                have hs5_dom8 : s5.memaddrs (evw + 8#64) := by
                  rw [hs5_ma, hInv.1.1.memaddrs.symm]
                  have hev8_eq : evw + 8#64 = BitVec.ofNat 64 (globN s "ev" + 8) := by
                    apply BitVec.eq_of_toNat_eq
                    have : (8#64 : BitVec 64).toNat = 8 := rfl
                    rw [BitVec.toNat_add, hevw_nat, this, BitVec.toNat_ofNat]
                  rw [hev8_eq]
                  exact ((hFW0.1 (globN s "ev", 280) (by simp)).2.2.2 1 (by omega)).choose_spec.1
                have hev_mc_src : @evalHOLExact 64 F _ s5.toExact (fun a => Classical.propDecidable (s5.memaddrs a))
                    (.load .one (.op .add [.var .global (ofString "ev"), .const 8#64])) =
                    some (.val (.word oldStkw)) := by
                  simp [evalHOLExact, evalListHOLExact, hs5_ev, wordOpHOL, wordOp, valueIsWord, valueWord,
                    memLoadHOLExact, hs5_dom8, hs5_m8]
                have hev_mc_dst : @evalHOLExact 64 F _ s5.toExact (fun a => Classical.propDecidable (s5.memaddrs a))
                    (.var .local (ofString "ns")) = some (.val (.word nsw)) := hs5_ns
                have hev_mc_n : @evalHOLExact 64 F _ s5.toExact (fun a => Classical.propDecidable (s5.memaddrs a))
                    (.panop .mul [.var .local (ofString "sp"), .const 32#64]) =
                    some (.val (.word (spw * 32#64))) := by
                  simp [evalHOLExact, evalListHOLExact, hs5_sp, panOpHOL, valueIsWord, valueWord]
                have hsp32_nat : (spw * 32#64).toNat = 32 * spw.toNat := by
                  have : (32#64 : BitVec 64).toNat = 32 := rfl
                  rw [BitVec.toNat_mul, this, Nat.mod_eq_of_lt (by omega)]; omega
                let freshIvl : Ivl := (nsw.toNat, 32 * ncapw.toNat)
                have hnt_mc : (evaluateHOLFiniteState s5 mcCall).1 ≠ some .timeOut := by
                  intro hto
                  rcases hmc_to : evaluateHOLFiniteState s5
                      (.call (some (none, none)) (ofString "memcpy")
                        [.var .local (ofString "ns"),
                         .load .one (.op .add [.var .global (ofString "ev"), .const 8#64]),
                         .panop .mul [.var .local (ofString "sp"), .const 32#64]]) with ⟨rmc_to, smc_to⟩
                  have hto' : rmc_to = some .timeOut := by
                    dsimp only [mcCall] at hto; rw [hmc_to] at hto; exact hto
                  subst hto'
                  rw [evaluateHOLFiniteState_seq_line780] at hnt
                  simp [hmc_to] at hnt
                have hmc := M11.eval_call_memcpy_bre s5 _ _ _ nsw oldStkw (spw * 32#64) [freshIvl]
                  hs5_code hs5_ma hev_mc_dst hev_mc_src hev_mc_n
                  (fun _ => ⟨freshIvl, by simp, le_refl _, by dsimp only [freshIvl]; omega⟩) hnt_mc
                dsimp only at hmc
                rw [evaluateHOLFiniteState_seq_line780] at hnt ⊢
                rcases hmc_run : evaluateHOLFiniteState s5 mcCall with ⟨rmc, s6⟩
                rw [hmc_run] at hmc
                have hmc_run_raw : evaluateHOLFiniteState s5
                    (.call (some (none, none)) (ofString "memcpy")
                      [.var .local (ofString "ns"),
                       .load .one (.op .add [.var .global (ofString "ev"), .const 8#64]),
                       .panop .mul [.var .local (ofString "sp"), .const 32#64]]) = (rmc, s6) := hmc_run
                simp only [hmc_run_raw] at hnt ⊢
                cases rmc with
                | some rmc0 =>
                  dsimp only at hnt ⊢
                  have hnr := hmc.2 (by simp)
                  refine ⟨fun v hv => absurd (Or.inl ⟨v, hv⟩) hnr, ?_⟩
                  rintro ⟨ev, hv⟩
                  injection hv with hv'; subst hv'
                  exact absurd (Or.inr ⟨ofString "EvmErr", ev, rfl, by decide⟩) hnr
                | none =>
                  dsimp only at hnt ⊢
                  obtain ⟨heff_mc_m11, hs6_loc⟩ := hmc.1 rfl
                  have heff_mc : ScratchByteEff s5 s6 [freshIvl] := ScratchByteEff.of_m11_bre heff_mc_m11
                  rw [evaluateHOLFiniteState_seq_line780] at hnt ⊢
                  rcases hst8 : evaluateHOLFiniteState s6 st8Prog with ⟨rst8, s7⟩
                  have hst8_raw : evaluateHOLFiniteState s6
                      (.store (.op .add [.var .global (ofString "ev"), .const 8#64]) (.var .local (ofString "ns"))) = (rst8, s7) := hst8
                  simp only [hst8_raw] at hnt ⊢
                  cases rst8 with
                  | some res8 =>
                    have herr := store_some_eq_error' hst8; subst herr; dsimp only; exact herr_triv
                  | none =>
                    dsimp only at hnt ⊢
                    have hs6_ev : s6.globals.lookup (ofString "ev") = some (.val (.word evw)) := by
                      rw [heff_mc_m11.globals]; exact hs5_ev
                    have hs6_ns : s6.locals.lookup (ofString "ns") = some (.val (.word nsw)) := by
                      rw [hs6_loc]; exact hs5_ns
                    obtain ⟨w_ns', hw_ns_ev, hs7_eq⟩ := R14Shards.OpHandlersA.store_global_off_word (t := s6) (post := s7)
                      (gname := "ev") (gbase := globN s "ev") (off := 8) hs6_ev hevw_nat (by omega)
                      (fun v hv => by
                        change s6.locals.lookup (ofString "ns") = some v at hv
                        rw [hs6_ns] at hv; injection hv with hv'; exact ⟨nsw, hv'.symm⟩) hst8
                    have hw_ns_val : nsw = w_ns' := by
                      change s6.locals.lookup (ofString "ns") = some (.val (.word w_ns')) at hw_ns_ev
                      rw [hs6_ns] at hw_ns_ev
                      injection hw_ns_ev with h1; injection h1 with h2; injection h2 with h3
                    subst w_ns'
                    have heff_st8 := (ByteRegionEffect.of_store_word (Rl := [(globN s "ev", 280)])
                      (heff_mc_m11.memaddrs.trans hs5_ma) hst8
                      (fun v hv => by
                        change s6.locals.lookup (ofString "ns") = some v at hv
                        rw [hs6_ns] at hv; injection hv with hv'; exact ⟨nsw, hv'.symm⟩)
                      (fun addr hdst _ => by
                        simp [evalHOLExact, evalListHOLExact, hs6_ev, wordOpHOL, wordOp, valueIsWord, valueWord] at hdst
                        have h8_eq : (evw + 8#64).toNat = globN s "ev" + 8 := by
                          have : (8#64 : BitVec 64).toNat = 8 := rfl
                          rw [BitVec.toNat_add, hevw_nat, this, Nat.mod_eq_of_lt (by omega)]
                        exact ⟨(globN s "ev", 280), by simp, by rw [← hdst, h8_eq]; dsimp only; omega,
                          by rw [← hdst, h8_eq]; dsimp only; omega⟩)).1
                    rcases hst232 : evaluateHOLFiniteState s7 st232Prog with ⟨rst232, s8⟩
                    have hst232_raw : evaluateHOLFiniteState s7
                        (.store (.op .add [.var .global (ofString "ev"), .const 232#64]) (.var .local (ofString "ncap"))) = (rst232, s8) := hst232
                    simp only [hst232_raw] at hnt ⊢
                    cases rst232 with
                    | some res232 =>
                      have herr := store_some_eq_error' hst232; subst herr; dsimp only; exact herr_triv
                    | none =>
                      dsimp only at hnt ⊢
                      have hs7_ev : s7.globals.lookup (ofString "ev") = some (.val (.word evw)) := by
                        rw [hs7_eq]; exact hs6_ev
                      have hs7_ncap : s7.locals.lookup (ofString "ncap") = some (.val (.word ncapw)) := by
                        rw [hs7_eq]; dsimp only; rw [hs6_loc]; exact hs5_ncap
                      obtain ⟨w_ncap', hw_ncap_ev, hs8_eq⟩ := R14Shards.OpHandlersA.store_global_off_word (t := s7) (post := s8)
                        (gname := "ev") (gbase := globN s "ev") (off := 232) hs7_ev hevw_nat (by omega)
                        (fun v hv => by
                          change s7.locals.lookup (ofString "ncap") = some v at hv
                          rw [hs7_ncap] at hv; injection hv with hv'; exact ⟨ncapw, hv'.symm⟩) hst232
                      have hw_ncap_val : ncapw = w_ncap' := by
                        change s7.locals.lookup (ofString "ncap") = some (.val (.word w_ncap')) at hw_ncap_ev
                        rw [hs7_ncap] at hw_ncap_ev
                        injection hw_ncap_ev with h1; injection h1 with h2; injection h2 with h3
                      subst w_ncap'
                      have heff_st232 := (ByteRegionEffect.of_store_word (Rl := [(globN s "ev", 280)])
                        (by rw [hs7_eq]; exact heff_mc_m11.memaddrs.trans hs5_ma) hst232
                        (fun v hv => by
                          change s7.locals.lookup (ofString "ncap") = some v at hv
                          rw [hs7_ncap] at hv; injection hv with hv'; exact ⟨ncapw, hv'.symm⟩)
                        (fun addr hdst _ => by
                          simp [evalHOLExact, evalListHOLExact, hs7_ev, wordOpHOL, wordOp, valueIsWord, valueWord] at hdst
                          have h232_eq : (evw + 232#64).toNat = globN s "ev" + 232 := by
                            have : (232#64 : BitVec 64).toNat = 232 := rfl
                            rw [BitVec.toNat_add, hevw_nat, this, Nat.mod_eq_of_lt (by omega)]
                          exact ⟨(globN s "ev", 280), by simp, by rw [← hdst, h232_eq]; dsimp only; omega,
                            by rw [← hdst, h232_eq]; dsimp only; omega⟩)).1
                      let m : PanSemStateFiniteExact 64 F :=
                        { s8 with
                          locals := (s8.locals.resVarEq (ofString "ns", s4.locals.lookup (ofString "ns"))).resVarEq
                            (ofString "ncap", s2.locals.lookup (ofString "ncap")) }
                      change (let out := evaluateHOLFiniteState m tailProg
                        let post := { out.2 with
                          locals := (out.2.locals.resVarEq (ofString "cap", s1.locals.lookup (ofString "cap"))).resVarEq
                            (ofString "sp", s.locals.lookup (ofString "sp")) }
                        (∀ v, out.1 = some (.returned v) →
                          (StorageCreateFinish.WitnessDbOK post ∧
                            Inside (globN post "vm_system_address", 20) sourceBase (globN post "heap_ptr") ∧
                            HeadMemBridge.HeadMemChainWF post)) ∧
                        (IsEvmErr out.1 →
                          (StorageCreateFinish.WitnessDbOK post ∧
                            Inside (globN post "vm_system_address", 20) sourceBase (globN post "heap_ptr") ∧
                            HeadMemBridge.HeadMemChainWF post)))
                      have hm_glob : m.globals = s.globals.update (ofString "scratch_ptr", .val (.word nsw)) := by
                        dsimp only [m]; rw [hs8_eq, hs7_eq]; dsimp only; rw [heff_mc_m11.globals, hs5_glob]
                      have hm_sp_glob : globN m "scratch_ptr" = nsw.toNat := by
                        unfold globN; rw [hm_glob]; simp [HolFiniteMapExact.lookup_update, FUPDATE]
                      have hm_other_glob : ∀ g : String, ofString g ≠ ofString "scratch_ptr" →
                          m.globals.lookup (ofString g) = s.globals.lookup (ofString g) := by
                        intro g hg; rw [hm_glob]
                        simp [HolFiniteMapExact.lookup_update, FUPDATE, hg, Ne.symm hg]
                      have hm_G : GuestInv m := by
                        have hcode_m : m.code = s.code := by
                          dsimp only [m]; rw [hs8_eq, hs7_eq]; dsimp only
                          rw [heff_mc_m11.code, hs5_code, hcode]
                        have hma_m : m.memaddrs = s.memaddrs := by
                          dsimp only [m]; rw [hs8_eq, hs7_eq]; dsimp only
                          rw [heff_mc_m11.memaddrs, hs5_ma, hInv.1.1.memaddrs]
                        have hsh_m : m.shMemaddrs = s.shMemaddrs := by
                          dsimp only [m]; rw [hs8_eq, hs7_eq]; dsimp only
                          rw [heff_mc_m11.shMemaddrs]
                          change saPost.shMemaddrs = s.shMemaddrs
                          rw [hsaPost_eq]; dsimp only [callEntryStateHOLFinite]; rw [hs4_eq]
                        have hba_m : m.baseAddr = s.baseAddr := by
                          dsimp only [m]; rw [hs8_eq, hs7_eq]; dsimp only
                          rw [heff_mc_m11.baseAddr]
                          change saPost.baseAddr = s.baseAddr
                          rw [hsaPost_eq]; dsimp only [callEntryStateHOLFinite]; rw [hs4_eq]
                        exact guestInv_congr hcode_m hma_m hsh_m hba_m hInv.1.1
                      have hsc_m : globN m "scratch_ptr" ≤ globN s "scratch_ptr" := by
                        rw [hm_sp_glob]; omega
                      have hAm : ArenaReady m := by
                        refine ⟨hm_G, ?_⟩
                        unfold ArenaOK
                        have hhp_m : globN m "heap_ptr" = globN s "heap_ptr" :=
                          R16Shards.OpHandlers.globN_eq_of_lookup_eq (hm_other_glob "heap_ptr" (by decide))
                        have hfp_m : globN m "frame_mem_ptr" = globN s "frame_mem_ptr" :=
                          R16Shards.OpHandlers.globN_eq_of_lookup_eq (hm_other_glob "frame_mem_ptr" (by decide))
                        rw [hhp_m, hfp_m, hm_sp_glob]
                        have hA := hInv.1.2
                        exact ⟨hA.1, hA.2.1, hA.2.2.1, hnsw_ge_fp,
                          le_trans (by omega : nsw.toNat ≤ globN s "scratch_ptr") hA.2.2.2.2.1,
                          hA.2.2.2.2.2.1, hA.2.2.2.2.2.2.1, hnsw_al,
                          globalsWord_update (ofString "scratch_ptr") nsw hm_glob hA.2.2.2.2.2.2.2.2⟩
                      have heff_s_s5 : ScratchByteEff s s5 [freshIvl, (globN s "ev", 280), (memW s (globN s "ev" + 8), 32 * memW s (globN s "ev" + 232))] :=
                        ⟨hs5_code.trans hcode.symm,
                         hs5_ma.trans hInv.1.1.memaddrs.symm,
                         by change saPost.shMemaddrs = _; rw [hsaPost_eq]; dsimp only [callEntryStateHOLFinite]; rw [hs4_eq],
                         by change saPost.baseAddr = _; rw [hsaPost_eq]; dsimp only [callEntryStateHOLFinite]; rw [hs4_eq],
                         by change saPost.be = _; rw [hsaPost_eq]; dsimp only [callEntryStateHOLFinite]; rw [hs4_eq],
                         fun g hg => by
                           change saPost.globals.lookup (ofString g) = _; rw [hsaPost_eq]
                           dsimp only [callEntryStateHOLFinite]; rw [hs4_eq]
                           simp [HolFiniteMapExact.lookup_update, FUPDATE, hg, Ne.symm hg],
                         fun a _ => by rw [hs5_mem],
                         fun a _ => by rw [hs5_mem],
                         fun b _ _ => by
                           unfold memB; rw [hs5_mem]
                           have hbe5 : s5.be = s.be := by
                             change saPost.be = _; rw [hsaPost_eq]; dsimp only [callEntryStateHOLFinite]; rw [hs4_eq]
                           rw [hbe5]⟩
                      have heff_m : ScratchByteEff s m
                          [freshIvl, (globN s "ev", 280), (memW s (globN s "ev" + 8), 32 * memW s (globN s "ev" + 232))] := by
                        have h1 := heff_mc.mono (R2 := [freshIvl, (globN s "ev", 280), (memW s (globN s "ev" + 8), 32 * memW s (globN s "ev" + 232))])
                          (fun x hx => by simp at hx; subst hx; exact ⟨freshIvl, by simp, le_refl _, le_refl _⟩)
                        have h2 := (ScratchByteEff.of_bre heff_st8).mono
                          (R2 := [freshIvl, (globN s "ev", 280), (memW s (globN s "ev" + 8), 32 * memW s (globN s "ev" + 232))])
                          (fun x hx => by simp at hx; subst hx; exact ⟨(globN s "ev", 280), by simp, le_refl _, le_refl _⟩)
                        have h3 := (ScratchByteEff.of_bre heff_st232).mono
                          (R2 := [freshIvl, (globN s "ev", 280), (memW s (globN s "ev" + 8), 32 * memW s (globN s "ev" + 232))])
                          (fun x hx => by simp at hx; subst hx; exact ⟨(globN s "ev", 280), by simp, le_refl _, le_refl _⟩)
                        exact (((heff_s_s5.trans h1).trans h2).trans h3).with_locals_clock m.locals s8.clock
                      have hs6_e0_eq : ∀ off, off + 8 ≤ 280 → off % 8 = 0 →
                          memW s6 (globN s "ev" + off) = memW s (globN s "ev" + off) := by
                        intro off hoff hoff8
                        unfold memW
                        rw [heff_mc_m11.cell_frame (BitVec.ofNat 64 (globN s "ev" + off)), hs5_mem]
                        intro x hx; simp at hx; subst hx
                        have htn : (BitVec.ofNat 64 (globN s "ev" + off)).toNat = globN s "ev" + off :=
                          Nat.mod_eq_of_lt (by omega)
                        rw [htn]
                        have he0_8 : (globN s "ev") % 8 = 0 := (hFW0.1 (globN s "ev", 280) (by simp)).2.1
                        have ha8 : (globN s "ev" + off) % 8 = 0 := by omega
                        obtain ⟨he0_scr, _⟩ := (hFW0.1 (globN s "ev", 280) (by simp)).1
                        exact not_cellHits_of_disj_aligned (i := (globN s "ev", 280)) ha8 hnsw_al
                          (Nat.le_add_right _ off) (Nat.add_le_add_left hoff _)
                          (Or.inr (Or.inr (Or.inr (by dsimp only [freshIvl] at he0_scr ⊢; omega))))
                      have hm_e0_other : ∀ off, off + 8 ≤ 280 → off % 8 = 0 → off ≠ 8 → off ≠ 232 →
                          memW m (globN s "ev" + off) = memW s (globN s "ev" + off) := by
                        intro off hoff hoff8 hne8 hne232
                        change memW s8 (globN s "ev" + off) = memW s (globN s "ev" + off)
                        rw [hs8_eq, R14Shards.OpHandlersA.memW_updW_ne s7 (globN s "ev" + 232) (globN s "ev" + off) _ (by omega) (by omega) (by omega),
                            hs7_eq, R14Shards.OpHandlersA.memW_updW_ne s6 (globN s "ev" + 8) (globN s "ev" + off) _ (by omega) (by omega) (by omega),
                            hs6_e0_eq off hoff hoff8]
                      have hm_e0_8 : memW m (globN s "ev" + 8) = nsw.toNat := by
                        change memW s8 (globN s "ev" + 8) = nsw.toNat
                        rw [hs8_eq, R14Shards.OpHandlersA.memW_updW_ne s7 (globN s "ev" + 232) (globN s "ev" + 8) _ (by omega) (by omega) (by omega),
                            hs7_eq, R14Shards.OpHandlersA.memW_updW_same s6 (globN s "ev" + 8) nsw]
                      have hm_e0_232 : memW m (globN s "ev" + 232) = ncapw.toNat := by
                        change memW s8 (globN s "ev" + 232) = ncapw.toNat
                        rw [hs8_eq, R14Shards.OpHandlersA.memW_updW_same s7 (globN s "ev" + 232) ncapw]
                      have hfresh_m : freshIvl = (0, 0) ∨
                          (freshIvl.1 % 8 = 0 ∧ freshIvl.2 % 8 = 0 ∧
                            Inside freshIvl (globN m "scratch_ptr") (globN s "scratch_ptr")) := by
                        right; refine ⟨hnsw_al, by dsimp only [freshIvl]; omega, ?_⟩
                        rw [hm_sp_glob]; exact ⟨le_refl _, le_of_eq hnsw_end⟩
                      have hnew_m :
                          (freshIvl.2 = 0 ∧ memW m (globN s "ev" + 8) = memW s (globN s "ev" + 8) ∧
                            memW m (globN s "ev" + 232) = memW s (globN s "ev" + 232)) ∨
                          (freshIvl.2 ≠ 0 ∧ (memW m (globN s "ev" + 8), 32 * memW m (globN s "ev" + 232)) = freshIvl) := by
                        right; refine ⟨by dsimp only [freshIvl]; omega, ?_⟩
                        rw [hm_e0_8, hm_e0_232]
                      have hm_loc_s4 : ∀ k, k ≠ ofString "ns" → k ≠ ofString "ncap" →
                          m.locals.lookup k = s4.locals.lookup k := by
                        intro k hk1 hk2
                        have hres_ne : ∀ (mp : HolFiniteMapExact MlS (ValueHOL 64)) (key q : MlS) (old : Option (ValueHOL 64)),
                            key ≠ q → (mp.resVarEq (key, old)).lookup q = mp.lookup q := by
                          intro mp key q old hne
                          unfold HolFiniteMapExact.resVarEq
                          cases old with
                          | none => simp [HolFiniteMapExact.eraseEq, FDOMSUB_HOL, hne.symm]
                          | some v => simp [HolFiniteMapExact.updateEq, FUPDATE_HOL, hne.symm]
                        have hs8_l : s8.locals = s5.locals := by
                          rw [hs8_eq, hs7_eq]; exact hs6_loc
                        dsimp only [m]
                        rw [hres_ne _ _ _ _ hk2.symm,
                            hres_ne _ _ _ _ hk1.symm,
                            hs8_l]
                        simp [hs5, setVarHOLFinite, HolFiniteMapExact.lookup_update, FUPDATE, hk1, Ne.symm hk1]
                      exact run_tail m freshIvl hAm hsc_m hm_other_glob heff_m hfresh_m
                        (fun off hoff hoff8 h8 _ h232 => hm_e0_other off hoff hoff8 h8 h232)
                        hnew_m
                        (by rw [hm_e0_232]; omega)
                        (by rw [hm_e0_232]; exact hncap_le1024)
                        (by rw [hm_e0_other 16 (by omega) (by omega) (by omega) (by omega), ← hspw_eq])
                        (by rw [hm_loc_s4 (ofString "sp") (by decide) (by decide)]; exact hs4_sp)
                        (by rw [hm_loc_s4 (ofString "v") (by decide) (by decide)]; exact hs4_v)
      · have hsp_lt_cap : spw.toNat < capw.toNat := by
          rw [BitVec.le_def] at hgrow; omega
        simp only [hgrow, ↓reduceIte, evaluateHOLFiniteState_skip] at hnt ⊢
        exact run_tail s2 (0, 0)
          ⟨guestInv_congr (s := s) rfl rfl rfl rfl hInv.1.1, hInv.1.2⟩
          (le_refl _)
          (fun _ _ => rfl)
          ((ScratchByteEff.refl s _).with_locals_clock s2.locals s.clock)
          (Or.inl rfl)
          (fun _ _ _ _ _ _ => rfl)
          (Or.inl ⟨rfl, rfl, rfl⟩)
          (by change spw.toNat < memW s (globN s "ev" + 232); rw [← hcapw_eq]; exact hsp_lt_cap)
          (by change memW s (globN s "ev" + 232) ≤ 1024; rw [← hcapw_eq]; exact hcap_le1024)
          (by change memW s (globN s "ev" + 16) = spw.toNat; exact hspw_eq.symm)
          hs2_sp hs2_v


/-- `C00.evmR` and `OpDispatchSpec.evmR` have identical bodies; this lets G09-flavored
callee facts feed `HandlerRunA32`'s plain-flavored `evmR` goals. -/
theorem evmR_opdispatch_eq {F : Type} (s : PanSemStateFiniteExact 64 F) :
    evmR s = R11Shards.OpDispatchSpec.evmR s := rfl


/-- `seq (call fname args) (return 0)` at `EvmInvR32` strength, for callees proved at
`EvmPreservingSpecA32`: port of the (private) `Group10CallsCreates.epsA_seq_call_ret0`. -/
theorem epsA32_seq_call_ret0 {fname : MlS}
    (hf : EvmPreservingSpecA32 (fun _ => True)
      (fun s _ post => ∀ g : String, ofString g ≠ ofString "scratch_ptr" → globN post g = globN s g) fname)
    {F : Type} (s : PanSemStateFiniteExact 64 F) (args : List (ExpHOL 64))
    (hcode : s.code = originalRuntimeCode) (hInv : EvmInvR32 s)
    (hWF : HeadMemBridge.HeadMemChainWF s)
    (hnt : (evaluateHOLFiniteState s (.seq (.call (some (none, none)) fname args) (.return (.const 0#64)))).1 ≠ some .timeOut) :
    let r := (evaluateHOLFiniteState s (.seq (.call (some (none, none)) fname args) (.return (.const 0#64)))).1
    let post := (evaluateHOLFiniteState s (.seq (.call (some (none, none)) fname args) (.return (.const 0#64)))).2
    (∀ v, r = some (.returned v) →
      ((EvmInvR32 post ∧ HeadMemBridge.HeadMemChainWF post) ∧ evmChain post = evmChain s ∧ evmR post ≤ evmR s ∧
      (∀ g : String, ofString g ≠ ofString "scratch_ptr" → globN post g = globN s g))) ∧
    (IsEvmErr r →
      ((EvmInvR32 post ∧ HeadMemBridge.HeadMemChainWF post) ∧ evmChain post = evmChain s ∧ evmR post ≤ evmR s)) := by
  dsimp only
  have herr_triv : ∀ {P1 P2 : Prop},
      (∀ v, (some PanSemResultExact.error : Option (PanSemResultExact 64)) = some (.returned v) → P1) ∧
      (IsEvmErr (some PanSemResultExact.error) → P2) := by
    intro _ _; constructor
    · intro _ h; cases h
    · rintro ⟨_, h⟩; cases h
  obtain ⟨params, body, retShape, hlk, hspec⟩ := hf
  rw [evaluateHOLFiniteState_seq_line780, evaluateHOLFiniteState_call] at hnt ⊢
  rcases hargs : evalListHOLFinite s (h := fun a => Classical.propDecidable (s.memaddrs a)) args with _ | vals
  · exact herr_triv
  · simp only [hargs] at hnt ⊢
    rcases hl : lookupCodeHOLFinite s.code.lookup fname vals with _ | ⟨body', callee, ret'⟩
    · exact herr_triv
    · simp only [hl] at hnt ⊢
      by_cases hz : s.clock = 0
      · simp [hz] at hnt
      · simp only [hz, ↓reduceIte] at hnt ⊢
        have hbody_eq : body' = body :=
          lookupCodeHOLFinite_installed_body s.code.lookup fname params body body' retShape ret' vals callee
            (by rw [hcode]; exact hlk) hl
        subst body'
        have hret_eq : ret' = retShape := by
          have hx := PanSemStateFiniteExact.lookupCodeHOLFinite_eq_some s.code.lookup fname vals body callee ret' hl
          rw [hcode] at hx; simp only [Flapjack.lookupCodeHOLExact, hlk] at hx
          split at hx
          · exact (congrArg (fun x => x.2.2) (Option.some.inj hx)).symm
          · cases hx
        subst ret'
        have hl_orig : lookupCodeHOLFinite originalRuntimeCode.lookup fname vals = some (body, callee, retShape) := by
          rwa [← hcode]
        have hInv_ce : EvmInvR32 (callEntryStateHOLFinite s callee) :=
          localsFree_evmInvR32 s callee (s.clock - 1) hInv
        have hWF_ce : HeadMemBridge.HeadMemChainWF (callEntryStateHOLFinite s callee) :=
          HeadMemBridge.headMemChainWF_locals s callee (s.clock - 1) hWF
        have hc_ce := evm_congr (s := s) (t := callEntryStateHOLFinite s callee) rfl rfl
        have hs_spec := hspec (callEntryStateHOLFinite s callee) hcode hInv_ce hWF_ce trivial ⟨vals, hl_orig⟩
        dsimp only at hs_spec
        rcases hrun : evaluateHOLFiniteState (callEntryStateHOLFinite s callee) body with ⟨res, cpost⟩
        simp only [hrun] at hnt hs_spec ⊢
        cases res with
        | none => exact herr_triv
        | some r0 =>
          cases r0 with
          | timeOut => simp at hnt
          | returned vr =>
            by_cases hsh : shapeEqHOL (shapeOfHOLExact vr) retShape = true
            · simp only [hsh, ↓reduceIte]
              obtain ⟨⟨hInv_cp, hWF_cp⟩, hch_cp, hR_cp, hg_cp⟩ := (hs_spec (by simp)).1 vr rfl
              rw [evaluateHOLFiniteState_return]; dsimp only [evalHOLExact]
              have hsz0 : sizeOfShapeWithContextHOL cpost.structs
                  (shapeOfHOLExact (.val (.word 0#64))) ≤ 32 := by
                simp [shapeOfHOLExact, sizeOfShapeWithContextHOL]
              rw [if_pos hsz0]; dsimp only
              let post := ({ cpost with locals := s.locals } : PanSemStateFiniteExact 64 F).emptyLocalsHOLFinite
              have hInv_p : EvmInvR32 post := localsFree_evmInvR32 cpost post.locals cpost.clock hInv_cp
              have hWF_p : HeadMemBridge.HeadMemChainWF post :=
                HeadMemBridge.headMemChainWF_locals cpost post.locals cpost.clock hWF_cp
              have hc_p := evm_congr (s := cpost) (t := post) rfl rfl
              have hch_final : evmChain post = evmChain s := by
                have h1 : evmChain post = evmChain cpost := evmChain_congr rfl rfl
                have h2 : evmChain (callEntryStateHOLFinite s callee) = evmChain s := evmChain_congr rfl rfl
                exact h1.trans (hch_cp.trans h2)
              have hR_cp' : evmR cpost ≤ evmR (callEntryStateHOLFinite s callee) := by
                rw [evmR_opdispatch_eq, evmR_opdispatch_eq]; exact hR_cp
              have hR_final : evmR post ≤ evmR s := by
                rw [hc_p.2.1]; rw [hc_ce.2.1] at hR_cp'; exact hR_cp'
              have hg_final : ∀ g : String, ofString g ≠ ofString "scratch_ptr" → globN post g = globN s g :=
                fun g hg => hg_cp g hg
              constructor
              · intro _ _; exact ⟨⟨hInv_p, hWF_p⟩, hch_final, hR_final, hg_final⟩
              · rintro ⟨_, h⟩; cases h
            · simp only [hsh, Bool.false_eq_true, ↓reduceIte]
              exact herr_triv
          | exception eid ev =>
            dsimp only
            by_cases heid : eid = ofString "EvmErr"
            · subst heid
              obtain ⟨⟨hInv_cp, hWF_cp⟩, hch_cp, hR_cp⟩ := (hs_spec (by simp)).2 ⟨ev, rfl⟩
              have hInv_el : EvmInvR32 cpost.emptyLocalsHOLFinite :=
                localsFree_evmInvR32 cpost _ cpost.clock hInv_cp
              have hWF_el : HeadMemBridge.HeadMemChainWF cpost.emptyLocalsHOLFinite :=
                HeadMemBridge.headMemChainWF_locals cpost _ cpost.clock hWF_cp
              have hc_el := evm_congr (s := cpost) (t := cpost.emptyLocalsHOLFinite) rfl rfl
              have hch_final : evmChain cpost.emptyLocalsHOLFinite = evmChain s := by
                have h1 : evmChain cpost.emptyLocalsHOLFinite = evmChain cpost := evmChain_congr rfl rfl
                have h2 : evmChain (callEntryStateHOLFinite s callee) = evmChain s := evmChain_congr rfl rfl
                exact h1.trans (hch_cp.trans h2)
              have hR_cp' : evmR cpost ≤ evmR (callEntryStateHOLFinite s callee) := by
                rw [evmR_opdispatch_eq, evmR_opdispatch_eq]; exact hR_cp
              have hR_final : evmR cpost.emptyLocalsHOLFinite ≤ evmR s := by
                rw [hc_el.2.1]; rw [hc_ce.2.1] at hR_cp'; exact hR_cp'
              constructor
              · intro _ h; cases h
              · intro _; exact ⟨⟨hInv_el, hWF_el⟩, hch_final, hR_final⟩
            · constructor
              · intro _ h; cases h
              · rintro ⟨_, h⟩; injection h with h'; injection h' with h1 _; exact (heid h1).elim
          | «break» => exact herr_triv
          | «continue» => exact herr_triv
          | finalFfi _ =>
            constructor
            · intro _ h; cases h
            · rintro ⟨_, h⟩; cases h
          | error => exact herr_triv

theorem epsA32_stack_push_word :
    EvmPreservingSpecA32 (fun _ => True)
      (fun s _ post => ∀ g : String, ofString g ≠ ofString "scratch_ptr" → globN post g = globN s g)
      (ofString "stack_push_word") := by
  refine ⟨_, _, _, lookup_stack_push_word, ?_⟩
  intro F s hcode hInvR32 hWF _ _ hnt
  have hb : sourceFnBody Guest.Software.guestFn_stack_push_word =
      .seq
        (.call (some (none, none)) (ofString "stack_push")
          [.rstruct [.var .local (ofString "w"), .const 0#64, .const 0#64, .const 0#64]])
        (.return (.const 0#64)) := rfl
  dsimp only; rw [hb] at hnt ⊢
  exact epsA32_seq_call_ret0 epsA32_stack_push s _ hcode hInvR32 hWF hnt

theorem epsA32_stack_push_bool :
    EvmPreservingSpecA32 (fun _ => True)
      (fun s _ post => ∀ g : String, ofString g ≠ ofString "scratch_ptr" → globN post g = globN s g)
      (ofString "stack_push_bool") := by
  refine ⟨_, _, _, lookup_stack_push_bool, ?_⟩
  intro F s hcode hInvR32 hWF _ _ hnt
  have hb : sourceFnBody Guest.Software.guestFn_stack_push_bool =
      .seq
        (.ite (.cmp .notEqual (.var .local (ofString "b")) (.const 0#64))
          (.call (some (none, none)) (ofString "stack_push")
            [.rstruct [.const 1#64, .const 0#64, .const 0#64, .const 0#64]])
          (.call (some (none, none)) (ofString "stack_push")
            [.rstruct [.const 0#64, .const 0#64, .const 0#64, .const 0#64]]))
        (.return (.const 0#64)) := rfl
  dsimp only; rw [hb] at hnt ⊢
  rw [evaluateHOLFiniteState_seq_line780, evaluateHOLFiniteState_ite] at hnt ⊢
  revert hnt
  split
  · rename_i cw _
    by_cases hcw0 : cw = 0
    · subst hcw0; simp only [↓reduceIte]
      rw [← evaluateHOLFiniteState_seq_line780]
      intro hnt; exact epsA32_seq_call_ret0 epsA32_stack_push s _ hcode hInvR32 hWF hnt
    · simp only [hcw0, ↓reduceIte]
      rw [← evaluateHOLFiniteState_seq_line780]
      intro hnt; exact epsA32_seq_call_ret0 epsA32_stack_push s _ hcode hInvR32 hWF hnt
  · intro _
    constructor
    · intro _ h; cases h
    · rintro ⟨_, h⟩; cases h


/-! ## 7. Frame-write callees at `EvmPreservingSpecA32` strength -/

/-- A globals- and byte-order-keeping effect whose memory writes are confined to word
slots `ev + k` with `k ∈ offs` (8-aligned, inside the head frame's first 280 bytes) is a
`ByteRegionEffect` on the head-frame record `(ev, 280)`. -/
theorem byteRegionEffect_of_head_slots {F : Type}
    {s post : PanSemStateFiniteExact 64 F}
    (hInv : EvmInv s) (hGp : GuestInv post)
    (hglob : post.globals = s.globals) (hbe : post.be = s.be)
    {offs : List Nat} (hoffs : ∀ k ∈ offs, k % 8 = 0 ∧ k + 8 ≤ 280)
    (hmem_out : ∀ x : BitVec 64, (∀ k ∈ offs, x ≠ BitVec.ofNat 64 (globN s "ev" + k)) →
      post.memory x = s.memory x) :
    ByteRegionEffect s post [(globN s "ev", 280)] := by
  obtain ⟨hAs, S, hW, hch_ne, hch_len, hch_last, hFW_all, hFR_all, hRW, hFO_pw, hFO_disj,
    hAT, hMarks, hRoles, hGas⟩ := hInv
  have hhead_mem : (globN s "ev", globN s "cur_cont") ∈ evmChain s := by
    simp [evmChain, evmChainFrom]
  have hhead_FW := hFW_all _ hhead_mem
  have hins : Inside (globN s "ev", 280) (globN s "scratch_ptr") scratchEnd :=
    (hhead_FW.1 (globN s "ev", 280) (by simp)).1
  have hsc_hi : scratchEnd ≤ 2 ^ 64 := by decide
  have hev_hi : ∀ k ∈ offs, globN s "ev" + k < 2 ^ 64 := by
    intro k hk
    obtain ⟨_, hk8'⟩ := hoffs k hk
    have := hins.2; omega
  have hdom_slot : ∀ k ∈ offs, s.memaddrs (BitVec.ofNat 64 (globN s "ev" + k)) := by
    intro k hk
    obtain ⟨hk8, _⟩ := hoffs k hk
    have hdiv : k / 8 < 280 / 8 := by omega
    obtain ⟨_, hdom, _⟩ := (hhead_FW.1 (globN s "ev", 280) (by simp)).2.2.2 (k / 8) hdiv
    have hk8' : 8 * (k / 8) = k := by omega
    rwa [hk8'] at hdom
  have hak : ∀ k ∈ offs, (BitVec.ofNat 64 (globN s "ev" + k)).toNat = globN s "ev" + k :=
    fun k hk => Nat.mod_eq_of_lt (hev_hi k hk)
  refine ⟨hGp.code.trans hAs.1.code.symm, hGp.memaddrs.trans hAs.1.memaddrs.symm,
    hGp.shMemaddrs.trans hAs.1.shMemaddrs.symm, hGp.baseAddr.trans hAs.1.baseAddr.symm,
    hbe, hglob, ?_, ?_, ?_⟩
  · intro a hna
    refine hmem_out a ?_
    intro k hk heq
    rw [heq] at hna
    exact hna (hdom_slot k hk)
  · intro a ha
    refine hmem_out a ?_
    intro k hk heq
    obtain ⟨_, hk8b⟩ := hoffs k hk
    rw [heq] at ha
    exact ha (globN s "ev", 280) (by simp)
      ⟨by rw [hak k hk]; omega, by rw [hak k hk]; omega⟩
  · intro b hb hno
    unfold memB
    have hal_b : (panByteAlignHOL (BitVec.ofNat 64 b)).toNat = b / 8 * 8 := by
      rw [panByteAlign_toNat64, BitVec.toNat_ofNat, Nat.mod_eq_of_lt hb]
    rw [hmem_out (panByteAlignHOL (BitVec.ofNat 64 b)), hbe]
    intro k hk heq
    have htn := congrArg BitVec.toNat heq
    rw [hal_b, hak k hk] at htn
    obtain ⟨_, hk8'⟩ := hoffs k hk
    exact hno (globN s "ev", 280) (by simp) ⟨by dsimp only; omega, by dsimp only; omega⟩

/-- `stack_pop` at `EvmPreservingSpecA32` strength: the single word write at `ev + 16`
stays inside the head frame record `(ev, 280)`, so the frame-write master preserves the
witness DB. -/
theorem epsA32_stack_pop :
    EvmPreservingSpecA32 (fun _ => True) (fun _ _ _ => True) (ofString "stack_pop") := by
  obtain ⟨params, body, retShape, hlk, hsp⟩ :
      Group09ChainWF.EvmPreservingSpecA (fun _ => True)
        (fun s _ post => post.globals = s.globals) (ofString "stack_pop") :=
    Group09ChainWF.epsA_stack_pop
  obtain ⟨hpb, hbr⟩ := Prod.mk.inj (Option.some.inj
    (hlk.symm.trans R14Shards.OpHandlersA.lookup_stack_pop_pub))
  obtain ⟨hbody, _⟩ := Prod.mk.inj hbr
  subst hbody
  refine ⟨params, sourceFnBody Guest.Software.guestFn_stack_pop, retShape, hlk, ?_⟩
  intro F s hcode hInv hWF _ hlkv hnt
  have hsp' := hsp s hcode hInv.evmInv ((headMemChainWF_g09_iff_bridge s).mpr hWF) trivial hlkv hnt
  dsimp only at hsp' ⊢
  set post := (s.evaluateHOLFiniteState (sourceFnBody Guest.Software.guestFn_stack_pop)).2
    with hpost
  obtain ⟨S, Nd, hIW⟩ := evmInvWith_of_evmInv hInv.evmInv
  have hgl (hr : Resumes (s.evaluateHOLFiniteState (sourceFnBody Guest.Software.guestFn_stack_pop)).1) :
      post.globals = s.globals ∧ post.be = s.be ∧
      ∀ x : BitVec 64, x ≠ BitVec.ofNat 64 (globN s "ev" + 16) →
        post.memory x = s.memory x := by
    have hmeta := evaluateHOLFiniteState_metadata s
      (sourceFnBody Guest.Software.guestFn_stack_pop)
    have hbd := stack_pop_body_evmInvWith hIW hr
    dsimp only at hbd
    exact ⟨hbd.2.2.2.1, hmeta.2.2.1, hbd.2.2.2.2.2.2.2.2⟩
  obtain ⟨hAs, S_at, hW_at, hch_ne, hch_len, hch_last, hFW_all, hFR_all, hRW, hFO_pw,
    hFO_disj, hAT, hMarks, hRoles, hGas⟩ := hInv.evmInv
  have hEvm : EvmInv s :=
    ⟨hAs, S_at, hW_at, hch_ne, hch_len, hch_last, hFW_all, hFR_all, hRW, hFO_pw, hFO_disj,
      hAT, hMarks, hRoles, hGas⟩
  have hhead_mem : (globN s "ev", globN s "cur_cont") ∈ evmChain s := by
    simp [evmChain, evmChainFrom]
  have hev8 : globN s "ev" % 8 = 0 :=
    (hFW_all _ hhead_mem).1 (globN s "ev", 280) (by simp) |>.2.1
  have hfo : (globN s "ev", 280) ∈ frameObjects s (globN s "ev", globN s "cur_cont") := by
    simp [frameObjects]
  have hins : Inside (globN s "ev", 280) (globN s "scratch_ptr") scratchEnd :=
    (hFW_all _ hhead_mem).1 (globN s "ev", 280) (by simp) |>.1
  have hRl8 : ∀ x ∈ ([(globN s "ev", 280)] : List Ivl), x.1 % 8 = 0 := by
    intro x hx
    simp only [List.mem_singleton] at hx
    subst hx
    exact hev8
  have havoid : ∀ x ∈ ([(globN s "ev", 280)] : List Ivl),
      (x ∈ frameObjects s (globN s "ev", globN s "cur_cont") ∧
        Inside x (globN s "scratch_ptr") scratchEnd) ∨
      Inside x (globN post "scratch_ptr") (globN s "scratch_ptr") := by
    intro x hx
    simp only [List.mem_singleton] at hx
    subst hx
    exact Or.inl ⟨hfo, hins⟩
  refine ⟨fun v hv => ?_, fun herr => ?_⟩
  · obtain ⟨⟨hI, hWFg⟩, hch, hR, hg⟩ := hsp'.1 v hv
    obtain ⟨hg', hbe, hmem_out⟩ := hgl (Or.inl ⟨v, hv⟩)
    have heff := byteRegionEffect_of_head_slots hEvm hI.1.1 hg' hbe
      (offs := [16]) (by intro k hk; simp at hk; subst hk; omega)
      (fun x hx => hmem_out x (hx 16 (by simp)))
    have hdb := witnessDbOK_of_frameWrites hEvm hInv.witnessDbOK hI.1 heff hRl8 havoid
    exact ⟨⟨⟨hI, hdb, sysInside_congr_globals hg' hInv.sysInside⟩,
      (headMemChainWF_g09_iff_bridge _).mp hWFg⟩, hch, hR, trivial⟩
  · obtain ⟨vv, hvv⟩ := herr
    obtain ⟨⟨hI, hWFg⟩, hch, hR⟩ := hsp'.2 ⟨vv, hvv⟩
    obtain ⟨hg', hbe, hmem_out⟩ := hgl (Or.inr ⟨_, vv, hvv, by decide⟩)
    have heff := byteRegionEffect_of_head_slots hEvm hI.1.1 hg' hbe
      (offs := [16]) (by intro k hk; simp at hk; subst hk; omega)
      (fun x hx => hmem_out x (hx 16 (by simp)))
    have hdb := witnessDbOK_of_frameWrites hEvm hInv.witnessDbOK hI.1 heff hRl8 havoid
    exact ⟨⟨⟨hI, hdb, sysInside_congr_globals hg' hInv.sysInside⟩,
      (headMemChainWF_g09_iff_bridge _).mp hWFg⟩, hch, hR⟩

/-- `pc_add` at `EvmPreservingSpecA32` strength: the single word write at `ev + 0`
stays inside the head frame record `(ev, 280)`. -/
theorem epsA32_pc_add :
    EvmPreservingSpecA32 (fun _ => True) (fun _ _ _ => True) (ofString "pc_add") := by
  refine ⟨_, _, _, lookup_pc_add, ?_⟩
  intro F s hcode hInv hWF _ hlkv hnt
  have hbody : sourceFnBody Guest.Software.guestFn_pc_add =
      .seq
        (.store (.op .add [.var .global (ofString "ev"), .const 0])
          (.op .add [.load .one (.op .add [.var .global (ofString "ev"), .const 0]), .var .local (ofString "n")]))
        (.return (.const 0)) := rfl
  obtain ⟨hb_ev, evw, hevw, hevw_nat⟩ := ev_word_bounds hInv.evmInv
  dsimp only
  rw [hbody, evaluateHOLFiniteState_seq_line780]
  rcases hst : evaluateHOLFiniteState s
      (.store (.op .add [.var .global (ofString "ev"), .const 0])
        (.op .add [.load .one (.op .add [.var .global (ofString "ev"), .const 0]), .var .local (ofString "n")])) with ⟨r1, s1⟩
  cases r1 with
  | some res1 =>
    have herr := store_some_eq_error' hst
    subst herr
    dsimp only
    constructor
    · intro _ h; cases h
    · rintro ⟨_, h⟩; cases h
  | none =>
    dsimp only
    obtain ⟨w1, _, hs1_eq⟩ := R14Shards.OpHandlersA.store_global_off_word (t := s) (post := s1)
      (gname := "ev") (gbase := globN s "ev") (off := 0) hevw hevw_nat (by omega)
      (fun v hv => by
        simp only [evalHOLExact, wordOpHOL] at hv
        revert hv
        rcases @evalListHOLExact 64 F _ s.toExact (fun a => Classical.propDecidable (s.memaddrs a)) _ with _ | vs
        · simp
        · dsimp only
          split
          · simp only [Option.map]
            rcases wordOp .add (vs.map valueWord) with _ | w
            · simp
            · intro hv; injection hv with hv'; exact ⟨w, hv'.symm⟩
          · simp) hst
    rw [evaluateHOLFiniteState_return]
    dsimp only [evalHOLExact]
    have hsz0 : sizeOfShapeWithContextHOL s1.structs
        (shapeOfHOLExact (.val (.word (0 : BitVec 64)))) ≤ 32 := by
      simp [shapeOfHOLExact, sizeOfShapeWithContextHOL]
    rw [if_pos hsz0]
    dsimp only
    let post := emptyLocalsHOLFinite s1
    have hGp : GuestInv post := guestInv_congr (s := s)
      (by simp [post, emptyLocalsHOLFinite, hs1_eq])
      (by simp [post, emptyLocalsHOLFinite, hs1_eq])
      (by simp [post, emptyLocalsHOLFinite, hs1_eq])
      (by simp [post, emptyLocalsHOLFinite, hs1_eq]) hInv.evmInv.1.1
    have hglob_p : post.globals = s.globals := by simp [post, emptyLocalsHOLFinite, hs1_eq]
    have hbe_p : post.be = s.be := by simp [post, emptyLocalsHOLFinite, hs1_eq]
    have hmem_ne : ∀ x : BitVec 64, x ≠ BitVec.ofNat 64 (globN s "ev" + 0) →
        post.memory x = s.memory x := by
      intro x hx
      change s1.memory x = s.memory x
      rw [hs1_eq]; dsimp only [R14Shards.OpHandlersA.updW]; rw [if_neg hx]
    have hmem_out : ∀ x : BitVec 64,
        (∀ off ∈ nonStructFrameOffs, x ≠ BitVec.ofNat 64 (globN s "ev" + off)) →
        post.memory x = s.memory x :=
      fun x hx => hmem_ne x (hx 0 (by simp [nonStructFrameOffs]))
    obtain ⟨hInv_p, hch_p, hR_p⟩ := evmInv_of_head_nonstruct hInv.evmInv hGp hglob_p hbe_p hmem_out
    have hWF_p : Group09ChainWF.HeadMemChainWF post :=
      headMemChainWF_store_headSafe' hInv.evmInv ((headMemChainWF_g09_iff_bridge s).mpr hWF)
        (x := BitVec.ofNat 64 (globN s "ev" + 0))
        (by
          rw [BitVec.toNat_ofNat, Nat.mod_eq_of_lt (by omega)]
          exact Or.inl ⟨0, rfl, by omega, by omega, by omega, by omega⟩)
        hglob_p hch_p hmem_ne
    obtain ⟨hAs, S_at, hW_at, hch_ne, hch_len, hch_last, hFW_all, hFR_all, hRW, hFO_pw,
      hFO_disj, hAT, hMarks, hRoles, hGas⟩ := hInv.evmInv
    have hEvm : EvmInv s :=
      ⟨hAs, S_at, hW_at, hch_ne, hch_len, hch_last, hFW_all, hFR_all, hRW, hFO_pw, hFO_disj,
        hAT, hMarks, hRoles, hGas⟩
    have hhead_mem : (globN s "ev", globN s "cur_cont") ∈ evmChain s := by
      simp [evmChain, evmChainFrom]
    have hev8 : globN s "ev" % 8 = 0 :=
      (hFW_all _ hhead_mem).1 (globN s "ev", 280) (by simp) |>.2.1
    have hfo : (globN s "ev", 280) ∈ frameObjects s (globN s "ev", globN s "cur_cont") := by
      simp [frameObjects]
    have hins : Inside (globN s "ev", 280) (globN s "scratch_ptr") scratchEnd :=
      (hFW_all _ hhead_mem).1 (globN s "ev", 280) (by simp) |>.1
    have hRl8 : ∀ x ∈ ([(globN s "ev", 280)] : List Ivl), x.1 % 8 = 0 := by
      intro x hx
      simp only [List.mem_singleton] at hx
      subst hx
      exact hev8
    have havoid : ∀ x ∈ ([(globN s "ev", 280)] : List Ivl),
        (x ∈ frameObjects s (globN s "ev", globN s "cur_cont") ∧
          Inside x (globN s "scratch_ptr") scratchEnd) ∨
        Inside x (globN post "scratch_ptr") (globN s "scratch_ptr") := by
      intro x hx
      simp only [List.mem_singleton] at hx
      subst hx
      exact Or.inl ⟨hfo, hins⟩
    have heff := byteRegionEffect_of_head_slots hEvm hGp hglob_p hbe_p
      (offs := [0]) (by intro k hk; simp at hk; subst hk; omega)
      (fun x hx => hmem_ne x (hx 0 (by simp)))
    have hdb := witnessDbOK_of_frameWrites hEvm hInv.witnessDbOK hInv_p.1 heff hRl8 havoid
    exact ⟨fun _ _ => ⟨⟨⟨hInv_p, hdb, sysInside_congr_globals hglob_p hInv.sysInside⟩,
      (headMemChainWF_g09_iff_bridge _).mp hWF_p⟩, hch_p, le_of_eq hR_p, trivial⟩,
      by rintro ⟨_, h⟩; cases h⟩

/-- Word-level memory fact for `charge_gas` (both returned and trapped outcomes): away
from the two head-frame slots `ev + 64` and `ev + 184`, memory is unchanged. Copied
from the internal `hmem_res` step of `charge_gas_body_exactA_g09`. -/
theorem charge_gas_mem_res {F : Type} (s : PanSemStateFiniteExact 64 F) (hInv : EvmInv s)
    (hres : Resumes (evaluateHOLFiniteState s (sourceFnBody Guest.Software.guestFn_charge_gas)).1) :
    ∀ x : BitVec 64,
      x ≠ BitVec.ofNat 64 (globN s "ev" + 64) →
      x ≠ BitVec.ofNat 64 (globN s "ev" + 184) →
      (evaluateHOLFiniteState s (sourceFnBody Guest.Software.guestFn_charge_gas)).2.memory x = s.memory x := by
  have hnot_err : ¬ Resumes (some (.error : PanSemResultExact 64)) := by
    rintro (⟨_, h⟩ | ⟨_, _, h, _⟩) <;> cases h
  have hbody : sourceFnBody Guest.Software.guestFn_charge_gas =
      .dec (ofString "gl") .one (.load .one (.op .add [.var .global (ofString "ev"), .const 64]))
        (.seq
          (.ite (.cmp .lower (.var .local (ofString "gl")) (.var .local (ofString "amount")))
            (.raise (ofString "EvmErr") (.const 4))
            .skip)
          (.seq
            (.store (.op .add [.var .global (ofString "ev"), .const 64])
              (.op .sub [.var .local (ofString "gl"), .var .local (ofString "amount")]))
            (.seq
              (.store (.op .add [.var .global (ofString "ev"), .const 184])
                (.op .add
                  [.load .one (.op .add [.var .global (ofString "ev"), .const 184]),
                   .var .local (ofString "amount")]))
              (.return (.const 0))))) := rfl
  obtain ⟨hb_ev, evw, hevw, hevw_nat⟩ := ev_word_bounds hInv
  revert hres
  rw [hbody, evaluateHOLFiniteState_dec_total]
  dsimp only
  split
  · intro hres; exact absurd hres hnot_err
  · rename_i glv _
    split
    · dsimp only
      set s1 := setVarHOLFinite (ofString "gl") glv s
      rw [evaluateHOLFiniteState_seq_line780, evaluateHOLFiniteState_ite]
      split
      · split
        · simp only [evaluateHOLFiniteState_skip]
          rw [evaluateHOLFiniteState_seq_line780]
          rcases hst1 : evaluateHOLFiniteState s1
              (.store (.op .add [.var .global (ofString "ev"), .const 64])
                (.op .sub [.var .local (ofString "gl"), .var .local (ofString "amount")])) with ⟨r1, s2⟩
          cases r1 with
          | some res1 =>
            have herr1 := store_some_eq_error' hst1; subst herr1; dsimp only
            intro hres; exact absurd hres hnot_err
          | none =>
            dsimp only
            obtain ⟨w1, _, hs2_eq⟩ := R14Shards.OpHandlersA.store_global_off_word (t := s1) (post := s2)
              (gname := "ev") (gbase := globN s "ev") (off := 64) hevw hevw_nat (by omega)
              (fun v hv => by
                simp only [evalHOLExact, wordOpHOL] at hv; revert hv
                rcases @evalListHOLExact 64 F _ s1.toExact (fun a => Classical.propDecidable (s1.memaddrs a)) _ with _ | vs
                · simp
                · dsimp only; split
                  · simp only [Option.map]
                    rcases wordOp .sub (vs.map valueWord) with _ | w
                    · simp
                    · intro hv; injection hv with hv'; exact ⟨w, hv'.symm⟩
                  · simp) hst1
            rw [evaluateHOLFiniteState_seq_line780]
            rcases hst2 : evaluateHOLFiniteState s2
                (.store (.op .add [.var .global (ofString "ev"), .const 184])
                  (.op .add
                    [.load .one (.op .add [.var .global (ofString "ev"), .const 184]),
                     .var .local (ofString "amount")])) with ⟨r2, s3⟩
            cases r2 with
            | some res2 =>
              have herr2 := store_some_eq_error' hst2; subst herr2; dsimp only
              intro hres; exact absurd hres hnot_err
            | none =>
              dsimp only
              obtain ⟨w2, _, hs3_eq⟩ := R14Shards.OpHandlersA.store_global_off_word (t := s2) (post := s3)
                (gname := "ev") (gbase := globN s "ev") (off := 184)
                (by rw [hs2_eq]; exact hevw) hevw_nat (by omega)
                (fun v hv => by
                  simp only [evalHOLExact, wordOpHOL] at hv; revert hv
                  rcases @evalListHOLExact 64 F _ s2.toExact (fun a => Classical.propDecidable (s2.memaddrs a)) _ with _ | vs
                  · simp
                  · dsimp only; split
                    · simp only [Option.map]
                      rcases wordOp .add (vs.map valueWord) with _ | w
                      · simp
                      · intro hv; injection hv with hv'; exact ⟨w, hv'.symm⟩
                    · simp) hst2
              intro _ x hx64 hx184
              rw [evaluateHOLFiniteState_return]
              split
              · dsimp only; rw [hs3_eq]; dsimp only [R14Shards.OpHandlersA.updW]; rw [if_neg hx184, hs2_eq]; dsimp only [R14Shards.OpHandlersA.updW]; rw [if_neg hx64]; rfl
              · split
                · dsimp only [emptyLocalsHOLFinite]; rw [hs3_eq]; dsimp only [R14Shards.OpHandlersA.updW]; rw [if_neg hx184, hs2_eq]; dsimp only [R14Shards.OpHandlersA.updW]; rw [if_neg hx64]; rfl
                · dsimp only; rw [hs3_eq]; dsimp only [R14Shards.OpHandlersA.updW]; rw [if_neg hx184, hs2_eq]; dsimp only [R14Shards.OpHandlersA.updW]; rw [if_neg hx64]; rfl
        · rcases hraise : evaluateHOLFiniteState s1 (.raise (ofString "EvmErr") (.const 4)) with ⟨rr, sr⟩
          have hr_nn : rr ≠ none ∧ sr.memory = s.memory := by
            rw [evaluateHOLFiniteState_raise] at hraise; dsimp only [evalHOLExact] at hraise
            split at hraise
            · split at hraise <;> (injection hraise with h1 h2; subst h1 h2; exact ⟨by simp, rfl⟩)
            · injection hraise with h1 h2; subst h1 h2; exact ⟨by simp, rfl⟩
          cases rr with
          | none => exact absurd rfl hr_nn.1
          | some _ =>
            dsimp only; intro _ x _ _; exact congrFun hr_nn.2 x
      · intro hres; exact absurd hres hnot_err
    · intro hres; exact absurd hres hnot_err

/-- `charge_gas` at `EvmPreservingSpecA32` strength: the two word writes at `ev + 64`
and `ev + 184` stay inside the head frame record `(ev, 280)`. -/
theorem epsA32_charge_gas :
    EvmPreservingSpecA32 (fun _ => True) (fun _ _ _ => True) (ofString "charge_gas") := by
  refine ⟨_, _, _, M21.lookup_charge_gas, ?_⟩
  intro F s hcode hInv hWF _ hlkv hnt
  obtain ⟨vals, hl⟩ := hlkv
  have hlen1 : ∃ v0, vals = [v0] := by
    have hx := PanSemStateFiniteExact.lookupCodeHOLFinite_eq_some
      originalRuntimeCode.lookup (ofString "charge_gas") vals _ _ _ hl
    simp only [Flapjack.lookupCodeHOLExact, M21.lookup_charge_gas] at hx
    rcases vals with _ | ⟨v0, _ | _⟩ <;> simp at hx
    exact ⟨v0, rfl⟩
  obtain ⟨v0, rfl⟩ := hlen1
  obtain ⟨_, _, amtw, rfl, hamt⟩ := one_word_arg_lookup M21.lookup_charge_gas hl
  have hcg := charge_gas_body_exactA_g09 s hInv.evmInv
    ((headMemChainWF_g09_iff_bridge s).mpr hWF) hamt
  dsimp only at hcg ⊢
  obtain ⟨hAs, S_at, hW_at, hch_ne, hch_len, hch_last, hFW_all, hFR_all, hRW, hFO_pw,
    hFO_disj, hAT, hMarks, hRoles, hGas⟩ := hInv.evmInv
  have hEvm : EvmInv s :=
    ⟨hAs, S_at, hW_at, hch_ne, hch_len, hch_last, hFW_all, hFR_all, hRW, hFO_pw, hFO_disj,
      hAT, hMarks, hRoles, hGas⟩
  have hhead_mem : (globN s "ev", globN s "cur_cont") ∈ evmChain s := by
    simp [evmChain, evmChainFrom]
  have hev8 : globN s "ev" % 8 = 0 :=
    (hFW_all _ hhead_mem).1 (globN s "ev", 280) (by simp) |>.2.1
  have hfo : (globN s "ev", 280) ∈ frameObjects s (globN s "ev", globN s "cur_cont") := by
    simp [frameObjects]
  have hins : Inside (globN s "ev", 280) (globN s "scratch_ptr") scratchEnd :=
    (hFW_all _ hhead_mem).1 (globN s "ev", 280) (by simp) |>.1
  have hRl8 : ∀ x ∈ ([(globN s "ev", 280)] : List Ivl), x.1 % 8 = 0 := by
    intro x hx
    simp only [List.mem_singleton] at hx
    subst hx
    exact hev8
  have havoid : ∀ x ∈ ([(globN s "ev", 280)] : List Ivl),
      (x ∈ frameObjects s (globN s "ev", globN s "cur_cont") ∧
        Inside x (globN s "scratch_ptr") scratchEnd) ∨
      Inside x (globN (s.evaluateHOLFiniteState
        (sourceFnBody Guest.Software.guestFn_charge_gas)).2 "scratch_ptr")
        (globN s "scratch_ptr") := by
    intro x hx
    simp only [List.mem_singleton] at hx
    subst hx
    exact Or.inl ⟨hfo, hins⟩
  have hoffs : ∀ k ∈ ([64, 184] : List Nat), k % 8 = 0 ∧ k + 8 ≤ 280 := by
    intro k hk
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hk
    rcases hk with rfl | rfl <;> omega
  have hmeta := evaluateHOLFiniteState_metadata s
    (sourceFnBody Guest.Software.guestFn_charge_gas)
  refine ⟨fun v hv => ?_, fun herr => ?_⟩
  · obtain ⟨⟨hI, hWFg'⟩, hg, hch, hR_eq, hbound, hmemW⟩ := hcg.1 v hv
    have hmem := charge_gas_mem_res s hEvm (Or.inl ⟨v, hv⟩)
    have heff := byteRegionEffect_of_head_slots hEvm hI.1.1 hg hmeta.2.2.1
      (offs := [64, 184]) hoffs
      (fun x hx => hmem x (hx 64 (by simp)) (hx 184 (by simp)))
    have hdb := witnessDbOK_of_frameWrites hEvm hInv.witnessDbOK hI.1 heff hRl8 havoid
    exact ⟨⟨⟨hI, hdb, sysInside_congr_globals hg hInv.sysInside⟩,
      (headMemChainWF_g09_iff_bridge _).mp hWFg'⟩, hch, by omega, trivial⟩
  · obtain ⟨vv, hvv⟩ := herr
    obtain ⟨⟨hI, hWFg'⟩, hg, hch, hR⟩ := hcg.2 ⟨vv, hvv⟩
    have hmem := charge_gas_mem_res s hEvm (Or.inr ⟨_, vv, hvv, by decide⟩)
    have heff := byteRegionEffect_of_head_slots hEvm hI.1.1 hg hmeta.2.2.1
      (offs := [64, 184]) hoffs
      (fun x hx => hmem x (hx 64 (by simp)) (hx 184 (by simp)))
    have hdb := witnessDbOK_of_frameWrites hEvm hInv.witnessDbOK hI.1 heff hRl8 havoid
    exact ⟨⟨⟨hI, hdb, sysInside_congr_globals hg hInv.sysInside⟩,
      (headMemChainWF_g09_iff_bridge _).mp hWFg'⟩, hch, le_of_eq hR⟩

/-- `EvmInvR32`-strength port of `Group09ChainWF.HandlerRunA.seq_charge_gas_exact`:
sequencing a `charge_gas` call (with a positive amount expression) flips the walk to
the strict-`evmR` (charged) regime and hands the continuation the callee's frame-word
facts. -/
theorem HandlerRunA32.seq_charge_gas_exact {F : Type} {s0 : PanSemStateFiniteExact 64 F}
    {P Q : PanSemStateFiniteExact 64 F → Prop} {charged : Bool}
    {amtExp : ExpHOL 64} {cont : ProgHOL 64}
    (hpos : ∀ t (w : BitVec 64),
      @evalHOLExact 64 F _ t.toExact (fun a => Classical.propDecidable (t.memaddrs a)) amtExp =
        some (.val (.word w)) →
      EvmInvR32 t → HeadMemBridge.HeadMemChainWF t → P t → 0 < w.toNat)
    (hstep : ∀ t cpost (amtw : BitVec 64),
      @evalHOLExact 64 F _ t.toExact (fun a => Classical.propDecidable (t.memaddrs a)) amtExp =
        some (.val (.word amtw)) →
      amtw.toNat < 2 ^ 64 - 1 →
      EvmInvR32 t → HeadMemBridge.HeadMemChainWF t → P t →
      EvmInvR32 cpost → HeadMemBridge.HeadMemChainWF cpost →
      cpost.globals = t.globals → evmChain cpost = evmChain t →
      (∀ off : Nat, off ∈ ([24, 32, 40] : List Nat) →
        memW cpost (globN t "ev" + off) = memW t (globN t "ev" + off)) →
      Q { cpost with locals := t.locals })
    (hcont : HandlerRunA32 s0 Q true cont) :
    HandlerRunA32 s0 P charged
      (.seq (.call (some (none, none)) (ofString "charge_gas") [amtExp]) cont) := by
  intro t hc hi hw hlen hR hp hn
  have hR_le : evmR t ≤ evmR s0 := rboundA32_to_le hR
  rw [evaluateHOLFiniteState_seq_line780, evaluateHOLFiniteState_call] at hn ⊢
  rcases hargs : evalListHOLFinite t (h := fun a => Classical.propDecidable (t.memaddrs a)) [amtExp] with _ | values
  · exact opDispatchChainPostR32_error s0 t
  · simp only [hargs] at hn ⊢
    rcases hl : lookupCodeHOLFinite t.code.lookup (ofString "charge_gas") values with _ | ⟨body', callee, ret'⟩
    · exact opDispatchChainPostR32_error s0 t
    · simp only [hl] at hn ⊢
      by_cases hz : t.clock = 0
      · simp [hz] at hn
      · simp only [hz, ↓reduceIte] at hn ⊢
        have hv_list : ∃ v0, @evalHOLExact 64 F _ t.toExact (fun a => Classical.propDecidable (t.memaddrs a)) amtExp = some v0 ∧ values = [v0] := by
          rw [evalListHOLFinite_eq_toExact] at hargs
          simp only [evalListHOLExact] at hargs
          rcases he : @evalHOLExact 64 F _ t.toExact (fun a => Classical.propDecidable (t.memaddrs a)) amtExp with _ | v0
          · simp [he] at hargs
          · simp only [he, Option.some.injEq] at hargs; exact ⟨v0, rfl, hargs.symm⟩
        obtain ⟨v0, hv0_ev, rfl⟩ := hv_list
        have hl_orig : lookupCodeHOLFinite originalRuntimeCode.lookup (ofString "charge_gas") [v0] =
            some (body', callee, ret') := by rwa [← hc]
        obtain ⟨rfl, rfl, amtw, rfl, hamt_cal⟩ := one_word_arg_lookup M21.lookup_charge_gas hl_orig
        have hamt_pos : 0 < amtw.toNat := hpos t amtw hv0_ev hi hw hp
        have hi_ce : EvmInvR32 (callEntryStateHOLFinite t callee) :=
          localsFree_evmInvR32 t callee (t.clock - 1) hi
        have hw_ce : HeadMemBridge.HeadMemChainWF (callEntryStateHOLFinite t callee) :=
          HeadMemBridge.headMemChainWF_locals t callee (t.clock - 1) hw
        have hc_ce := evm_congr (s := t) (t := callEntryStateHOLFinite t callee) rfl rfl
        have hmeta := (PanRunBounded.evaluateHOLFiniteState_metadata
          (callEntryStateHOLFinite t callee) (sourceFnBody Guest.Software.guestFn_charge_gas)).1
        have hmeta_be := (PanRunBounded.evaluateHOLFiniteState_metadata
          (callEntryStateHOLFinite t callee) (sourceFnBody Guest.Software.guestFn_charge_gas)).2.2.1
        have hcg := charge_gas_body_exactA_g09 (callEntryStateHOLFinite t callee) hi_ce.evmInv
          ((headMemChainWF_g09_iff_bridge _).mpr hw_ce) hamt_cal
        rcases hrun : evaluateHOLFiniteState (callEntryStateHOLFinite t callee)
            (sourceFnBody Guest.Software.guestFn_charge_gas) with ⟨res, cpost⟩
        simp only [hrun] at hn hmeta hmeta_be hcg ⊢
        change cpost.code = t.code at hmeta
        obtain ⟨hAs, S_at, hW_at, hch_ne, hch_len, hch_last, hFW_all, hFR_all, hRW, hFO_pw,
          hFO_disj, hAT, hMarks, hRoles, hGas⟩ := hi_ce.evmInv
        have hEvm_ce : EvmInv (callEntryStateHOLFinite t callee) :=
          ⟨hAs, S_at, hW_at, hch_ne, hch_len, hch_last, hFW_all, hFR_all, hRW, hFO_pw,
            hFO_disj, hAT, hMarks, hRoles, hGas⟩
        have hhead_mem : (globN (callEntryStateHOLFinite t callee) "ev",
            globN (callEntryStateHOLFinite t callee) "cur_cont") ∈
            evmChain (callEntryStateHOLFinite t callee) := by
          simp [evmChain, evmChainFrom]
        have hev8 : globN (callEntryStateHOLFinite t callee) "ev" % 8 = 0 :=
          (hFW_all _ hhead_mem).1 (globN (callEntryStateHOLFinite t callee) "ev", 280) (by simp) |>.2.1
        have hfo : (globN (callEntryStateHOLFinite t callee) "ev", 280) ∈
            frameObjects (callEntryStateHOLFinite t callee)
              (globN (callEntryStateHOLFinite t callee) "ev",
               globN (callEntryStateHOLFinite t callee) "cur_cont") := by
          simp [frameObjects]
        have hins : Inside (globN (callEntryStateHOLFinite t callee) "ev", 280)
            (globN (callEntryStateHOLFinite t callee) "scratch_ptr") scratchEnd :=
          (hFW_all _ hhead_mem).1 (globN (callEntryStateHOLFinite t callee) "ev", 280) (by simp) |>.1
        have hRl8 : ∀ x ∈ ([(globN (callEntryStateHOLFinite t callee) "ev", 280)] : List Ivl),
            x.1 % 8 = 0 := by
          intro x hx
          simp only [List.mem_singleton] at hx
          subst hx
          exact hev8
        have havoid : ∀ x ∈ ([(globN (callEntryStateHOLFinite t callee) "ev", 280)] : List Ivl),
            (x ∈ frameObjects (callEntryStateHOLFinite t callee)
                (globN (callEntryStateHOLFinite t callee) "ev",
                 globN (callEntryStateHOLFinite t callee) "cur_cont") ∧
              Inside x (globN (callEntryStateHOLFinite t callee) "scratch_ptr") scratchEnd) ∨
            Inside x (globN cpost "scratch_ptr")
              (globN (callEntryStateHOLFinite t callee) "scratch_ptr") := by
          intro x hx
          simp only [List.mem_singleton] at hx
          subst hx
          exact Or.inl ⟨hfo, hins⟩
        have hoffs : ∀ k ∈ ([64, 184] : List Nat), k % 8 = 0 ∧ k + 8 ≤ 280 := by
          intro k hk
          simp only [List.mem_cons, List.not_mem_nil, or_false] at hk
          rcases hk with rfl | rfl <;> omega
        cases res with
        | none => exact opDispatchChainPostR32_error s0 cpost
        | some r0 =>
          cases r0 with
          | timeOut => simp at hn
          | returned v =>
            by_cases hsh_ok : shapeEqHOL (shapeOfHOLExact v) .one = true
            · simp only [hsh_ok, ↓reduceIte] at hn ⊢
              obtain ⟨⟨hi_cp, hw_cp⟩, hglob_cp, hch_cp, hR_cp, hamt_lt, hmem_cp⟩ := hcg.1 v rfl
              have hmem := charge_gas_mem_res (callEntryStateHOLFinite t callee) hEvm_ce
                (Or.inl ⟨v, by simp [hrun]⟩)
              simp only [hrun] at hmem
              have heff := byteRegionEffect_of_head_slots hEvm_ce hi_cp.1.1 hglob_cp hmeta_be
                (offs := [64, 184]) hoffs
                (fun x hx => hmem x (hx 64 (by simp)) (hx 184 (by simp)))
              have hdb := witnessDbOK_of_frameWrites hEvm_ce hi_ce.witnessDbOK hi_cp.1 heff hRl8 havoid
              have hI32_cp : EvmInvR32 cpost :=
                ⟨hi_cp, hdb, sysInside_congr_globals hglob_cp hi_ce.sysInside⟩
              let resumed : PanSemStateFiniteExact 64 F := { cpost with locals := t.locals }
              have hi_res : EvmInvR32 resumed := localsFree_evmInvR32 cpost t.locals cpost.clock hI32_cp
              have hw_res : HeadMemBridge.HeadMemChainWF resumed :=
                HeadMemBridge.headMemChainWF_locals cpost t.locals cpost.clock
                  ((headMemChainWF_g09_iff_bridge cpost).mp hw_cp)
              have hc_res := evm_congr (s := cpost) (t := resumed) rfl rfl
              have hlen_res : (evmChain resumed).length = (evmChain s0).length := by
                rw [hc_res.2.2.1, hch_cp, hc_ce.2.2.1]; exact hlen
              have hR_cp' : evmR cpost + amtw.toNat =
                  evmR (callEntryStateHOLFinite t callee) := by
                rw [evmR_opdispatch_eq, evmR_opdispatch_eq]; exact hR_cp
              rw [hc_ce.2.1] at hR_cp'
              have hR_lt : evmR resumed < evmR s0 := by
                rw [hc_res.2.1]; omega
              exact hcont resumed (hmeta.trans hc) hi_res hw_res hlen_res (by simp [hR_lt])
                (hstep t cpost amtw hv0_ev hamt_lt hi hw hp hI32_cp
                  ((headMemChainWF_g09_iff_bridge _).mp hw_cp) hglob_cp
                  (hch_cp.trans (evmChain_congr rfl rfl)) hmem_cp)
                (by simpa [resumed] using hn)
            · simp only [hsh_ok, Bool.false_eq_true, ↓reduceIte]
              exact opDispatchChainPostR32_error s0 cpost
          | exception eid ev =>
            by_cases heid : eid = ofString "EvmErr"
            · subst heid
              obtain ⟨⟨hi_cp, hw_cp⟩, hglob_cp, hch_cp, hR_cp⟩ := hcg.2 ⟨ev, rfl⟩
              have hmem := charge_gas_mem_res (callEntryStateHOLFinite t callee) hEvm_ce
                (Or.inr ⟨ofString "EvmErr", ev, by simp [hrun], by decide⟩)
              simp only [hrun] at hmem
              have heff := byteRegionEffect_of_head_slots hEvm_ce hi_cp.1.1 hglob_cp hmeta_be
                (offs := [64, 184]) hoffs
                (fun x hx => hmem x (hx 64 (by simp)) (hx 184 (by simp)))
              have hdb := witnessDbOK_of_frameWrites hEvm_ce hi_ce.witnessDbOK hi_cp.1 heff hRl8 havoid
              have hI32_cp : EvmInvR32 cpost :=
                ⟨hi_cp, hdb, sysInside_congr_globals hglob_cp hi_ce.sysInside⟩
              have hi_el : EvmInvR32 cpost.emptyLocalsHOLFinite :=
                localsFree_evmInvR32 cpost _ cpost.clock hI32_cp
              have hw_el : HeadMemBridge.HeadMemChainWF cpost.emptyLocalsHOLFinite :=
                HeadMemBridge.headMemChainWF_locals cpost _ cpost.clock
                  ((headMemChainWF_g09_iff_bridge cpost).mp hw_cp)
              have hc_el := evm_congr (s := cpost) (t := cpost.emptyLocalsHOLFinite) rfl rfl
              refine ⟨?_, fun _ => ⟨⟨hi_el, hw_el⟩, ?_, ?_⟩⟩
              · rintro ⟨_, h⟩; cases h
              · rw [hc_el.2.2.1, hch_cp, hc_ce.2.2.1]; exact hlen
              · have hRle := rboundA32_to_le hR
                have hR_cp' : evmR cpost = evmR (callEntryStateHOLFinite t callee) := by
                  rw [evmR_opdispatch_eq, evmR_opdispatch_eq]; exact hR_cp
                rw [hc_ce.2.1] at hR_cp'
                rw [hc_el.2.1]; omega
            · refine opDispatchChainPostR32_other (fun _ h => by cases h) ?_
              rintro ⟨_, h⟩; injection h with h'; injection h' with h1 _; exact heid h1
          | «break» => exact opDispatchChainPostR32_error s0 cpost
          | «continue» => exact opDispatchChainPostR32_error s0 cpost
          | finalFfi _ =>
            refine opDispatchChainPostR32_other (fun _ h => by cases h) ?_
            rintro ⟨_, h⟩; cases h
          | error => exact opDispatchChainPostR32_error s0 cpost.emptyLocalsHOLFinite

/-- `OpHandlerChainSpecR32` from a `HandlerRunA32` walk of the handler body:
the `EvmInvR32`-strength analogue of `Group09ChainWF.opHandlerSpecA_of_run`. -/
theorem opHandlerChainSpecR32_of_run (idx : Nat) (hidx : idx < Guest.Software.guestAst.length)
    (d : Flapjack.Decl (BitVec 64)) (hd : Guest.Software.guestAst[idx] = .function (extractFn d))
    (hrun : ∀ {F : Type} (s0 : PanSemStateFiniteExact 64 F),
      EvmInvR32 s0 → HeadMemBridge.HeadMemChainWF s0 → ¬ EvmDone s0 →
      HandlerRunA32 s0 (fun _ => True) false
        (InitECandidate.Solver.FrontendCodecComputation.progToHOLStructural (extractFn d).body)) :
    OpHandlerChainSpecR32 (ofString (extractFn d).name) := by
  refine ⟨_, _, _, lookup_of_guestAst_getElem idx hidx (extractFn d) hd, ?_⟩
  intro F s0 hcode ⟨hInv0, hWF0, hnd0⟩ _ hnt
  exact hrun s0 hInv0 hWF0 hnd0 s0 hcode hInv0 hWF0 rfl (le_refl _) trivial hnt

/-! ## 3.5 Pilot handler: `op_add` at R32 strength -/

theorem epsA32_u256_add :
    EvmPreservingSpecA32 (fun _ => True) (fun s _ post => LocFrame s post)
      (ofString "u256_add") :=
  epsA32_of_readOnly 56 (by rw [guestAst_len]; decide)
    Guest.Software.guestFn_u256_add rfl opRoCallees opRoCallees_good rfl

theorem op_add_chainSpecR32 : OpHandlerChainSpecR32 (ofString "op_add") := by
  refine opHandlerChainSpecR32_of_run 475 (by rw [guestAst_len]; decide) Guest.Software.guestFn_op_add rfl ?_
  intro F s0 _ _ _
  dsimp only [Guest.Software.guestFn_op_add, extractFn,
    InitECandidate.Solver.FrontendCodecComputation.progToHOLStructural,
    InitECandidate.Solver.FrontendCodecComputation.expToHOLStructural,
    InitECandidate.Solver.FrontendCodecComputation.expListToHOLStructural,
    InitECandidate.Solver.FrontendCodecComputation.shapeToHOLStructural,
    Option.map, List.map]
  refine HandlerRunA32.decCall_simple epsA32_stack_pop ?_
  refine HandlerRunA32.decCall_simple epsA32_stack_pop ?_
  refine HandlerRunA32.seq_charge_gas_exact (Q := fun _ => True) ?_ ?_ ?_
  · intro t w hv _ _ _
    simp only [evalHOLExact] at hv
    injection hv with h1
    injection h1 with h2
    injection h2 with h3
    subst h3
    decide
  · intro t cpost amtw _ _ _ _ _ _ _ _ _ _
    trivial
  · refine HandlerRunA32.decCall_simple epsA32_u256_add ?_
    refine HandlerRunA32.seq_call_simple epsA32_stack_push ?_
    exact HandlerRunA32.seq_call_simple epsA32_pc_add (HandlerRunA32.ret _)


/-- `seq`-combinator for `ite cond (raise "EvmErr" errExp) skip cont`: on `cond = 0`
the raise-branch is skipped and `cont` runs; on `cond ≠ 0` the raise-branch raises. -/
theorem HandlerRunA32.seq_ite_raise_skip {F : Type} {s0 : PanSemStateFiniteExact 64 F}
    {P Q : PanSemStateFiniteExact 64 F → Prop} {charged : Bool}
    {cond : ExpHOL 64} {errExp : ExpHOL 64} {cont : ProgHOL 64}
    (hfalse : ∀ t,
      @evalHOLExact 64 F _ t.toExact (fun a => Classical.propDecidable (t.memaddrs a)) cond = some (.val (.word 0)) →
      EvmInvR32 t → P t → Q t)
    (hcont : HandlerRunA32 s0 Q charged cont) :
    HandlerRunA32 s0 P charged (.seq (.ite cond (.raise (ofString "EvmErr") errExp) .skip) cont) := by
  intro t hc hi hwf hlen hR hp hn
  rw [evaluateHOLFiniteState_seq_line780, evaluateHOLFiniteState_ite] at hn ⊢
  revert hn
  split
  · rename_i w he
    by_cases hz : w = 0
    · subst hz; simp only [↓reduceIte, evaluateHOLFiniteState_skip]
      intro hn; exact hcont t hc hi hwf hlen hR (hfalse t he hi hp) hn
    · simp only [hz, ↓reduceIte]
      rcases hraise : evaluateHOLFiniteState t (.raise (ofString "EvmErr") errExp) with ⟨rr, sr⟩
      cases rr with
      | none => exact absurd hraise (fun h => raise_ne_none t _ errExp (by rw [h]))
      | some _ =>
        dsimp only; intro hn
        have hr := (HandlerRunA32.raise_evmErr (P := P) (charged := charged) errExp) t hc hi hwf hlen hR hp
          (by rw [hraise]; exact hn)
        rw [hraise] at hr; exact hr
  · intro _; exact opDispatchChainPostR32_error s0 t

import InitECandidate.Solver.Wave8GuestInv.ContractParts.ChainHandlersR32C1
import InitECandidate.Solver.Wave8GuestInv.ContractParts.ChainHandlersR32C2
import InitECandidate.Solver.Wave8GuestInv.R16Shards.EvmEkFk.WkSetStorageR31

/-! # Wave 8 R32 C3: fresh opcode walks at `EvmInvR32` strength (part 3)

The 25 remaining `RemainingChainHandlersR32` obligations that were not covered by the
`ChainHandlersR31A1/A2/B` port lane: world/account/storage/memory/control-flow opcode
handlers, re-walked on the `HandlerRunA32` framework with `EvmPreservingSpecA32`
callee leaves.  World-mutating callees are lifted through the `WorldKeepsSc`
calculus: `epsA32_of_wkSc` turns a structured world-keeping step into an
`EvmPreservingSpecA32` leaf, preserving `EvmInvR32` (including the witness DB and
the `vm_system_address` placement) and the bridge `HeadMemChainWF`.
-/

set_option Elab.async false
set_option autoImplicit false
set_option maxRecDepth 100000
set_option maxHeartbeats 4000000
set_option linter.unusedSimpArgs false
set_option linter.unusedTactic false
set_option linter.unreachableTactic false
set_option linter.unusedVariables false

namespace InitECandidate.Solver.Wave8GuestInv.ContractParts.ChainHandlersR32C3

open Flapjack Flapjack.Pancake.PanLang Flapjack.PanSemStateFiniteExact
open Flapjack.Basis.Pure.MlString
open InitE
open InitECandidate.Solver.GuestCodeLookup
open InitECandidate.Solver.GuestTrapAndLookup
open InitECandidate.Solver.PanTerminatingBounded
open InitECandidate.Solver.PanRunBounded
open InitECandidate.Solver.Wave8GuestInv
open InitECandidate.Solver.Wave8GuestInv.R11Shards
open InitECandidate.Solver.Wave8GuestInv.R11Shards.OpDispatchSpec
open InitECandidate.Solver.Wave8GuestInv.R14Shards.OpHandlersA
open InitECandidate.Solver.Wave8GuestInv.R16Shards.OpHandlers
open InitECandidate.Solver.Wave8Contracts.M23
open InitECandidate.Solver.Wave8GuestInv.ContractParts.StrongBridges
open InitECandidate.Solver.Wave8GuestInv.ContractParts
open InitECandidate.Solver.Wave8GuestInv.R16Shards.OpHandlersB
open InitECandidate.Solver.Wave8GuestInv.R16Shards.OpHandlersB.Group09ChainWF
open InitECandidate.Solver.Wave8GuestInv.R16Shards.OpHandlersB.Group10
open InitECandidate.Solver.Wave8GuestInv.R16Shards.EvmEkFk
open InitECandidate.Solver.Wave8GuestInv.R16Shards.EvmEkFk.StorageCreateFinish
open InitECandidate.Solver.Wave8GuestInv.ContractParts.ChainHandlersR32C1
open InitECandidate.Solver.Wave8GuestInv.ContractParts.ChainHandlersR32C2

/-! ## 1. Master leaf-lift: `WorldKeepsSc` → `EvmPreservingSpecA32` -/

/-- A structured world-keeping step (`WorldKeepsSc` at `stdKeep`, no extra
obligations) yields an `EvmPreservingSpecA32` callee leaf: `EvmInvR32` is preserved
(the witness DB by `witnessDbOK_of_worldStepSc`, the `vm_system_address` placement by
globals-keeping plus heap growth), the bridge `HeadMemChainWF` by
`headMemChainWF_of_agree` over the preserved chain cells, and the caller-visible
postcondition is `GlobalsKept gw` plus `evmR` equality. -/
theorem epsA32_of_wkSc {B : R16WkAcctWs.BufList} {gw : List String} {fname : MlS}
    {P : ∀ {F : Type}, PanSemStateFiniteExact 64 F → Prop}
    (hB : R16WkAcctWs.ValidBufList B) (hgw : R16WkAcctWs.SafeStepGlobals gw)
    (hwk : R16WkAcctWs.WorldKeepsSc P (R16WkAcctWs.bufRegions B) gw
      EvmBase.stdKeep M13.NoExtra fname)
    (hP : ∀ {F : Type} (s : PanSemStateFiniteExact 64 F), EvmInvR32 s → P s)
    (hnev : ofString "ev" ∉ gw.map ofString)
    (hnfmp : ofString "frame_mem_ptr" ∉ gw.map ofString)
    (hnvsa : ofString "vm_system_address" ∉ gw.map ofString) :
    EvmPreservingSpecA32 (fun _ => True)
      (fun s _ post => GlobalsKept gw s post ∧ OpDispatchSpec.evmR post = OpDispatchSpec.evmR s)
      fname := by
  obtain ⟨ps, body, rt, hlk, hbody⟩ := hwk
  refine ⟨ps, body, rt, hlk, ?_⟩
  intro F s hc hInvR32 hWF _ hval hnt
  obtain ⟨hAs, S, hInvAt⟩ := hInvR32.evmInv
  have key : ∀ hr : Resumes (evaluateHOLFiniteState s body).1,
      let post := (evaluateHOLFiniteState s body).2
      (EvmInvR32 post ∧ HeadMemBridge.HeadMemChainWF post) ∧
        evmChain post = evmChain s ∧ OpDispatchSpec.evmR post ≤ OpDispatchSpec.evmR s ∧
        (GlobalsKept gw s post ∧ OpDispatchSpec.evmR post = OpDispatchSpec.evmR s) := by
    intro hr
    have hstep := hbody s hc (hP s hInvR32) hval hnt hr
    obtain ⟨hevm, hevmR, hcells⟩ :=
      evmStep_and_cells_of_worldStepSc hB hgw hAs ⟨S, hInvAt⟩ hstep
    obtain ⟨hInv_p, hhp, hG, hch⟩ := hevm
    have hdb : StorageCreateFinish.WitnessDbOK (evaluateHOLFiniteState s body).2 :=
      witnessDbOK_of_worldStepSc hB hgw hAs hInvR32.witnessDbOK hstep
    have hev : globN (evaluateHOLFiniteState s body).2 "ev" = globN s "ev" :=
      R16Shards.OpHandlers.globN_eq_of_lookup_eq ((hG (ofString "ev") hnev).symm)
    have hfmp : globN (evaluateHOLFiniteState s body).2 "frame_mem_ptr" =
        globN s "frame_mem_ptr" :=
      R16Shards.OpHandlers.globN_eq_of_lookup_eq ((hG (ofString "frame_mem_ptr") hnfmp).symm)
    have hva : globN (evaluateHOLFiniteState s body).2 "vm_system_address" =
        globN s "vm_system_address" :=
      R16Shards.OpHandlers.globN_eq_of_lookup_eq ((hG (ofString "vm_system_address") hnvsa).symm)
    have hsys : Inside (globN (evaluateHOLFiniteState s body).2 "vm_system_address", 20) sourceBase
        (globN (evaluateHOLFiniteState s body).2 "heap_ptr") :=
      ⟨by rw [hva]; exact hInvR32.sysInside.1,
        by rw [hva]; exact le_trans hInvR32.sysInside.2 hhp⟩
    have hwf : Group09ChainWF.HeadMemChainWF (evaluateHOLFiniteState s body).2 :=
      headMemChainWF_of_agree ((headMemChainWF_g09_iff_bridge s).mpr hWF) hch
        (fun ec hec =>
          let h := hcells ec hec
          ⟨h.1, h.2.1, h.2.2.1, h.2.2.2.2⟩)
        hev hfmp
    exact ⟨⟨⟨hInv_p, hdb, hsys⟩, (headMemChainWF_g09_iff_bridge _).mp hwf⟩,
      hch, le_of_eq hevmR, ⟨hG, hevmR⟩⟩
  dsimp only
  refine ⟨fun v hv => ?_, fun herr => ?_⟩
  · have hk := key (Or.inl ⟨v, hv⟩)
    dsimp only at hk
    exact ⟨hk.1, hk.2.1, hk.2.2.1, hk.2.2.2⟩
  · obtain ⟨ev, hev⟩ := herr
    have hk := key (Or.inr ⟨ofString "EvmErr", ev, hev, by decide⟩)
    dsimp only at hk
    exact ⟨hk.1, hk.2.1, hk.2.2.1⟩

/-! ## 2. World-callee leaves at `EvmPreservingSpecA32` strength -/

theorem epsA32_get_account :
    EvmPreservingSpecA32 (fun _ => True)
      (fun s _ post => GlobalsKept ["heap_ptr", "scratch_ptr"] s post ∧
        OpDispatchSpec.evmR post = OpDispatchSpec.evmR s)
      (ofString "get_account") :=
  epsA32_of_wkSc validBufList_wsAcctBufs safeStepGlobals_hp_sp wkSc_get_account
    (fun _ h => let ⟨hAs, S, hIA⟩ := h.evmInv; ⟨hAs, S, hIA.1⟩)
    (by decide) (by decide) (by decide)

theorem epsA32_ext_code_of :
    EvmPreservingSpecA32 (fun _ => True)
      (fun s _ post => GlobalsKept ["heap_ptr", "scratch_ptr"] s post ∧
        OpDispatchSpec.evmR post = OpDispatchSpec.evmR s)
      (ofString "ext_code_of") :=
  epsA32_of_wkSc validBufList_extCodeBufs safeStepGlobals_hp_sp wkSc_ext_code_of
    (fun _ h => let ⟨hAs, S, hIA⟩ := h.evmInv; ⟨hAs, S, hIA.1⟩)
    (by decide) (by decide) (by decide)

theorem epsA32_get_storage :
    EvmPreservingSpecA32 (fun _ => True)
      (fun s _ post => GlobalsKept ["heap_ptr", "scratch_ptr"] s post ∧
        OpDispatchSpec.evmR post = OpDispatchSpec.evmR s)
      (ofString "get_storage") :=
  epsA32_of_wkSc validBufList_extCodeBufs safeStepGlobals_hp_sp StorageCreateFinish.wkSc_get_storage_strong
    (fun _ h => ⟨let ⟨hAs, S, hIA⟩ := h.evmInv; ⟨hAs, S, hIA.1⟩, h.witnessDbOK⟩)
    (by decide) (by decide) (by decide)

theorem epsA32_get_storage_original :
    EvmPreservingSpecA32 (fun _ => True)
      (fun s _ post => GlobalsKept ["heap_ptr", "scratch_ptr"] s post ∧
        OpDispatchSpec.evmR post = OpDispatchSpec.evmR s)
      (ofString "get_storage_original") :=
  epsA32_of_wkSc validBufList_wsAcctBufs safeStepGlobals_hp_sp
    StorageCreateFinish.wkSc_get_storage_original_strong
    (fun _ h => ⟨let ⟨hAs, S, hIA⟩ := h.evmInv; ⟨hAs, S, hIA.1⟩, h.witnessDbOK⟩)
    (by decide) (by decide) (by decide)

theorem epsA32_set_storage :
    EvmPreservingSpecA32 (fun _ => True)
      (fun s _ post => GlobalsKept ["heap_ptr", "journal_n", "scratch_ptr"] s post ∧
        OpDispatchSpec.evmR post = OpDispatchSpec.evmR s)
      (ofString "set_storage") :=
  epsA32_of_wkSc validBufList_wsAcctBufs safeStepGlobals_hp_jn_sp wkSc_set_storage
    (fun _ h => let ⟨hAs, S, hIA⟩ := h.evmInv; ⟨hAs, S, hIA.1⟩)
    (by decide) (by decide) (by decide)

/-! ## 3. Read-only callee leaves at `EvmPreservingSpecA32` strength -/

theorem epsA32_max :
    EvmPreservingSpecA32 (fun _ => True) (fun s _ post => LocFrame s post) (ofString "max") :=
  epsA32_of_readOnly 32 (by rw [guestAst_len]; decide) Guest.Software.guestFn_max rfl
    opRoCallees opRoCallees_good rfl

theorem epsA32_acct_is_empty_ro :
    EvmPreservingSpecA32 (fun _ => True) (fun s _ post => LocFrame s post)
      (ofString "acct_is_empty") :=
  epsA32_of_readOnly 384 (by rw [guestAst_len]; decide) Guest.Software.guestFn_acct_is_empty rfl
    opRoCallees opRoCallees_good rfl

theorem epsA32_is_warm_address_ro :
    EvmPreservingSpecA32 (fun _ => True) (fun s _ post => LocFrame s post)
      (ofString "is_warm_address") :=
  epsA32_of_readOnly 471 (by rw [guestAst_len]; decide)
    Guest.Software.guestFn_is_warm_address rfl opRoCallees opRoCallees_good rfl

theorem epsA32_is_valid_jumpdest :
    EvmPreservingSpecA32 (fun _ => True) (fun s _ post => LocFrame s post)
      (ofString "is_valid_jumpdest") :=
  epsA32_of_readOnly 464 (by rw [guestAst_len]; decide)
    Guest.Software.guestFn_is_valid_jumpdest rfl opRoCallees opRoCallees_good rfl

theorem epsA32_check_gas :
    EvmPreservingSpecA32 (fun _ => True) (fun s _ post => LocFrame s post)
      (ofString "check_gas") :=
  epsA32_of_readOnly 447 (by rw [guestAst_len]; decide)
    Guest.Software.guestFn_check_gas rfl opRoCallees opRoCallees_good rfl

theorem epsA32_require_not_static :
    EvmPreservingSpecA32 (fun _ => True) (fun s _ post => LocFrame s post)
      (ofString "require_not_static") :=
  epsA32_of_readOnly 470 (by rw [guestAst_len]; decide)
    Guest.Software.guestFn_require_not_static rfl opRoCallees opRoCallees_good (by decide)

/-- `words_of(x)` returns a word bounded by `2 ^ 59`. -/
theorem epsA32_words_of_lt :
    EvmPreservingSpecA32 (fun _ => True)
      (fun s v post => LocFrame s post ∧ ∃ w : BitVec 64, v = .val (.word w) ∧ w.toNat < 2 ^ 59)
      (ofString "words_of") := by
  obtain ⟨params, body, retShape, hlk, hro⟩ :=
    epsA32_of_readOnly 443 (by rw [guestAst_len]; decide) Guest.Software.guestFn_words_of rfl
      opRoCallees opRoCallees_good rfl
  have hlk_eq := lookup_words_of.symm.trans hlk
  injection hlk_eq with hprod
  rcases Prod.mk.inj hprod with ⟨rfl, hprod2⟩
  rcases Prod.mk.inj hprod2 with ⟨hbody_eq, rfl⟩
  subst hbody_eq
  refine ⟨_, _, _, lookup_words_of, ?_⟩
  intro F s hcode hInv hWF _ hlkv hnt
  have hs := hro s hcode hInv hWF trivial hlkv hnt
  dsimp only at hs ⊢
  refine ⟨fun v hv => ?_, hs.2⟩
  obtain ⟨⟨hi2, hw2⟩, hch2, hR2, hlf⟩ := hs.1 v hv
  exact ⟨⟨hi2, hw2⟩, hch2, hR2, hlf, words_of_body_lt s v hv⟩

/-- `add_sat(a, b)` with `0 < a` returns a positive word. -/
theorem epsA32_add_sat_pos :
    EvmPreservingSpecA32
      (fun s => ∃ aw : BitVec 64, s.locals.lookup (ofString "a") = some (.val (.word aw)) ∧ 0 < aw.toNat)
      (fun s v post => LocFrame s post ∧ ∃ rw : BitVec 64, v = .val (.word rw) ∧ 0 < rw.toNat)
      (ofString "add_sat") := by
  obtain ⟨params, body, retShape, hlk, hro⟩ :=
    epsA32_of_readOnly 441 (by rw [guestAst_len]; decide) Guest.Software.guestFn_add_sat rfl
      opRoCallees opRoCallees_good rfl
  have hlk_eq : some ([(ofString "a", ShapeHOL.one), (ofString "b", ShapeHOL.one)],
      sourceFnBody Guest.Software.guestFn_add_sat, ShapeHOL.one) =
      some (params, body, retShape) := lookup_add_sat.symm.trans hlk
  injection hlk_eq with hprod
  rcases Prod.mk.inj hprod with ⟨rfl, hprod2⟩
  rcases Prod.mk.inj hprod2 with ⟨hbody_eq, rfl⟩
  subst hbody_eq
  refine ⟨_, _, _, lookup_add_sat, ?_⟩
  intro F s hcode hInv hWF ⟨aw, haw, hpos⟩ hlkv hnt
  have hs := hro s hcode hInv hWF trivial hlkv hnt
  dsimp only at hs ⊢
  obtain ⟨vals, hl⟩ := hlkv
  obtain ⟨_, _, w1, w2, rfl, hw1, hw2⟩ := two_word_arg_lookup (by decide) lookup_add_sat hl
  rw [haw] at hw1; injection hw1 with hw1'; injection hw1' with hw1''; injection hw1'' with hw_eq; subst hw_eq
  refine ⟨fun v hv => ?_, hs.2⟩
  obtain ⟨⟨hi3, hw3⟩, hch3, hR3, hlf⟩ := hs.1 v hv
  obtain ⟨rw, rfl, hrw_ge⟩ := add_sat_body_ge s haw hw2 v hv
  exact ⟨⟨hi3, hw3⟩, hch3, hR3, hlf, rw, rfl, by omega⟩

/-- `access_gas_cost(addr)` returns either `100` (`G_WARM_ACCESS`) or `3000` (`G_COLD_ACCOUNT_ACCESS`). -/
theorem epsA32_access_gas_cost_bounds :
    EvmPreservingSpecA32 (fun _ => True)
      (fun s v post => LocFrame s post ∧ ∃ cw : BitVec 64, v = .val (.word cw) ∧ (cw.toNat = 100 ∨ cw.toNat = 3000))
      (ofString "access_gas_cost") := by
  obtain ⟨params, body, retShape, hlk, hro⟩ :=
    epsA32_of_readOnly 473 (by rw [guestAst_len]; decide)
      Guest.Software.guestFn_access_gas_cost rfl opRoCallees opRoCallees_good rfl
  have hlk_eq := lookup_access_gas_cost.symm.trans hlk
  injection hlk_eq with hprod
  rcases Prod.mk.inj hprod with ⟨rfl, hprod2⟩
  rcases Prod.mk.inj hprod2 with ⟨hbody_eq, rfl⟩
  subst hbody_eq
  refine ⟨_, _, _, lookup_access_gas_cost, ?_⟩
  intro F s hcode hInv hWF _ hlkv hnt
  have hs := hro s hcode hInv hWF trivial hlkv hnt
  dsimp only at hs ⊢
  refine ⟨fun v hv => ?_, hs.2⟩
  obtain ⟨⟨hi2, hw2⟩, hch2, hR2, hlf⟩ := hs.1 v hv
  exact ⟨⟨hi2, hw2⟩, hch2, hR2, hlf, access_gas_cost_body_bounds s v hv⟩

/-! ## 4. Walk combinators: shaped `decCall`, `stack_pop` specialization, head-slot stores -/

theorem HandlerRunA32.decCall_shaped {F : Type} {s0 : PanSemStateFiniteExact 64 F}
    {P Q : PanSemStateFiniteExact 64 F → Prop}
    {Pc : ∀ {F : Type}, PanSemStateFiniteExact 64 F → Prop}
    {Qc : ∀ {F : Type}, PanSemStateFiniteExact 64 F → ValueHOL 64 → PanSemStateFiniteExact 64 F → Prop}
    {charged : Bool}
    {nm : MlS} {sh : ShapeHOL} {fname : MlS} {args : List (ExpHOL 64)} {cont : ProgHOL 64}
    (hf : EvmPreservingSpecA32 Pc Qc fname)
    (hentry : ∀ t values body' callee ret',
      t.code = originalRuntimeCode → EvmInvR32 t → HeadMemBridge.HeadMemChainWF t → P t →
      evalListHOLFinite t (h := fun a => Classical.propDecidable (t.memaddrs a)) args = some values →
      lookupCodeHOLFinite t.code.lookup fname values = some (body', callee, ret') →
      Pc (callEntryStateHOLFinite t callee))
    (hstep : ∀ t values body callee retShape v cpost,
      EvmInvR32 t → HeadMemBridge.HeadMemChainWF t → P t →
      shapeEqHOL (shapeOfHOLExact v) sh = true →
      evalListHOLFinite t (h := fun a => Classical.propDecidable (t.memaddrs a)) args = some values →
      lookupCodeHOLFinite originalRuntimeCode.lookup fname values = some (body, callee, retShape) →
      EvmInvR32 cpost → HeadMemBridge.HeadMemChainWF cpost →
      evmChain cpost = evmChain (callEntryStateHOLFinite t callee) →
      Qc (callEntryStateHOLFinite t callee) v cpost →
      Q (setVarHOLFinite nm v { cpost with locals := t.locals }))
    (hcont : HandlerRunA32 s0 Q charged cont) :
    HandlerRunA32 s0 P charged (.decCall nm sh fname args cont) := by
  intro t hc hi hw hlen hR hp hn
  obtain ⟨params, body, retShape, hlook, hspec⟩ := hf
  rw [evaluateHOLFiniteState_decCall_fixClockRewrite] at hn ⊢
  rcases hargs : evalListHOLFinite t (h := fun a => Classical.propDecidable (t.memaddrs a)) args with _ | values
  · exact opDispatchChainPostR32_error s0 t
  · simp only [hargs] at hn ⊢
    rcases hl : lookupCodeHOLFinite t.code.lookup fname values with _ | ⟨body', callee, ret'⟩
    · exact opDispatchChainPostR32_error s0 t
    · simp only [hl] at hn ⊢
      by_cases hz : t.clock = 0
      · simp [hz] at hn
      · simp only [hz, ↓reduceIte] at hn ⊢
        have hbody_eq : body' = body :=
          lookupCodeHOLFinite_installed_body t.code.lookup fname params body body'
            retShape ret' values callee (by rw [hc]; exact hlook) hl
        subst body'
        have hret_eq : ret' = retShape := by
          have hx := PanSemStateFiniteExact.lookupCodeHOLFinite_eq_some
            t.code.lookup fname values body callee ret' hl
          rw [hc] at hx; simp only [Flapjack.lookupCodeHOLExact, hlook] at hx
          split at hx
          · exact (congrArg (fun x => x.2.2) (Option.some.inj hx)).symm
          · cases hx
        subst ret'
        have hi_ce : EvmInvR32 (callEntryStateHOLFinite t callee) :=
          localsFree_evmInvR32 t callee (t.clock - 1) hi
        have hw_ce : HeadMemBridge.HeadMemChainWF (callEntryStateHOLFinite t callee) :=
          HeadMemBridge.headMemChainWF_locals t callee (t.clock - 1) hw
        have hPc : Pc (callEntryStateHOLFinite t callee) :=
          hentry t values body callee retShape hc hi hw hp hargs hl
        have hl_orig : lookupCodeHOLFinite originalRuntimeCode.lookup fname values =
            some (body, callee, retShape) := by rwa [← hc]
        have hmeta := (PanRunBounded.evaluateHOLFiniteState_metadata (callEntryStateHOLFinite t callee) body).1
        rcases hrun : evaluateHOLFiniteState (callEntryStateHOLFinite t callee) body with ⟨res, cpost⟩
        simp only [hrun] at hn hmeta ⊢
        change cpost.code = t.code at hmeta
        have hc_ce := evm_congr (s := t) (t := callEntryStateHOLFinite t callee) rfl rfl
        have hQ (hsafe : res ≠ some .timeOut) :
            (∀ v, res = some (.returned v) →
              (EvmInvR32 cpost ∧ HeadMemBridge.HeadMemChainWF cpost) ∧
              evmChain cpost = evmChain (callEntryStateHOLFinite t callee) ∧
              evmR cpost ≤ evmR (callEntryStateHOLFinite t callee) ∧
              Qc (callEntryStateHOLFinite t callee) v cpost) ∧
            (IsEvmErr res →
              (EvmInvR32 cpost ∧ HeadMemBridge.HeadMemChainWF cpost) ∧
              evmChain cpost = evmChain (callEntryStateHOLFinite t callee) ∧
              evmR cpost ≤ evmR (callEntryStateHOLFinite t callee)) := by
          have hs := hspec (callEntryStateHOLFinite t callee) hc hi_ce hw_ce hPc ⟨values, hl_orig⟩
            (by rw [hrun]; exact hsafe)
          dsimp only at hs; rw [hrun] at hs; exact hs
        cases res with
        | none => exact opDispatchChainPostR32_error s0 cpost
        | some r0 =>
          cases r0 with
          | timeOut => simp at hn
          | returned v =>
            dsimp only at hn ⊢
            split
            · rename_i hsh_ok
              rw [if_pos hsh_ok] at hn
              have hsh_v : shapeEqHOL (shapeOfHOLExact v) sh = true := by
                simp only [Bool.and_eq_true] at hsh_ok; exact hsh_ok.1
              obtain ⟨⟨hi_cp, hw_cp⟩, hch_cp, hR_cp, hQc_cp⟩ := (hQ (by simp)).1 v rfl
              let resumed := setVarHOLFinite nm v { cpost with locals := t.locals }
              have hcode_res : resumed.code = originalRuntimeCode := hmeta.trans hc
              have hi_res : EvmInvR32 resumed := localsFree_evmInvR32 cpost resumed.locals cpost.clock hi_cp
              have hw_res : HeadMemBridge.HeadMemChainWF resumed :=
                HeadMemBridge.headMemChainWF_locals cpost resumed.locals cpost.clock hw_cp
              have hc_res := evm_congr (s := cpost) (t := resumed) rfl rfl
              have hlen_res : (evmChain resumed).length = (evmChain s0).length := by
                rw [hc_res.2.2.1, hch_cp, hc_ce.2.2.1]; exact hlen
              have hR_res : if charged then evmR resumed < evmR s0 else evmR resumed ≤ evmR s0 :=
                rboundA32_step (by rw [hc_res.2.1]; rw [hc_ce.2.1] at hR_cp; exact hR_cp) hR
              have hQ_res : Q resumed :=
                hstep t values body callee retShape v cpost hi hw hp hsh_v hargs hl_orig hi_cp hw_cp hch_cp hQc_cp
              have hb := hcont resumed hcode_res hi_res hw_res hlen_res hR_res hQ_res (by simpa [resumed] using hn)
              exact opDispatchChainPostR32_congr_lcl rfl hb
            · exact opDispatchChainPostR32_error s0 cpost
          | exception eid ev =>
            by_cases heid : eid = ofString "EvmErr"
            · subst heid
              obtain ⟨⟨hi_cp, hw_cp⟩, hch_cp, hR_cp⟩ := (hQ (by simp)).2 ⟨ev, rfl⟩
              have hi_el : EvmInvR32 cpost.emptyLocalsHOLFinite :=
                localsFree_evmInvR32 cpost _ cpost.clock hi_cp
              have hw_el : HeadMemBridge.HeadMemChainWF cpost.emptyLocalsHOLFinite :=
                HeadMemBridge.headMemChainWF_locals cpost _ cpost.clock hw_cp
              have hc_el := evm_congr (s := cpost) (t := cpost.emptyLocalsHOLFinite) rfl rfl
              refine ⟨?_, fun _ => ⟨⟨hi_el, hw_el⟩, ?_, ?_⟩⟩
              · rintro ⟨_, h⟩; cases h
              · rw [hc_el.2.2.1, hch_cp, hc_ce.2.2.1]; exact hlen
              · have := rboundA32_to_le hR; rw [hc_el.2.1]; rw [hc_ce.2.1] at hR_cp; omega
            · refine opDispatchChainPostR32_other (fun _ h => by cases h) ?_
              rintro ⟨_, h⟩; injection h with h'; injection h' with h1 _; exact heid h1
          | «break» => exact opDispatchChainPostR32_error s0 cpost
          | «continue» => exact opDispatchChainPostR32_error s0 cpost
          | finalFfi _ =>
            refine opDispatchChainPostR32_other (fun _ h => by cases h) ?_
            rintro ⟨_, h⟩; cases h
          | error => exact opDispatchChainPostR32_error s0 cpost.emptyLocalsHOLFinite


theorem HandlerRunA32.decCall_stack_pop_s4 {F : Type} {s0 : PanSemStateFiniteExact 64 F}
    {P : PanSemStateFiniteExact 64 F → Prop} {charged : Bool}
    {nm : MlS} {cont : ProgHOL 64}
    (hP_loc : ∀ t (cpost : PanSemStateFiniteExact 64 F) (v : ValueHOL 64), P t →
      P (setVarHOLFinite nm v { cpost with locals := t.locals }))
    (hcont : HandlerRunA32 s0 (fun t => P t ∧ IsStruct4Local nm t) charged cont) :
    HandlerRunA32 s0 P charged
      (.decCall nm (.comb [.one, .one, .one, .one]) (ofString "stack_pop") [] cont) := by
  refine HandlerRunA32.decCall_shaped epsA32_stack_pop
    (fun _ _ _ _ _ _ _ _ _ _ _ => trivial) ?_ hcont
  intro t values body callee retShape v cpost _ _ hp hsh _ _ _ _ _ _
  obtain ⟨w0, w1, w2, w3, rfl⟩ := shapeEq_comb4_iff v hsh
  exact ⟨hP_loc t cpost _ hp, w0, w1, w2, w3, by
    simp [setVarHOLFinite, HolFiniteMapExact.lookup_update, FUPDATE]⟩

theorem eval_rField_of_struct4 {F : Type} {t : PanSemStateFiniteExact 64 F} {nm : MlS}
    (hs4 : IsStruct4Local nm t) (idx : Nat) (hidx : idx < 4) :
    ∀ v : ValueHOL 64,
      @evalHOLExact 64 F _ t.toExact (fun a => Classical.propDecidable (t.memaddrs a))
        (.rfield idx (.var .local nm)) = some v →
      ∃ w : BitVec 64, v = .val (.word w) := by
  obtain ⟨w0, w1, w2, w3, hlk⟩ := hs4
  intro v hv
  simp only [evalHOLExact, hlk] at hv
  rcases idx with _ | _ | _ | _ | _
  · simp at hv; exact ⟨w0, hv.symm⟩
  · simp at hv; exact ⟨w1, hv.symm⟩
  · simp at hv; exact ⟨w2, hv.symm⟩
  · simp at hv; exact ⟨w3, hv.symm⟩
  · omega

theorem HandlerRunA32.seq_charge_gas_const {F : Type} {s0 : PanSemStateFiniteExact 64 F}
    {charged : Bool} {k : BitVec 64} (hk : 0 < k.toNat) (hk2 : k.toNat < 2 ^ 64 - 1)
    {cont : ProgHOL 64} (hcont : HandlerRunA32 s0 (fun _ => True) true cont) :
    HandlerRunA32 s0 (fun _ => True) charged
      (.seq (.call (some (none, none)) (ofString "charge_gas") [.const k]) cont) :=
  HandlerRunA32.seq_charge_gas_exact (Q := fun _ => True)
    (fun _ w hw _ _ _ => by
      simp only [evalHOLExact] at hw
      injection hw with h1; injection h1 with h2; injection h2 with h3; subst h3
      simp only [hk, hk2])
    (fun _ _ _ _ _ _ _ _ _ _ _ _ _ => trivial)
    hcont

theorem HandlerRunA32.seq_store_ev_nonstruct {F : Type} {s0 : PanSemStateFiniteExact 64 F}
    {P Q : PanSemStateFiniteExact 64 F → Prop} {charged : Bool}
    (off : Nat) (hoff : off ∈ nonStructFrameOffs) {valExp : ExpHOL 64} {cont : ProgHOL 64}
    (hval : ∀ (t : PanSemStateFiniteExact 64 F) (v : ValueHOL 64),
      P t →
      @evalHOLExact 64 F _ t.toExact (fun a => Classical.propDecidable (t.memaddrs a)) valExp = some v →
      ∃ w : BitVec 64, v = .val (.word w))
    (hstep : ∀ (t : PanSemStateFiniteExact 64 F) (w : BitVec 64),
      @evalHOLExact 64 F _ t.toExact (fun a => Classical.propDecidable (t.memaddrs a)) valExp =
        some (.val (.word w)) →
      EvmInvR32 t → HeadMemBridge.HeadMemChainWF t → P t →
      EvmInvR32 { t with memory := R14Shards.OpHandlersA.updW t.memory (BitVec.ofNat 64 (globN t "ev" + off)) w } →
      HeadMemBridge.HeadMemChainWF { t with memory := R14Shards.OpHandlersA.updW t.memory (BitVec.ofNat 64 (globN t "ev" + off)) w } →
      Q { t with memory := R14Shards.OpHandlersA.updW t.memory (BitVec.ofNat 64 (globN t "ev" + off)) w })
    (hcont : HandlerRunA32 s0 Q charged cont) :
    HandlerRunA32 s0 P charged
      (.seq (.store (.op .add [.var .global (ofString "ev"), .const (BitVec.ofNat 64 off)]) valExp) cont) := by
  intro t hc hi hw hlen hR hp hn
  have hoff_facts : off < 280 ∧ off ≠ 24 ∧ off ≠ 32 ∧ off ≠ 40 ∧ off + 8 ≤ 280 := by
    simp only [nonStructFrameOffs, List.mem_cons, List.not_mem_nil, or_false] at hoff
    rcases hoff with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl <;> omega
  obtain ⟨hb_ev, evw, hevw, hevw_nat⟩ := ev_word_bounds hi.evmInv
  rw [evaluateHOLFiniteState_seq_line780] at hn ⊢
  rcases hst : evaluateHOLFiniteState t
      (.store (.op .add [.var .global (ofString "ev"), .const (BitVec.ofNat 64 off)]) valExp) with ⟨r1, t1⟩
  simp only [hst] at hn ⊢
  cases r1 with
  | some res1 =>
    have herr := store_some_eq_error' hst; subst herr
    exact opDispatchChainPostR32_error s0 t1
  | none =>
    dsimp only at hn ⊢
    obtain ⟨w, hw_ev, ht1_eq⟩ := R14Shards.OpHandlersA.store_global_off_word (t := t) (post := t1)
      (gname := "ev") (gbase := globN t "ev") (off := off) hevw hevw_nat (by omega)
      (fun v hv => hval t v hp hv) hst
    have hGt1 : GuestInv t1 := guestInv_congr (s := t)
      (by simp [ht1_eq]) (by simp [ht1_eq]) (by simp [ht1_eq]) (by simp [ht1_eq]) hi.evmInv.1.1
    have hglob_t1 : t1.globals = t.globals := by simp [ht1_eq]
    have hbe_t1 : t1.be = t.be := by simp [ht1_eq]
    have hmem_ne : ∀ x : BitVec 64, x ≠ BitVec.ofNat 64 (globN t "ev" + off) →
        t1.memory x = t.memory x := by
      intro x hx
      rw [ht1_eq]; dsimp only [R14Shards.OpHandlersA.updW]
      rw [if_neg hx]
    have hmem_out : ∀ x : BitVec 64,
        (∀ off' ∈ nonStructFrameOffs, x ≠ BitVec.ofNat 64 (globN t "ev" + off')) →
        t1.memory x = t.memory x := fun x hx =>
      hmem_ne x (hx off hoff)
    obtain ⟨hInv1, hch1, hR1_eq⟩ := evmInv_of_head_nonstruct hi.evmInv hGt1 hglob_t1 hbe_t1 hmem_out
    have hWF1 : HeadMemBridge.HeadMemChainWF t1 :=
      (headMemChainWF_g09_iff_bridge t1).mp (headMemChainWF_store_headSafe' hi.evmInv
        ((headMemChainWF_g09_iff_bridge t).mpr hw)
        (x := BitVec.ofNat 64 (globN t "ev" + off))
        (by
          rw [BitVec.toNat_ofNat, Nat.mod_eq_of_lt (by omega)]
          exact Or.inl ⟨off, rfl, by omega, by omega, by omega, by omega⟩)
        hglob_t1 hch1 hmem_ne)
    have hdb1 : StorageCreateFinish.WitnessDbOK t1 :=
      witnessDbOK_of_head_slots hi hGt1 hglob_t1 hbe_t1 hmem_out
    have hsys1 : Inside (globN t1 "vm_system_address", 20) sourceBase (globN t1 "heap_ptr") :=
      sysInside_congr_globals hglob_t1 hi.sysInside
    have hI32_1 : EvmInvR32 t1 := ⟨hInv1, hdb1, hsys1⟩
    have hlen1 : (evmChain t1).length = (evmChain s0).length := by rw [hch1]; exact hlen
    have hR1 : if charged then evmR t1 < evmR s0 else evmR t1 ≤ evmR s0 := by
      have hR_le := rboundA32_to_le hR
      have heq : evmR t1 = evmR t := by
        rw [evmR_opdispatch_eq, evmR_opdispatch_eq]; exact hR1_eq
      rw [heq]; exact hR
    have hQ1 : Q t1 := by
      rw [ht1_eq] at hI32_1 hWF1 ⊢
      exact hstep t w hw_ev hi hw hp hI32_1 hWF1
    exact hcont t1 (by rw [ht1_eq]; exact hc) hI32_1 hWF1 hlen1 hR1 hQ1 hn


/-! ## 5. First walks: `op_jump` -/

theorem op_jump_chainSpecR32 : OpHandlerChainSpecR32 (ofString "op_jump") := by
  refine opHandlerChainSpecR32_of_run 503 (by rw [guestAst_len]; decide)
    Guest.Software.guestFn_op_jump rfl ?_
  intro F s0 _ _ _
  dsimp only [Guest.Software.guestFn_op_jump, extractFn,
    InitECandidate.Solver.FrontendCodecComputation.progToHOLStructural,
    InitECandidate.Solver.FrontendCodecComputation.expToHOLStructural,
    InitECandidate.Solver.FrontendCodecComputation.expListToHOLStructural,
    InitECandidate.Solver.FrontendCodecComputation.shapeToHOLStructural]
  refine HandlerRunA32.decCall_stack_pop_s4 (fun _ _ _ _ => trivial) ?_
  refine HandlerRunA32.seq_charge_gas_exact (Q := fun t => IsStruct4Local (ofString "dest") t)
    (fun _ w hw _ _ _ => by
      change some (ValueHOL.val (.word 8#64)) = some (.val (.word w)) at hw
      injection hw with h1; injection h1 with h2; injection h2 with h3; subst h3; decide)
    (fun _ _ _ _ _ _ _ ⟨_, hs4⟩ _ _ _ _ _ => hs4) ?_
  have hstep_ivj : ∀ (t : PanSemStateFiniteExact 64 F) (values : List (ValueHOL 64))
      (body : ProgHOL 64) (callee : HolFiniteMapExact MlS (ValueHOL 64)) (retShape : ShapeHOL)
      (v : ValueHOL 64) (cpost : PanSemStateFiniteExact 64 F),
      EvmInvR32 t → HeadMemBridge.HeadMemChainWF t → IsStruct4Local (ofString "dest") t →
      t.evalListHOLFinite (h := fun a => Classical.propDecidable (t.memaddrs a))
        (List.map FrontendCodecComputation.expToHOLStructural [Exp.var VarKind.local "dest"]) =
        some values →
      PanSemStateFiniteExact.lookupCodeHOLFinite originalRuntimeCode.lookup
        (ofString "is_valid_jumpdest") values = some (body, callee, retShape) →
      EvmInvR32 cpost → HeadMemBridge.HeadMemChainWF cpost →
      evmChain cpost = evmChain (PanSemStateFiniteExact.callEntryStateHOLFinite t callee) →
      LocFrame (PanSemStateFiniteExact.callEntryStateHOLFinite t callee) cpost →
      IsStruct4Local (ofString "dest")
        (setVarHOLFinite (ofString "ok") v { cpost with locals := t.locals }) := by
    intro t _ _ _ _ _ cpost _ _ hs4 _ _ _ _ _ _
    obtain ⟨w0, w1, w2, w3, hlk⟩ := hs4
    refine ⟨w0, w1, w2, w3, ?_⟩
    have hne : ofString "ok" ≠ ofString "dest" := by decide
    simpa [setVarHOLFinite, HolFiniteMapExact.lookup_update, FUPDATE, hne] using hlk
  refine HandlerRunA32.decCall (Q := fun t => IsStruct4Local (ofString "dest") t)
    epsA32_is_valid_jumpdest
    (fun _ _ _ _ _ _ _ _ _ _ _ => trivial) hstep_ivj ?_
  refine HandlerRunA32.seq_ite_raise_skip (fun _ _ _ hp => hp) ?_
  exact HandlerRunA32.seq_store_ev_nonstruct (Q := fun _ => True)
    0 (by simp [nonStructFrameOffs])
    (fun _ v hs4 hv => eval_rField_of_struct4 hs4 0 (by omega) v hv)
    (fun _ _ _ _ _ _ _ _ => trivial)
    (HandlerRunA32.ret _)


/-! ### Generic `IsStruct4Local "dest"`-transfer hstep for `decCall` positions -/

theorem decCall_hstep_isStruct4Local_transfer {F : Type}
    {nm' : MlS} (hne : nm' ≠ ofString "dest") {args : List (ExpHOL 64)} {fname : MlS}
    {Qc : ∀ {F : Type}, PanSemStateFiniteExact 64 F → ValueHOL 64 → PanSemStateFiniteExact 64 F → Prop} :
    ∀ (t : PanSemStateFiniteExact 64 F) (values : List (ValueHOL 64))
      (body : ProgHOL 64) (callee : HolFiniteMapExact MlS (ValueHOL 64)) (retShape : ShapeHOL)
      (v : ValueHOL 64) (cpost : PanSemStateFiniteExact 64 F),
    EvmInvR32 t → HeadMemBridge.HeadMemChainWF t → IsStruct4Local (ofString "dest") t →
    t.evalListHOLFinite (h := fun a => Classical.propDecidable (t.memaddrs a)) args = some values →
    PanSemStateFiniteExact.lookupCodeHOLFinite originalRuntimeCode.lookup fname values =
      some (body, callee, retShape) →
    EvmInvR32 cpost → HeadMemBridge.HeadMemChainWF cpost →
    evmChain cpost = evmChain (PanSemStateFiniteExact.callEntryStateHOLFinite t callee) →
    Qc (PanSemStateFiniteExact.callEntryStateHOLFinite t callee) v cpost →
    IsStruct4Local (ofString "dest") (setVarHOLFinite nm' v { cpost with locals := t.locals }) := by
  intro t values body callee retShape v cpost hi hw hs4 hev hlk hi2 hw2 hch hQc
  obtain ⟨w0, w1, w2, w3, hlk2⟩ := hs4
  refine ⟨w0, w1, w2, w3, ?_⟩
  simpa [setVarHOLFinite, HolFiniteMapExact.lookup_update, FUPDATE, hne] using hlk2

theorem decCall_hstep_isStruct4Local_transfer_and {F : Type}
    {nm' : MlS} (hne : nm' ≠ ofString "dest") {args : List (ExpHOL 64)} {fname : MlS}
    {Qc : ∀ {F : Type}, PanSemStateFiniteExact 64 F → ValueHOL 64 → PanSemStateFiniteExact 64 F → Prop} :
    ∀ (t : PanSemStateFiniteExact 64 F) (values : List (ValueHOL 64))
      (body : ProgHOL 64) (callee : HolFiniteMapExact MlS (ValueHOL 64)) (retShape : ShapeHOL)
      (v : ValueHOL 64) (cpost : PanSemStateFiniteExact 64 F),
    EvmInvR32 t → HeadMemBridge.HeadMemChainWF t → True ∧ IsStruct4Local (ofString "dest") t →
    t.evalListHOLFinite (h := fun a => Classical.propDecidable (t.memaddrs a)) args = some values →
    PanSemStateFiniteExact.lookupCodeHOLFinite originalRuntimeCode.lookup fname values =
      some (body, callee, retShape) →
    EvmInvR32 cpost → HeadMemBridge.HeadMemChainWF cpost →
    evmChain cpost = evmChain (PanSemStateFiniteExact.callEntryStateHOLFinite t callee) →
    Qc (PanSemStateFiniteExact.callEntryStateHOLFinite t callee) v cpost →
    IsStruct4Local (ofString "dest") (setVarHOLFinite nm' v { cpost with locals := t.locals }) := by
  intro t values body callee retShape v cpost hi hw ⟨_, hs4⟩ hev hlk hi2 hw2 hch hQc
  obtain ⟨w0, w1, w2, w3, hlk2⟩ := hs4
  refine ⟨w0, w1, w2, w3, ?_⟩
  simpa [setVarHOLFinite, HolFiniteMapExact.lookup_update, FUPDATE, hne] using hlk2

theorem op_jumpi_chainSpecR32 : OpHandlerChainSpecR32 (ofString "op_jumpi") := by
  refine opHandlerChainSpecR32_of_run 504 (by rw [guestAst_len]; decide)
    Guest.Software.guestFn_op_jumpi rfl ?_
  intro F s0 _ _ _
  dsimp only [Guest.Software.guestFn_op_jumpi, extractFn,
    InitECandidate.Solver.FrontendCodecComputation.progToHOLStructural,
    InitECandidate.Solver.FrontendCodecComputation.expToHOLStructural,
    InitECandidate.Solver.FrontendCodecComputation.expListToHOLStructural,
    InitECandidate.Solver.FrontendCodecComputation.shapeToHOLStructural,
    InitECandidate.Solver.FrontendCodecComputation.shapeListToHOLStructural,
    Option.map, List.map]
  refine HandlerRunA32.decCall_stack_pop_s4 (fun _ _ _ _ => trivial) ?_
  refine HandlerRunA32.decCall (Q := fun t => IsStruct4Local (ofString "dest") t)
    epsA32_stack_pop
    (fun _ _ _ _ _ _ _ _ _ _ _ => trivial)
    (decCall_hstep_isStruct4Local_transfer_and (nm' := ofString "cond") (args := [])
      (fname := ofString "stack_pop") (Qc := fun _ _ _ => True) (by decide)) ?_
  refine HandlerRunA32.seq_charge_gas_exact (Q := fun t => IsStruct4Local (ofString "dest") t)
    (fun _ w hw _ _ _ => by
      change some (ValueHOL.val (.word 10#64)) = some (.val (.word w)) at hw
      injection hw with h1; injection h1 with h2; injection h2 with h3; subst h3; decide)
    (fun _ _ _ _ _ _ _ hs4 _ _ _ _ _ => hs4) ?_
  refine HandlerRunA32.decCall (Q := fun t => IsStruct4Local (ofString "dest") t)
    epsA32_u256_is_zero
    (fun _ _ _ _ _ _ _ _ _ _ _ => trivial)
    (decCall_hstep_isStruct4Local_transfer (nm' := ofString "z")
      (args := [ExpHOL.var VarKind.local (ofString "cond")])
      (fname := ofString "u256_is_zero") (Qc := fun s _ post => LocFrame s post) (by decide)) ?_
  intro t hc hi hw hlen hR hs4 hnt
  rw [evaluateHOLFiniteState_seq_line780, evaluateHOLFiniteState_ite] at hnt ⊢
  revert hnt
  split
  · rename_i cw hcw
    by_cases hcw0 : cw = 0
    · subst hcw0
      simp only [↓reduceIte, evaluateHOLFiniteState_skip]
      intro hnt
      refine (HandlerRunA32.decCall (Q := fun u => IsStruct4Local (ofString "dest") u)
        epsA32_is_valid_jumpdest
        (fun _ _ _ _ _ _ _ _ _ _ _ => trivial)
        (decCall_hstep_isStruct4Local_transfer (nm' := ofString "ok")
          (args := [ExpHOL.var VarKind.local (ofString "dest")])
          (fname := ofString "is_valid_jumpdest") (Qc := fun s _ post => LocFrame s post) (by decide))
        (HandlerRunA32.seq_ite_raise_skip (fun _ _ _ hp => hp)
          (HandlerRunA32.seq_store_ev_nonstruct (Q := fun _ => True)
            0 (by simp [nonStructFrameOffs])
            (fun _ v hs4 hv => eval_rField_of_struct4 hs4 0 (by omega) v hv)
            (fun _ _ _ _ _ _ _ _ => trivial)
            (HandlerRunA32.ret _)))) t hc hi hw hlen hR hs4 hnt
    · simp only [hcw0, ↓reduceIte]
      have hyes_run : HandlerRunA32 s0 (fun _ => True) true
          (.seq (.call (some (none, none)) (ofString "pc_add") [.const 1#64]) (.return (.const 0#64))) :=
        HandlerRunA32.seq_call_simple epsA32_pc_add (HandlerRunA32.ret _)
      rcases hyes_ev : evaluateHOLFiniteState t
          (.seq (.call (some (none, none)) (ofString "pc_add") [.const 1#64]) (.return (.const 0#64))) with ⟨ry, sy⟩
      cases ry with
      | none =>
        exfalso
        rw [evaluateHOLFiniteState_seq_line780] at hyes_ev
        rcases hcall : evaluateHOLFiniteState t
            (.call (some (none, none)) (ofString "pc_add") [.const 1#64]) with ⟨rc, sc⟩
        rw [hcall] at hyes_ev
        cases rc with
        | some _ => dsimp only at hyes_ev; injection hyes_ev with hr; cases hr
        | none =>
          dsimp only at hyes_ev
          rw [evaluateHOLFiniteState_return] at hyes_ev
          split at hyes_ev
          · injection hyes_ev with hr; cases hr
          · split at hyes_ev <;> (injection hyes_ev with hr; cases hr)
      | some r0 =>
        intro hnt
        have hp := hyes_run t hc hi hw hlen hR trivial (by rw [hyes_ev]; exact hnt)
        rw [hyes_ev] at hp; exact hp
  · intro _; exact opDispatchChainPostR32_error s0 t

theorem epsA32_move_ether :
    EvmPreservingSpecA32 (fun _ => True)
      (fun s _ post => GlobalsKept ["heap_ptr", "journal_n", "scratch_ptr"] s post ∧
        OpDispatchSpec.evmR post = OpDispatchSpec.evmR s)
      (ofString "move_ether") :=
  epsA32_of_wkSc validBufList_acctMutBufs safeStepGlobals_hp_jn_sp R16Shards.EvmEkFkPrologue.wkSc_move_ether
    (fun _ h => let ⟨hAs, S, hIA⟩ := h.evmInv; ⟨hAs, S, hIA.1⟩)
    (by decide) (by decide) (by decide)
